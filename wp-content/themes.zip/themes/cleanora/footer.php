<?php
/**
 * @package 	WordPress
 * @subpackage 	Cleanora
 * @version		1.0.0
 * 
 * Website Footer Template
 * Created by CMSMasters
 * 
 */


$cmsmasters_option = cleanora_get_global_options();
?>


		</div>
	</div>
</div>
<!--  Finish Middle  -->
<?php 

get_sidebar('bottom');

?>
<a href="<?php echo esc_js("javascript:void(0)"); ?>" id="slide_top" class="cmsmasters_theme_icon_slide_top"><span></span></a>
</div>
<!--  Finish Main  -->

<!--  Start Footer  -->

<!-- disabled chatkit  
<div class="chatbubble">
			<div class="unexpanded">
				<div class="title" id='chat-label'></div>
			</div>
			<div class="expanded chat-window">
			  <div class="login-screen container">
				<form id="loginScreenForm">
				  <div class="form-group">
					<input type="text" class="form-control" id="fullname" placeholder="Name*" required>
				  </div>
				  <div class="form-group">
					<input type="email" class="form-control" id="email" placeholder="Email Address*" required>
				  </div>
				  <button type="submit" class="btn btn-block btn-primary">Start Chat</button>
				</form>
			  </div>
			  <div class="chats">
				<div class="loader-wrapper">
				  <div class="loader">
					<span>{</span><span>}</span>
				  </div>
				</div>
				<ul class="messages clearfix" id='messagesdiv'>
				</ul>
				<div class="input">
				  <form class="form-inline" id="messageSupport">
					<div class="form-group">
					  <input type="text" autocomplete="off" class="form-control" id="newMessage" placeholder="Enter Message">
					</div>
					<button type="submit" class="btn btn-primary">Send</button>
				  </form>
				</div>
			  </div>
			</div>
		</div> disabled chatkit -->
<footer id="footer">
	<?php  
	get_template_part('theme-framework/theme-style' . CMSMASTERS_THEME_STYLE . '/template/footer');
	?>
</footer>
<!--  Finish Footer  -->

<?php do_action('cmsmasters_after_page', $cmsmasters_option); ?>
</div>
<span class="cmsmasters_responsive_width"></span>
<!--  Finish Page  -->

<?php do_action('cmsmasters_after_body', $cmsmasters_option); ?>
<?php wp_footer(); ?>
<?php 
    global $post;
    $post_slug=$post->post_name;
if ($post_slug !='offers-en' && $post_slug !='contact' ){
	?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5b700fcbf31d0f771d83b68a/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<?php
}
?>
<!--<a href="https://api.whatsapp.com/send?phone=+9651888883" target="_blank" class="whatsapp-chat"><img src="http://qmc-dubai.com/wp-content/uploads/2021/05/whatsapp-chat-link-black.png"></a>-->
</body>
</html>