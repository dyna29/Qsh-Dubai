/**
 * @package 	WordPress
 * @subpackage 	Cleanora
 * @version 	1.0.1
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */

To update your theme please use the files list from the FILE LOGS below and substitute/add the listed files on your server with the same files in the Updates folder.

Important: after you have updated the theme, in your admin panel please proceed to
Theme Settings - Fonts and click "Save" in any tab,
then proceed to 
Theme Settings - Colors and click "Save" in any tab here.


--------------------------------------
Version 1.0.1: files operations:
	Theme Files edited:
		cleanora\js\smooth-sticky.min.js
		cleanora\readme.txt
		cleanora\style.css
		cleanora\theme-framework\theme-style\js\jquery.isotope.mode.js
		cleanora\theme-vars\plugin-activator.php
	
	
	Proceed to wp-content\plugins\cmsmasters-content-composer 
	and update all files in this folder to version 2.2.8
	
	
	
--------------------------------------

Version 1.0: Release!

