<?php
/**
 * @cmsmasters_package 	Cleanora
 * @cmsmasters_version 	1.0.0
 */


?>
<ul class="products columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?> cmsmasters_products">