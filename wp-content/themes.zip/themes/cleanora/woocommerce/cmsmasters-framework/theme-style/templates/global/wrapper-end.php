<?php
/**
 * @cmsmasters_package 	Cleanora
 * @cmsmasters_version 	1.0.0
 */


echo '</div>' . "\n" . 
'<!--  Finish Content  -->' . "\n\n";
