(function() {
    'use strict';

     const PUSHER_INSTANCE_LOCATOR = "v1:us1:dc46542f-b040-4e5b-932d-4271d9c98927"

    // ----------------------------------------------------
    // Chat Details
    // ----------------------------------------------------

    let chat = {
        messages: [],
        room:  undefined,
        userId: undefined,
        currentUser: undefined,
    }
 

    // ----------------------------------------------------
    // Targeted Elements
    // ----------------------------------------------------
const chatstart = 0;
    const chatPage   = jQuery(document)
    const chatWindow = jQuery('.chatbubble') 
    const chatHeader = chatWindow.find('.unexpanded')
    const chatBody   = chatWindow.find('.chat-window')


    // ----------------------------------------------------
    // Helpers
    // ----------------------------------------------------

    let helpers = {
        /**
         * Toggles the display of the chat window.
         */
        ToggleChatWindow: function () {
			
			if(chatstart==0){
			   helpers.ShowAppropriateChatDisplay();
				let chatstart = 1
			   }
            chatWindow.toggleClass('opened')
            chatHeader.find('.title').text(
                chatWindow.hasClass('opened') ? 'Minimize Live Chat' : 'Live Chat'
            )
        },

        /**
         * Show the appropriate display screen. Login screen
         * or Chat screen.
         */
        ShowAppropriateChatDisplay: function () {
			 if (localStorage.getItem("qmcchat_uemail") !== null) {
   	            var uemail = localStorage.getItem('qmcchat_uemail')
			    var uname = localStorage.getItem('qmcchat_uname')
			    var uroom = localStorage.getItem('qmcchat_uroomid')
			 
				  chat.userId = uemail
				   chat.roomid = uroom
              } 
		  
			(chat.roomid && chat.userId) ? helpers.ShowChatRoomDisplay() : helpers.LogIntoChatSession()
        },

        /**
         * Show the enter details form
         */
        ShowChatInitiationDisplay: function () {
			chatBody.find('.chats').removeClass('active')
            chatBody.find('.login-screen').addClass('active')
        },

        /**
         * Show the chat room messages dislay.
         */
        ShowChatRoomDisplay: function () {
			chatBody.find('.chats').addClass('active')
            chatBody.find('.login-screen').removeClass('active')
console.log(chat)
			console.log('chat')
		
            const chatManager = new Chatkit.ChatManager({
                userId: chat.userId,
                instanceLocator: PUSHER_INSTANCE_LOCATOR,
                 tokenProvider: new Chatkit.TokenProvider({userId: chat.userId, url: "https://us1.pusherplatform.io/services/chatkit_token_provider/v1/dc46542f-b040-4e5b-932d-4271d9c98927/token"})
            });
			console.log('after request');
			console.log(chatManager);
			chatManager
			.connect()
			.then(currentUser => {
				chat.currentUser = currentUser
				console.log('roomid'+chat.roomid)
				
				currentUser.fetchMessages({
				  roomId: chat.roomid,
				  direction: 'older',
				  limit: 100
				})
				  .then(messages => {
							chatBody.find('ul.messages').append(
                    `<li class="clearfix message  welcome">
                        
                        <div class="message"> Hello , welcome to QMC support. How may I help u? </div>
                    </li>`
                )
					chatBody.find('.loader-wrapper').hide()
					chatBody.find('.input, .messages').show()

					messages.forEach(message => helpers.PrevChatMessage(message))
                
					currentUser.subscribeToRoom({
						roomId: chat.roomid,
						hooks: { 
							onMessage: message => helpers.NewChatMessage(message) 
						}						 
					})
				  })
				  .catch(err => {
					console.log(`Error fetching messages: ${err}`)
				  })
				
			})
		  .catch(error => {
				console.log('errorshow');
			console.log(error);
				helpers.LogIntoChatSession();
		  });
          
          
        },
/**
         * Append a message to the chat messages UI.
         */
        PrevChatMessage: function (message) {
		 
            if (chat.messages[message.id] === undefined) {
                const messageClass = message.sender.id !== chat.userId ? 'support' : 'user'
                const messageuname = message.sender.id !== chat.userId ? 'Support: ' : 'Me: '
console.log('prev'+message.text)
                chatBody.find('ul.messages').append(
                    `<li class="clearfix message ${messageClass}">
                        
                        <div class="message">${messageuname} ${message.text}</div>
                    </li>`
                )

                chat.messages[message.id] = message
                  console.log('scrollTop');
                  console.log(jQuery.find('ul.messages').scrollHeight);
                chatBody.scrollTop(chatBody[0].scrollHeight)
				document.getElementById("messagesdiv").scrollTop = document.getElementById("messagesdiv").scrollHeight
            }
        },
        /**
         * Append a message to the chat messages UI.
         */
        NewChatMessage: function (message) {
		    

            if (chat.messages[message.id] === undefined) {
                const messageClass = message.sender.id !== chat.userId ? 'support' : 'user'
                const messageuname = message.sender.id !== chat.userId ? 'Support: ' : 'Me: '
console.log('new'+message.text)
							jQuery('.chatbubble .unexpanded').css('background-color', '#76c069');
                chatBody.find('ul.messages').append(
                    `<li class="clearfix message ${messageClass}">
                        
                        <div class="message">${messageuname} ${message.text}</div>
                    </li>`
                )

                chat.messages[message.id] = message

                chatBody.scrollTop(chatBody[0].scrollHeight)
				document.getElementById("messagesdiv").scrollTop = document.getElementById("messagesdiv").scrollHeight
            }
        },

        /**
         * Send a message to the chat channel
         */
        SendMessageToSupport: function (evt) {
            evt.preventDefault()

            const message = jQuery('#newMessage').val().trim()

            chat.currentUser.sendMessage( {text: message, roomId: localStorage.getItem('qmcchat_uroomid')},
                msgId => { console.log("Message added!") },
                error => { console.log(`Error adding message to jQuery{chat.room.id}: jQuery{error}`) }
            )
			
            jQuery('#newMessage').val('')
			document.getElementById("messagesdiv").scrollTop = document.getElementById("messagesdiv").scrollHeight
        },

        /**
         * Logs user into a chat session
         */
        LogIntoChatSession: function (evt) {
          
			chatBody.find('#loginScreenForm input, #loginScreenForm button').attr('disabled', true)
 
                jQuery.post(globalvar.site_url+'/wp-json/chatkitpusher/v1/session/load', { }, function( response ) {
                 console.log(response)
                    chat.userId = response.created_by_id
                    chat.room   = response 
                    chat.roomid   =response.id
					 
			        localStorage.setItem('qmcchat_uroomid',chat.room.id); 
			        localStorage.setItem('qmcchat_uemail',chat.userId);
			 
					 console.log('lo'+localStorage.getItem('qmcchat_uroomid'))
                    helpers.ShowAppropriateChatDisplay()
                })
          

           
        }
    }


    // ----------------------------------------------------
    // Register page event listeners
    // ----------------------------------------------------

  //  chatPage.ready()
    chatHeader.on('click', helpers.ToggleChatWindow)
    chatBody.find('#loginScreenForm').on('submit', helpers.LogIntoChatSession)
    chatBody.find('#messageSupport').on('submit', helpers.SendMessageToSupport)
	
	 jQuery('#newMessage').on('click', function() {
     jQuery('.chatbubble .unexpanded').css('background-color', '#59a4b9');
    });
}())