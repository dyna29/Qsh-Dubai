	
	
	/*FLIP CLOCK STARTS*/
	console.clear();
	jQuery('.slide-carousel').owlCarousel({
    loop:true,
    margin:0, 
    dots:false,
    nav:true,
		autoplay:true, 
		animateOut : "fadeOut",
		animateIn : "fadeIn",
     navText : ['<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevronw-left-48.png" />','<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevronw-right-48.png" />'],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
jQuery(document).ready(function(){
	
		 jQuery('.home-map').attr('src','https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13910.57093305394!2d48.0308314!3d29.3514644!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5cddd330c44d78f5!2z2YXYsdmD2LIg2YLYt9mK2YbYqSDYp9mE2LfYqNmKIC0gUU1D!5e0!3m2!1sen!2sin!4v1600693185266!5m2!1sen!2sin')
	if(jQuery('body.home').length >0){
		 jQuery(this).scrollTop(0);
	}
   
});

jQuery(document).ready(function() { 
		console.log('take_tour_url'+globaltrans.cur_lang)

	if(globaltrans.cur_lang =='ar'){
	console.log('take_tour_url')
	   jQuery('.i360-container').find('a').attr('href',globaltrans.take_tour_url)
	   jQuery('.i360-container ').append('<a href="https://qmc-dubai.com/home"  class="language-switch"><img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/gb.png" /></a>')
	   jQuery('.logo_wrap').append('<div class="language-switch"><a href="https://qmc-dubai.com/home"><img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/gb.png" /></a></div>')
	   }else{
		   jQuery('.logo_wrap').append('<div class="language-switch"><a href="http://qmc-dubai.com/ar/%d8%a7%d9%84%d8%b5%d9%81%d8%ad%d8%a9-%d8%a7%d9%84%d8%b1%d8%a6%d9%8a%d8%b3%d9%8a%d8%a9/"><img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/kuwait.png" /></a></div>')
		jQuery('.i360-container ').append('<a href="http://qmc-dubai.com/ar/%d8%a7%d9%84%d8%b5%d9%81%d8%ad%d8%a9-%d8%a7%d9%84%d8%b1%d8%a6%d9%8a%d8%b3%d9%8a%d8%a9/"  class="language-switch"><img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/kuwait.png" /></a>')   
	   }
	// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
 
// When the user clicks the button, open the modal 
jQuery("#myBtn").click(function(){
 alert('clicked')
jQuery("#myModal").css("display", "block");
})
 

// When the user clicks on <span> (x), close the modal
jQuery(".close-offer").click(function(){
 jQuery("#myModal").css("display", "none");
})
 console.log( 'dis-offerpop' )
 console.log(localStorage.getItem('dis-offer-pop'))
    if(localStorage.getItem('dis-offer-pop') == null){ 
 
		  jQuery('#myModal').css("display", "block");
		 localStorage.setItem('dis-offer-pop','shown')
    }
else
    {
        localStorage.setItem('dis-offer-pop','shown')
       jQuery("#myModal").css("display", "none");
	}
}); 
jQuery(document).ready(function() {
	jQuery('#service-banner').on( "mouseenter", function() {
		console.log('enter')
		jQuery('.floating-review-block').hide();
		});
		jQuery('#service-banner').on( "mouseleave", function() {
			console.log('leave')
		jQuery('.floating-review-block').show();
		});
 
});
jQuery(document).ready(function(){
	
	//review slider
	//
	//
	jQuery('.review-slider').owlCarousel({
   items : 1,
     loop  : true,
     margin : 50,
     nav    : true,
     smartSpeed :900,
		autoplay:true,
     navText : ['<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/icon-left.png" />','<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/icon-right.png" />'],
		    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
      jQuery("input[name='medical-check']").click(function(){
            var radioValue = jQuery("input[name='medical-check']:checked").val();
            if(radioValue=='Non Medical'){
                jQuery(".medical-cert").hide()
            }else{
				jQuery(".medical-cert").show()
			}
        });
        
    });
jQuery(document).ready(function(){
	
	
	//jQuery(".box").appendTo("#page");
        var boxWidth = jQuery(".box").width();
	 jQuery(".box").animate({
                width: "toggle"
            });
        jQuery(".slide-toggle").click(function(){
			
			if(jQuery('.cmsmasters_toggle_inner').hasClass('minheight')){
				jQuery('.cmsmasters_toggle_inner').removeClass('minheight')
			}
			else{
				jQuery('.cmsmasters_toggle_inner').addClass('minheight')
			}
           jQuery(".box").animate({
                width: "toggle"
            });
        });
    });

function CountdownTracker(label, value){

  var el = document.createElement('span');

  el.className = 'flip-clock__piece';
  el.innerHTML = '<b class="flip-clock__card card"><b class="card__top"></b><b class="card__bottom"></b><b class="card__back"><b class="card__bottom"></b></b></b>' + 
    '<span class="flip-clock__slot">' + label + '</span>';

  this.el = el;

  var top = el.querySelector('.card__top'),
      bottom = el.querySelector('.card__bottom'),
      back = el.querySelector('.card__back'),
      backBottom = el.querySelector('.card__back .card__bottom');

  this.update = function(val){
    val = ( '0' + val ).slice(-2);
    if ( val !== this.currentValue ) {
      
      if ( this.currentValue >= 0 ) {
        back.setAttribute('data-value', this.currentValue);
        bottom.setAttribute('data-value', this.currentValue);
      }
      this.currentValue = val;
      top.innerText = this.currentValue;
      backBottom.setAttribute('data-value', this.currentValue);

      this.el.classList.remove('flip');
      void this.el.offsetWidth;
      this.el.classList.add('flip');
    }
  }
  
  this.update(value);
}

// Calculation adapted from https://www.sitepoint.com/build-javascript-countdown-timer-no-dependencies/

function getTimeRemaining(endtime) {
  var t = Date.parse(endtime) - Date.parse(new Date());
  return {
    'Total': t,
    'Days': Math.floor(t / (1000 * 60 * 60 * 24)),
    'Hours': Math.floor((t / (1000 * 60 * 60)) % 24),
    'Minutes': Math.floor((t / 1000 / 60) % 60),
    'Seconds': Math.floor((t / 1000) % 60)
  };
}

function getTime() {
  var t = new Date();
  return {
    'Total': t,
    'Hours': t.getHours() % 12,
    'Minutes': t.getMinutes(),
    'Seconds': t.getSeconds()
  };
}

function Clock(countdown,callback) {
  
  countdown = countdown ? new Date(Date.parse(countdown)) : false;
  callback = callback || function(){};
  
  var updateFn = countdown ? getTimeRemaining : getTime;

  this.el = document.createElement('div');
  this.el.className = 'flip-clock';

  var trackers = {},
      t = updateFn(countdown),
      key, timeinterval;

  for ( key in t ){
    if ( key === 'Total' ) { continue; }
    trackers[key] = new CountdownTracker(key, t[key]);
    this.el.appendChild(trackers[key].el);
  }

  var i = 0;
  function updateClock() {
    timeinterval = requestAnimationFrame(updateClock);
    
    // throttle so it's not constantly updating the time.
    if ( i++ % 10 ) { return; }
    
    var t = updateFn(countdown);
    if ( t.Total < 0 ) {
      cancelAnimationFrame(timeinterval);
      for ( key in trackers ){
        trackers[key].update( 0 );
      }
      callback();
      return;
    }
    
    for ( key in trackers ){
      trackers[key].update( t[key] );
    }
  }

  setTimeout(updateClock,500);
}



 
	/*FLIP CLOCK ENDS*/
jQuery( document ).ready(function() {
	if(jQuery( '.single-project' ).find('.cmsmasters_img_link').length){
		jQuery( '.single-project' ).find('.cmsmasters_img_link').attr('href','javascript:void(0)')
		
		jQuery( '.single-project' ).find('.cmsmasters_img_link').attr('rel','')
	}
    	jQuery('#loginPanel1').click(function(){
            
                if (jQuery('#userNav').is(':hidden')) {
                   
                   jQuery('#userNav').show('slide',{direction:'right'},1000);
                } else {
                   
                   jQuery('#userNav').hide('slide',{direction:'right'},1000);
                }
});
	mainwidth  =  jQuery('#main').width();
	 
	 
    
    jQuery('.page-loader').hide();
   // jQuery('.header_mid').attr('style', 'width: '+mainwidth+'px !important');
	// jQuery('.header_bot').attr('style', 'width: '+mainwidth+'px !important');
	// jQuery('.footer').attr('style', 'width: '+mainwidth+'px !important');
     jQuery('#page').show();
	 //socila floating links
	 //
	 //
	 	html = '<div class="icon-bar">'
		html += '<a href="#" class="Snapchat social-media-floating" target="_blank" item="1" datapull="snapchat-data"><img src="'+globalvar.assets+'/images/social1.png"></a> '
		html += '<a href="https://www.facebook.com/qmckuwait/" class="Facebook social-media-floating1" target="_blank" item="2"  datapull="facebook-data"><img src="'+globalvar.assets+'/images/social2.png"></a>' 
		html += '<a href="https://www.instagram.com/Qmckuwait/" class="Instagram social-media-floating1"  datapull="widget_instagram-feed-widget" target="_blank" item="3"><img src="'+globalvar.assets+'/images/social3.png"></a> '
		html += '<a href="https://twitter.com/qmckuwait" class="Twitter social-media-floating1" target="_blank"  datapull="twitter-data" item="4"><img src="'+globalvar.assets+'/images/social5.png"></a>'
		html += '<a href="https://www.youtube.com/channel/UCvucYiYEAh0LIXdFDmAWFpQ" class="Youtube social-media-floating1" target="_blank"  datapull="youtube-data" item="5"><img src="'+globalvar.assets+'/images/social4.png"></a> '
		//html += '<a href="#" class="QRcode social-media-floating" target="_blank"  datapull="qrcode-data" item="5"><img src="'+globalvar.assets+'/images/icons8-qr-code-50.png"></a> '
		html += '<div class="icon-details">Details</div>'	
	html += '</div>'	
	htmlright= '<div class="featured-before-after"><div class="ba-label">'+globaltrans.beforenafter+'</div>'	
		htmlright += '<div class="featured-before-after-slider">' 
	htmlright += '</div>'
	htmlright += '</div>'
	var isOnDiv = false;
	
	 jQuery(document).on("mouseenter", ".social-media-floating1", function() {
	isOnDiv=false;
  jQuery( ".icon-details" ).fadeOut( "slow", function() {
    // Animation complete
  });
		 console.log('icon-details mouse leave')
	   console.log("isOnDiv" )
	  console.log(isOnDiv )									 
  });
 jQuery(document).on("mouseenter", ".icon-details", function() {
	 isOnDiv=true;
	 console.log('icon-details mouse enter')
	   console.log("isOnDiv" )
	  console.log(isOnDiv )
 });
 jQuery(document).on("mouseleave", ".icon-details", function() {
	isOnDiv=false;
  jQuery( ".icon-details" ).fadeOut( "slow", function() {
    // Animation complete
  });
		 console.log('icon-details mouse leave')
	   console.log("isOnDiv" )
	  console.log(isOnDiv )									 
  });
   
		 jQuery(document).on("mouseenter", ".featured-before-after", function() {
		   jQuery( ".featured-before-after-slider" ).fadeIn( "slow", function() {
    // Animation complete
  });
		 })
	
	
		 jQuery(document).on("mouseleave", ".featured-before-after", function() {
		   jQuery( ".featured-before-after-slider" ).fadeOut( "slow", function() {
    // Animation complete
  });
		 })
	 jQuery(document).on("mouseenter", ".social-media-floating", function() {
		  jQuery(".icon-details").html("")
	   console.log(".social-media-floating" )
		 isOnDiv=true;
	  item = jQuery(this).attr('item')
		 datapull =   jQuery(this).attr('datapull')
		 if(datapull !=''){
			 datapullshow =  jQuery("."+datapull).html()
			 if(datapull=='twitter-data'){
				  jQuery(".icon-details").html('<a class="twitter-timeline" data-width="300" data-height="200" data-theme="light" href="https://twitter.com/qmckuwait?ref_src=twsrc%5Etfw">Tweets by qmckuwait</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>')
		 
			 }else{
				  jQuery(".icon-details").html(datapullshow)
			 }}
			
		 item = parseFloat(item)-1
		toppos = parseFloat(item)* 50
		jQuery(".icon-details").css('top',toppos + "px");
		 jQuery(".icon-details").css('left',  "50px");
	  jQuery( ".icon-details" ).fadeIn( "slow", function() {
    // Animation complete
  });
 console.log('.social-media-floating mouse enter')
	   console.log("isOnDiv" )
	  console.log(isOnDiv )
  })
	 jQuery(document).on("mouseleave", ".social-media-floating", function() {
	    if(isOnDiv == false){
				  item = jQuery(this).attr('item')
	  jQuery( ".icon-details" ).fadeOut( "slow", function() {
    // Animation complete
  });
		}
 console.log('.social-media-floating mouse leave')
	   console.log("isOnDiv" )
	  console.log(isOnDiv )
	   
  })
	//timing-grid
	//
	
	jQuery('#bottom').find('.contact_widget_phone').after("<div class='timing-grid'></div>")
	  jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'show_timing_grid', 
                      
                 },
                 success: function(response) { 
					 	response = jQuery.parseJSON( response )
                      	jQuery('.timing-grid').html(response.html)
                       
                 }
             });
	jQuery('#page').prepend(html)
	var bodyarea =  jQuery('body').width()
	var middlearea =  jQuery('#middle').width()
    marginleftforbeforeafter = (parseFloat(bodyarea) - parseFloat(middlearea))/2
	marginleftforbeforeafterslider = marginleftforbeforeafter - 100
    jQuery('body').width()
 
	jQuery('#page').prepend(htmlright)
	
	jQuery('.featured-before-after').css('margin-right', marginleftforbeforeafter); 
	jQuery('.icon-bar').css('margin-left', marginleftforbeforeafter); 
	jQuery('.featured-before-after-slider').html(jQuery('#featured-ba-items').html()); 
	jQuery('#featured-ba-items').html('')
	jQuery('.bf-top-slider').owlCarousel({
   items : 1,
     loop  : true,
     margin : 50,
     nav    : true,
     smartSpeed :900,
		autoplay:true,
     navText : ['<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-left-48.png" />','<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-right-48.png" />'],
		    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})	 
	//socila floating links end
	 //
	 //
	 //
	jQuery('.before-after-menubox').find('.sub-menu').find('.sub-menu').find('a').each(function(i)
		{
		  ba_href = jQuery(this).attr('href') 
		  jQuery(this).addClass('subsub') 
			 ba_href = ba_href.replace("before-after-category", "before-and-after");
				 jQuery(this).attr('href',ba_href) 
		});
	jQuery('.before-after-menubox').find('.sub-menu').find('a').each(function(i)
		{
		if(jQuery(this).hasClass('subsub')){
			console.log('subsub')
		}else{
			console.log('nosubsub')
			jQuery(this).attr('href','#') 
		} 
				 
		});
	
	if(jQuery('.museum-icon').length >0){
		if(globaltrans.cur_lang=='ar'){
		  jQuery('.museum-icon').html('<a href="'+globalvar.site_url+'/ar/الضيافة/#quttainah-medical-museum" alt="المتحف الطبي"  class="tooltip-1"    ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/menu-icon-1.png" class="menu-img-icon"><div class="tooltiptext-1 menu-desc-medusa">المتحف الطبي</div></a>')  
		   }else{
		jQuery('.museum-icon').html('<a href="'+globalvar.site_url+'/hospitality/#quttainah-medical-museum" alt="Quttainah Medical Museum"  class="tooltip-1"    ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/menu-icon-1.png" class="menu-img-icon"><div class="tooltiptext-1 menu-desc-medusa">Quttainah Medical Museum</div></a>')}
	} 
	if(jQuery('.medusa-icon').length >0){
	if(globaltrans.cur_lang=='ar'){ 
	
	jQuery('.medusa-icon').html('<a href="'+globalvar.site_url+'/ar/الضيافة/" class="tooltip"  alt="كافيه ميدوسا" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/menu-icon-2.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">كافيه ميدوسا</div></a>')
	
	}else{
		jQuery('.medusa-icon').html('<a href="'+globalvar.site_url+'/hospitality/" class="tooltip"  alt="Café Medusa" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/menu-icon-2.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">Café Medusa</div></a>')}
	} 
	if(jQuery('.laboratory-icon').length >0){
		if(globaltrans.cur_lang=='ar'){
		
		jQuery('.laboratory-icon').html('<a href="'+globalvar.site_url+'/service/مختبر/" class="tooltip"  alt="Laboratory" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon1.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">مختبر</div></a>')
		
		}else{
		jQuery('.laboratory-icon').html('<a href="'+globalvar.site_url+'/service/laboratory/" class="tooltip"  alt="Laboratory" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon1.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">Laboratory</div></a>')}
	} 
	if(jQuery('.ivf-icon').length >0){
		if(globaltrans.cur_lang=='ar'){
		jQuery('.ivf-icon').html('<a href="'+globalvar.site_url+'/ar/service/أمراض-النساء-وأطفال-الأنابيب/" class="tooltip"  alt="IVF" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon2.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">أمراض النساء وأطفال الأنابيب</div></a>')
		
		}else{
		jQuery('.ivf-icon').html('<a href="'+globalvar.site_url+'/service/gynecology-and-ivf/" class="tooltip"  alt="IVF" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon2.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">IVF</div></a>')}
	} 
	if(jQuery('.pharmacy-icon').length >0){
		if(globaltrans.cur_lang=='ar'){ 
		jQuery('.pharmacy-icon').html('<a href="'+globalvar.site_url+'/الصيدلية/" class="tooltip"  alt="الصيدلية" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon3.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">الصيدلية</div></a>')
		}else{
		jQuery('.pharmacy-icon').html('<a href="'+globalvar.site_url+'/pharmacy/" class="tooltip"  alt="Pharmacy" ><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/micon3.png" class="menu-img-icon"><div class="tooltiptext menu-desc-medusa">Pharmacy</div></a>')
	} }
	if(jQuery('#beforeafter-header').length >0){
		jQuery('.headline_text').html('<h1 class="entry-title">'+ jQuery('#beforeafter-header').val()+'</h1>')
	} 
	
	//review
	//
	jQuery(document).on("click", "#write-review", function() {
		if(jQuery('#write-review-block').hasClass('closed')){
			jQuery('#write-review-block').addClass='opened';
			jQuery('#write-review-block').show();
			jQuery('.review-msg').html('')
		} 
	 })
	jQuery(document).on("click", ".rate-star", function() {
		rate = jQuery(this).attr('rating')
		jQuery('.rate-star').find('img').attr('src',globalvar.assets+'/images/star-empty.png')
		for(i=1;i<=rate;i++){
			jQuery('#rate-star-'+i).find('img').attr('src',globalvar.assets+'/images/star.png')
		}
		jQuery('#rating').val(rate)
	 })
	jQuery(document).on("click", "#submit-review", function() {
		 rating = jQuery('#rating').val()
		 headline = jQuery('#headline').val()
		 review_text = jQuery('#review-text').val()
		 reviewer_name = jQuery('#reviewer-name').val()
		 review_type = jQuery('#review-type').val()
		 service_id = jQuery('#service_id').val()
		 jQuery('.error').remove();
		 error = 0;
		if(jQuery('#rating').val() ==''){
			jQuery('#rating').after('<span class="error">Please rate our service!</span>');
			error = 1;
		}
		if(jQuery('#headline').val() ==''){
			jQuery('#headline').after('<span class="error">Please headline for the review!</span>');
			error = 1;
		}
		if(jQuery('#review-text').val() ==''){
			jQuery('#review-text').after('<span class="error">Please enter your review!</span>');
			error = 1;
		}
		if(jQuery('#reviewer-name').val() ==''){
			jQuery('#reviewer-name').after('<span class="error">Please enter your name!</span>');
			error = 1;
		}
		if(error==0){
			 var submitBtn = jQuery(this)
             submitBtn.hide()
			 submitBtn.after("<img src='" + globalvar.assets+"/images/preloader.gif' class='ajax-loader'>")
					  jQuery.ajax({
                 url: globalvar.ajax_url,
						 
                 type: 'post',
                 data: {
                     action: 'submit_review', 
                     rating:rating,
						  headline:headline,
						  review_text:review_text,
						  reviewer_name:reviewer_name,
						   review_type:review_type,  
					 service_id:service_id,
                 },
                 success: function(response) { 
					 		response = jQuery.parseJSON( response )
				  jQuery('.ajax-loader').remove()
                     submitBtn.show()
                      		jQuery('.review-msg').html('Your review has been submitted successfully!')
						   jQuery('#write-review-block').removeClass('opened');
						   jQuery('#write-review-block').addClass('closed');
						   jQuery('#write-review-block').hide();
					 jQuery('.rate-star').find('img').attr('src',globalvar.assets+'/images/star-empty.png')
				  jQuery('#rating').val('')
		 jQuery('#headline').val('')
		 jQuery('#review-text').val('')
		 jQuery('#reviewer-name').val('')
                 }
             });
		}

		
	 })
	
	//
///review end
	if(jQuery('.searchbox').length >0){
	jQuery('.searchbox').html('<input type="text" placeholder="'+globaltrans.search+'" id="search-box"><a href="javascript:void(0)" id="search-site"><img src="https://qmc-dubai.com/wp-content/uploads/2018/12/icons8-search-50.png" class="search-icon" />')
	
	 jQuery('.contact-text.ns').html(globaltrans.needsupport) 
	 jQuery('.contact-text.cu').html(globaltrans.calluson) 
	 jQuery('.cms_home').html(globaltrans.home) 
	 jQuery('.txt-hotline').html(globaltrans.hotline) 
	 jQuery('.lbl-email').html(globaltrans.email) 
	 jQuery('#chat-label').html(globaltrans.livechat) 
	 jQuery('.footer_copyright').html(globaltrans.copyright+' | Powered by <a href="http://www.kdakw.com/" target="_blank" class="powerdby">KDA</a>') 
	jQuery('h2.share_posts_title').html(globaltrans.likethisservice) 
	jQuery('.single-project h2.cmsmasters_single_slider_title').html(globaltrans.moreservices) 
		 
	}
	 jQuery(document).on("click", "#search-site", function() {
		 location.href=globalvar.site_url+'/?s='+jQuery('#search-box').val()
	 })
	// timing display
	if(jQuery('.timing-box').length >0){
		  jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'show_timing_box', 
                      
                 },
                 success: function(response) { 
					 	response = jQuery.parseJSON( response )
                      	jQuery('.timing-box').html(response.html)
                       
                 }
             });
	   }
	// counters increment
	if(jQuery('.vippatients').length >0 ){
		
		 
		  jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'show_counters', 
                      
                 },
                 success: function(response) { 
					 	response = jQuery.parseJSON( response )
					 console.log(response.vippatients)
					 	 jQuery('.vippatients').attr('data-percent',response.counter_vippatients) 
					 	 jQuery('.cases').attr('data-percent',response.counter_cases) 
					 	 jQuery('.staffdoctors').attr('data-percent',response.counter_staffdoctors) 
					 console.log('fetched')
					 
					   var cnt = 0;
					   var cnt2 = 0;
					   var cnt3 = 0;
            var counter = setInterval(function() {
                if (cnt < response.counter_vippatients) {
                    jQuery('.vippatients').find('.cmsmasters_counter_counter').html(cnt);
                   cnt =  cnt+19;
                }
                else {
                    clearInterval(counter);
                     jQuery('.vippatients').find('.cmsmasters_counter_counter').html(cnt);
                }
				      }, 5);
					 
					    var counter2 = setInterval(function() {
							console.log('counter_cases'+response.counter_cases)
						 
				  if (cnt2 < response.counter_cases) {
                    jQuery('.cases').find('.cmsmasters_counter_counter').html(cnt2);
                   cnt2 =  cnt2+49;
                }
                else {
                    clearInterval(counter2);
                     jQuery('.cases').find('.cmsmasters_counter_counter').html(response.counter_cases);
                }
				     }, 5);
					 
				   var counter3 = setInterval(function() {
				  if (cnt3 < response.counter_staffdoctors) {
                    jQuery('.staffdoctors').find('.cmsmasters_counter_counter').html(cnt3);
                     cnt3 =  cnt3+19;
                }
                else {
                    clearInterval(counter3);
                     jQuery('.staffdoctors').find('.cmsmasters_counter_counter').html(response.counter_staffdoctors);
                }
           }, 5);
					  
            
						
                 }
             });
	   }
	
	// slider event display Starts
	if(jQuery('.upcoming-event').length >0 || jQuery('.upcoming-event-single').length >0){
		
		if(jQuery('.upcoming-event').length !==0){
		   eventid = jQuery('.upcoming-event').attr('event')
		   }
		if(jQuery('.upcoming-event-single').length !==0){
		   eventid = jQuery('.upcoming-event-single').attr('event')
		   }
		  jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'show_upcoming_event',
                     event: eventid,
                      
                 },
                 success: function(response) { 
					 	response = jQuery.parseJSON( response )
					 if(response.eventstatus=='expired'){
						jQuery('.big-round-event').hide()
					 }else{
						 
						jQuery('.big-round-event').show()
						      	jQuery('.upcoming-event').append(response.html)
                      	jQuery('.upcoming-event-single').append(response.html)
                      	//jQuery('.upcoming-event-date').html(response.eventdate) 
					   // jQuery('.upcoming-event-date').css('background-image', 'url(' + response.eventfeature + ')');
					    jQuery('.rev-small-circle').css('background-image', 'url(' + response.eventfeature + ')');
					 	var d = new Date(response.year,response.month,response.day); 
					 	var deadline = new Date(Date.parse(d) + 12 * 24 * 60 * 60 * 1000); 
					      console.log('deadline')
					  console.log(deadline)
						 jQuery('.count-down').each(function( index ) {
 						var c = new Clock(d, function(){   });
						jQuery( this ).html(c.el);
                         });
					 }
                 
						
                 }
             });
	   }
	
	// slider event display Ends
	if(jQuery('#slider-offer-1').length >0){
		jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'show_offer_1',
                     offer: jQuery('#slider-offer-1').attr('offer'),
                      
                 },
                 success: function(response) { 
					 	response = jQuery.parseJSON( response )
                      	jQuery('#slider-offer-1').html(response.html)
                      	jQuery('#offer-small-1').html(response.smallhtml) 
					 jQuery('#offer-1-know-more').attr('href',response.knowmore)
					 
                       
                 }
             });
	}

	jQuery('.doctor-carousel').owlCarousel({
    loop:true,
    margin:10, 
    dots:true, 
		autoplay:true,
     responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        },1100:{
            items:3
        }
    }
})


	
	jQuery('.cmsmasters_owl_slider').owlCarousel({
    loop:true,
    margin:10, 
    dots:true,
		autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
	jQuery('.doctor-service-carousel').owlCarousel({
     
    margin:10, 
    dots:true,
		autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
		jQuery('.news-events-slider').owlCarousel({
    loop:true,
    margin:10, 
    dots:true,
		autoplay:true,
		nav:true,
			 navText : ['<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-left-48.png" />','<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-right-48.png" />'],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:3
        }
    }
})  
	jQuery('.service-slider').owlCarousel({
    loop:true,
    margin:10, 
    dots:true,
		autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:3
        }
    }
})  
		jQuery('.testimonial-slide').owlCarousel({
    loop:true,
    margin:10, 
    dots:true,
		autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
	jQuery('.before-after-slide').owlCarousel({
   items : 2,
     loop  : true,
     margin : 50,
     nav    : true,
     smartSpeed :900,
		autoplay:true,
     navText : ['<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-left-48.png" />','<img class="left_arrow slick_arrows" src="'+globalvar.assets+'/images/chevron-right-48.png" />'],
		    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:2
        }
    }
})	 
	
	
	
		jQuery('.profile-slider').owlCarousel({
   items : 3,
     loop  : true,
     margin : 60,
     nav    : true,
     smartSpeed :900,
		autoplay:true ,
				    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:3
        }
    }
})	
	jQuery("#btn-find-doctor-btn").click(function(){
    speciality = jQuery("#speciality").val();
    doctorname = jQuery("#doctor-name").val();
	
		if(speciality !=''){
				console.log('sh1')
			link = 'https://qmc-dubai.com/find-a-doctor/'+speciality
		}
		if(speciality ==''  && doctorname !=''){
				console.log('sh2')
			link = 'https://qmc-dubai.com/find-a-doctor/all/?doc='+doctorname
		} 
		if(speciality !='' && doctorname !=''){
				console.log('sh3')
			link = 'https://qmc-dubai.com/find-a-doctor/'+speciality+'/?doc='+doctorname
		}  
		  location.href = link
			console.log(link)
});
})
