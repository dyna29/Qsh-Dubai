jQuery( document ).ready(function() {
 jQuery("#confirm-booking").click(function() {
		 ret = confirm('Are you sure you want to confirm the booking?')
		if(ret){
		jQuery('.success').hide() 
	 
 
             var submitBtn = jQuery(this)
             submitBtn.hide()
             submitBtn.after("<img src='" + globalvar.assets + "/images/icons/preloader.gif' width='50px' class='ajax-loader'>")
booking_notes = jQuery('#booking-notes').val()
			booking_id = jQuery('#booking_id').val()
			console.log('booking_id'+booking_id)
             jQuery.ajax({
                 url: globalvar.ajax_url,
                 type: 'post',
                 data: {
                     action: 'send_booking_confirmation',
                     booking_notes:booking_notes ,
                     booking_id:booking_id ,
                 },
                 success: function(response) { 
                     jQuery('.ajax-loader').remove()
                     submitBtn.show()
					  if (response == 1 ){
					  
					    jQuery('.success').html("Booking Confirmation Successfully!")
                     jQuery('.success').show()
					  }
                  
					 
             setTimeout(function(){
    location.reload();
    },2000);  


                 }
             });
          }else{
			return false
		}
 
     });
	 
         //  jQuery( "#event-date" ).datepicker();
          // jQuery( "#event-date" ).datepicker("show");
         
})
jQuery(document).ready(function($) {
				 jQuery('.add-image').on('click', function(facility) {
        console.log("add")
        gallery = jQuery(this).attr("gallery")
        console.log('.' + gallery + '-multiple-image')
        jQuery('.' + gallery + '-multiple-image').append('<div class="cp-image-item"><div><input type="hidden" class="regular-text" name="' + gallery + '_image[]" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '_img" value="" /><img width="150px" height="150px" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '_tag" src="' + globalvar.assets + '/images/placeholder.png" /><br/><span class="dashicons dashicons-plus taggr_upload" value="Upload" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '"></span><span class="dashicons dashicons dashicons-no  taggr_delete" value="Delete" id="delete_' + jQuery('.cp-image-item').length + '"></span></div><br><input type="text" class="regular-text" name="' + gallery + '_title[]"  value="" placeholder="Title" /><br><input type="text" class="regular-text" name="' + gallery + '_desc[]"  value="" placeholder="Description"/></div>');
    });

    jQuery('.add-image-phase').on('click', function(facility) {
        console.log("add")
        gallery = jQuery(this).attr("gallery")
        console.log('.' + gallery + '-multiple-image')
        jQuery('.' + gallery + '-multiple-image').append('<div class="cp-image-item"><div><input type="hidden" class="regular-text" name="' + gallery + '_image[]" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '_img" value="" /><img width="150px" height="150px" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '_tag" src="' + globalvar.assets + '/images/placeholder.png" /><br/><span class="dashicons dashicons-plus taggr_upload" value="Upload" id="' + gallery + '_upload_' + jQuery('.cp-image-item').length + '"></span><span class="dashicons dashicons dashicons-no  taggr_delete" value="Delete" id="delete_' + jQuery('.cp-image-item').length + '"></span></div><br><input type="text" class="regular-text" name="' + gallery + '_title[]"  value="" placeholder="Title" /><br><input type="text" class="regular-text" name="' + gallery + '_desc[]"  value="" placeholder="Description"/><br><input type="text" class="regular-text" name="' + gallery + '_title[]"  value="" placeholder="Title" /><br><input type="text" class="regular-text" name="' + gallery + '_location[]"  value="" placeholder="Location"/><br><input type="text" class="regular-text" name="' + gallery + '_construction[]"  value="" placeholder="Construction Status"/><br><input type="text" class="regular-text" name="' + gallery + '_title[]"  value="" placeholder="Title" /><br><input type="text" class="regular-text" name="' + gallery + '_total_units[]"  value="" placeholder="Total Units"/></div>');
    });
    var file_frame;
    jQuery('body').on('click', '.taggr_delete', function(facility) {
        var elem = jQuery(this);
        jQuery(elem).closest('.cp-image-item').remove();
    });
    jQuery('body').on('click', '.taggr_upload', function(facility) {
        var upload_id = jQuery(this).attr("id");

        file_frame = wp.media.frames.file_frame = wp.media({
            title: jQuery(this).data('uploader_title'),
            button: {
                text: jQuery(this).data('uploader_button_text'),
            },
            multiple: false // Set to true to allow multiple files to be selected
        });

        file_frame.on('select', function() {
            var attachment = file_frame.state().get('selection').first().toJSON();
            jQuery('#' + upload_id).removeClass('dashicons-plus').addClass('dashicons-edit');
            jQuery('#' + upload_id + '_img').val(attachment.id);
            jQuery('#' + upload_id + '_tag').attr('src', attachment.url);
        });
        file_frame.on('open', function() {
            var id = jQuery('#' + upload_id + '_img').val();
            var selattachment = wp.media.attachment(id);
            selattachment.fetch();
            file_frame.state().get('selection').add(selattachment ? [selattachment] : []);

        });
        file_frame.open();

    });
			});