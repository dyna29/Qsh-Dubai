<?php
/**
 * @package 	WordPress
 * @subpackage 	Cleanora
 * @version		1.0.0
 * 
 * Child Theme Functions File
 * Created by CMSMasters
 * 
 */

show_admin_bar(false);
pll_register_string( 'Gummy Smile Treatment', 'Gummy Smile Treatment' );pll_register_string( 'Visiting', 'Visiting' );pll_register_string( 'Select Speciality', 'Select Speciality' );pll_register_string( 'Doctor Name', 'Doctor Name' );pll_register_string( 'Search Doctor', 'Search Doctor' );pll_register_string( 'More services', 'More services' );pll_register_string( 'likethisservice', 'Like this service ?' );pll_register_string( 'nodoctorsfound', 'No doctors found' );pll_register_string( 'doctorsprovidingthisservice', 'Doctors providing this service' );pll_register_string( 'available', 'Available' );pll_register_string( 'busy', 'Busy' );pll_register_string( 'clickhere', 'Click Here' );pll_register_string( 'read more', 'Read More' );pll_register_string( 'after', 'After' );pll_register_string( 'before', 'Before' );pll_register_string( 'search', 'Search' );pll_register_string( 'need-support', 'Need support?' );pll_register_string( 'need-support', 'Need support?' );pll_register_string( 'hotline', 'Hotline' );pll_register_string( 'calluson', 'CALL US ON' );pll_register_string( 'email', 'email' );pll_register_string( 'sunday', 'Sunday' );pll_register_string( 'monday', 'Monday' );pll_register_string( 'tuesday', 'Tuesday' );pll_register_string( 'wednesday', 'Wednesday' );pll_register_string( 'thursday', 'Thursday' );pll_register_string( 'friday', 'Friday' );pll_register_string( 'saturday', 'Saturday' );pll_register_string( 'am', 'am' );pll_register_string( 'pm', 'pm' );pll_register_string( 'beforenafter', 'Before & After' );pll_register_string( 'knowmore', 'Know More' );pll_register_string( 'livechat', 'Live Chat' );pll_register_string( 'home', 'Home' );pll_register_string( 'timings', 'Timings' );pll_register_string( 'copyright', 'Copyright © 2020 Quttainah Medical Center. All Rights Reserved' );


//Remove Google ReCaptcha code/badge everywhere apart from select pages
add_action('wp_print_scripts', function () {
	//Add pages you want to allow to array
	if ( !is_page( array( 'contact','some-other-page-with-form' ) ) ){
		wp_dequeue_script( 'google-recaptcha' );
		//wp_dequeue_script( 'google-invisible-recaptcha' );
	}
});
/**
 * Disable the emoji's
 */
function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
 add_filter( 'wp_resource_hints', 'disable_emojis_remove_dns_prefetch', 10, 2 );
}
add_action( 'init', 'disable_emojis' );

/**
 * Filter function used to remove the tinymce emoji plugin.
 * 
 * @param array $plugins 
 * @return array Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}

/**
 * Remove emoji CDN hostname from DNS prefetching hints.
 *
 * @param array $urls URLs to print for resource hints.
 * @param string $relation_type The relation type the URLs are printed for.
 * @return array Difference betwen the two arrays.
 */
function disable_emojis_remove_dns_prefetch( $urls, $relation_type ) {
 if ( 'dns-prefetch' == $relation_type ) {
 /** This filter is documented in wp-includes/formatting.php */
 $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );

$urls = array_diff( $urls, array( $emoji_svg_url ) );
 }

return $urls;
}

function project_dequeue_unnecessary_styles() { 
global $post;
 
        if($post->post_name == 'home-default'){
			 
		   wp_dequeue_script( 'contact-form-7' );
           wp_dequeue_style( 'contact-form-7' ); 
		}
}
add_action( 'wp_enqueue_scripts', 'project_dequeue_unnecessary_styles' );
function cleanora_child_enqueue_styles() {
    wp_enqueue_style('owl-carousel', get_stylesheet_directory_uri() . '/css/owl.carousel.min.css');
    wp_enqueue_style('owl-theme', get_stylesheet_directory_uri() . '/css/owl.theme.default.css'); 
    wp_enqueue_style('cleanora-child-style', get_stylesheet_uri(), array(), '2019050455535491919231', 'screen, print');
    wp_enqueue_script('owl-carousel', get_stylesheet_directory_uri() . '/js/owl.carousel.min.js', array(), '20161929', true); 
    //	wp_enqueue_script( 'chatkit', 'https://unpkg.com/@pusher/chatkit-client@1/dist/web/chatkit.js', array( 'jquery' ), '2.1.2', true );
	//chat disabled wp_enqueue_script( 'chat', get_theme_file_uri( '/js/chat.js'), array( 'chatkit' ), '2.1.7', true );
    wp_enqueue_script('global-var', get_stylesheet_directory_uri() . '/js/script.js', array(),  '201905063244577778', true);    
    $globalvar = array("assets" => get_stylesheet_directory_uri(),"site_url" => site_url(), "ajax_url" => admin_url('admin-ajax.php'));
    wp_localize_script('global-var', 'globalvar', $globalvar);
       $globaltrans = array("cur_lang"=>pll_current_language(),"home" => pll__('Home'),"search" => pll__('Search'),"needsupport" => pll__('Need support?'),"hotline" => pll__('Hotline'),"calluson" => pll__('CALL US ON'),"email" => pll__('email'),"beforenafter" => pll__('Before & After'),"livechat" => pll__('Live Chat'),"timings" => pll__('Timings'),"copyright" => pll__('Copyright © 2020 Quttainah Medical Center. All Rights Reserved'),"likethisservice"=>pll__('Like this service ?'),"moreservices"=>pll__('More services'),"take_tour_url"=>get_permalink(16329));
    wp_localize_script('global-var', 'globaltrans', $globaltrans);
    // Enqueued script with localized data.
       
    wp_enqueue_script('global-var');
   
}

add_action('wp_enqueue_scripts', 'cleanora_child_enqueue_styles', 11);
 function load_custom_wp_admin_style()
{
    wp_register_style('admin-custom-styles', get_stylesheet_directory_uri() . '/css/admin-custom-styles.css', false, '1.0.0');
    wp_enqueue_style('admin-custom-styles');
    wp_register_script('admin-custom-scripts', get_stylesheet_directory_uri() . '/js/admin-custom-scripts.js');
    wp_enqueue_script('admin-custom-scripts');
	    // wp_register_style('jquery-ui-css', get_stylesheet_directory_uri() . '/css/jquery-ui.css', false, '1.0.0');
   // wp_enqueue_style('jquery-ui-css');
   // wp_register_script('jquery-ui', get_stylesheet_directory_uri() . '/js/jquery-ui.js');
   // wp_enqueue_script('jquery-ui');
    $globalvar = array("assets" => get_stylesheet_directory_uri(),"site_url" => site_url(), "ajax_url" => admin_url('admin-ajax.php'));
    wp_localize_script('admin-custom-scripts', 'globalvar', $globalvar);
 
}

add_action('admin_enqueue_scripts', 'load_custom_wp_admin_style');


//common gallery layout
function gallery_layout($post, $gallery, $items = "multiple", $data = 0)
{
    
    if ($post == 0) {
        $file_meta_image = $data;
    } else {
        $file_meta_image = get_post_meta($post->ID, $gallery . '_image', true);
        $file_meta_title = get_post_meta($post->ID, $gallery . '_title', true);
        $file_meta_desc  = get_post_meta($post->ID, $gallery . '_desc', true);
    }
?>
      <div class="<?php
    echo $gallery;
?>-multiple-image">
        <?php
    if (is_array($file_meta_image)) {
        if (count($file_meta_image) == 1) {
            
            foreach ($file_meta_image as $file_meta_image_val) {
                if ($file_meta_image_val == "") {
                    $file_meta_image = "";
                }
            }
        }
        
    }
    
    if (!is_array($file_meta_image)) {
?>
          <div class="cp-image-item">
                <div>
                    <input type="hidden" class="regular-text" name="<?php
        echo $gallery;
?>_image[]" id="<?php
        echo $gallery;
?>_upload_<?php
        echo $i;
?>_img" value="<?php
        echo $file_meta_image;
?>"  />
                    
                    <?php
        if ($file_meta_image != "") {
            $image_attributes = wp_get_attachment_image_src($file_meta_image, 'thumbnail');
            if ($image_attributes) {
?> 
                        <img width="<?php
                echo $image_attributes[1];
?>" height="<?php
                echo $image_attributes[2];
?>" id="<?php
                echo $gallery;
?>_upload_<?php
                echo $i;
?>_tag" src="<?php
                echo $image_attributes[0];
?>" />
                        <?php
            }
        } else {
?>
                      <img width="150px" height="150px" id="<?php
            echo $gallery;
?>_upload_<?php
            echo $i;
?>_tag" src="<?php
            echo get_stylesheet_directory_uri() . '/images/placeholder.png';
?>" />
                        <?php
        }
        
?>
                  
                    <br/>
                    <span class="dashicons dashicons-plus taggr_upload" value="Upload" id="<?php
        echo $gallery;
?>_upload_<?php
        echo $i;
?>"></span>
                    <?php
        if ($items == "multiple") {
?><span class="dashicons dashicons dashicons-no taggr_delete" value="Delete" id="<?php
            echo $gallery;
?>_delete_0"></span><?php
        }
?>
                  
                </div><br>
                <input type="text" class="regular-text" name="<?php
        echo $gallery;
?>_title[]" id="<?php
        echo $gallery;
?>_title_0" value=""  placeholder="Title"/><br>
                <input type="text" class="regular-text" name="<?php
        echo $gallery;
?>_desc[]" id="<?php
        echo $gallery;
?>_title_0" value="" placeholder="Description" />
            </div>
        <?php
    } else {
        
        $i = 0;
        foreach ($file_meta_image as $file_meta_image_val) {
?>
          <div class="cp-image-item">
                <div>
                
                    <input type="hidden" class="regular-text" name="<?php
            echo $gallery;
?>_image[]" id="<?php
            echo $gallery;
?>_upload_<?php
            echo $i;
?>_img" value="<?php
            echo $file_meta_image_val;
?>" />
                    <?php
            $image_attributes = wp_get_attachment_image_src($file_meta_image_val, 'thumbnail');
            if ($image_attributes) {
?> 
                        <img width="<?php
                echo $image_attributes[1];
?>" height="<?php
                echo $image_attributes[2];
?>" id="<?php
                echo $gallery;
?>_upload_<?php
                echo $i;
?>_tag" src="<?php
                echo $image_attributes[0];
?>" />
                        <?php
            }
?>
                  
                    <br/>
                    <span class="dashicons dashicons-edit taggr_upload" value="Upload" id="<?php
            echo $gallery;
?>_upload_<?php
            echo $i;
?>"></span>
                    <?php
            if ($items == "multiple") {
?><span class="dashicons dashicons dashicons-no dashicons dashicons dashicons-no  taggr_delete" value="Delete" id="<?php
                echo $gallery;
?>_delete_<?php
                echo $i;
?>"></span><?php
            }
?>
              </div>    <br>
                <input type="text" class="regular-text" name="<?php
            echo $gallery;
?>_title[]" id="<?php
            echo $gallery;
?>_title_<?php
            echo $i;
?>" value="<?php
            echo $file_meta_title[$i];
?>" placeholder="Title" />        <br>
                <input type="text" class="regular-text" name="<?php
            echo $gallery;
?>_desc[]" id="<?php
            echo $gallery;
?>_title_<?php
            echo $i;
?>" value="<?php
            echo $file_meta_desc[$i];
?>"  placeholder="Description"/>            
            </div>
        <?php
            $i++;
        }
    }
?>
      </div> 
        <?php
    
    if ($items == "multiple") {
?><input type="button" class="add-image" gallery="<?php
        echo $gallery;
?>" value="Add Image" /><?php
    }
?>
       
        <?php
}
function custom_post_init()
{
 
 
 $labels = array(
        'name' => _x('Slider', 'post type general name', 'cleanora'),
        'singular_name' => _x('Slider', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Sliders', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Slider', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Slider', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Slider', 'cleanora'),
        'new_item' => __('New Slider', 'cleanora'),
        'edit_item' => __('Edit Slider', 'cleanora'),
        'view_item' => __('View Slider', 'cleanora'),
        'all_items' => __('All Sliders', 'cleanora'),
        'search_items' => __('Search Sliders', 'cleanora'),
        'parent_item_colon' => __('Parent Sliders:', 'cleanora'),
        'not_found' => __('No Sliders found.', 'cleanora'),
        'not_found_in_trash' => __('No Sliders found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'slider'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('slider', $args);
    $labels = array(
        'name' => _x('Doctor', 'post type general name', 'cleanora'),
        'singular_name' => _x('Doctor', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Doctors', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Doctor', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Doctor', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Doctor', 'cleanora'),
        'new_item' => __('New Doctor', 'cleanora'),
        'edit_item' => __('Edit Doctor', 'cleanora'),
        'view_item' => __('View Doctor', 'cleanora'),
        'all_items' => __('All Doctors', 'cleanora'),
        'search_items' => __('Search Doctors', 'cleanora'),
        'parent_item_colon' => __('Parent Doctors:', 'cleanora'),
        'not_found' => __('No Doctors found.', 'cleanora'),
        'not_found_in_trash' => __('No Doctors found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'doctor'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('doctor', $args);
	   $labels = array(
        'name' => _x('Review', 'post type general name', 'cleanora'),
        'singular_name' => _x('Review', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Reviews', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Review', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Review', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Review', 'cleanora'),
        'new_item' => __('New Review', 'cleanora'),
        'edit_item' => __('Edit Review', 'cleanora'),
        'view_item' => __('View Review', 'cleanora'),
        'all_items' => __('All Reviews', 'cleanora'),
        'search_items' => __('Search Reviews', 'cleanora'),
        'parent_item_colon' => __('Parent Reviews:', 'cleanora'),
        'not_found' => __('No Reviews found.', 'cleanora'),
        'not_found_in_trash' => __('No Reviews found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'review'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('review', $args);
	$labels = array(
        'name' => _x('Offer', 'post type general name', 'cleanora'),
        'singular_name' => _x('Offer', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Offers', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Offer', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Offer', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Offer', 'cleanora'),
        'new_item' => __('New Offer', 'cleanora'),
        'edit_item' => __('Edit Offer', 'cleanora'),
        'view_item' => __('View Offer', 'cleanora'),
        'all_items' => __('All Offers', 'cleanora'),
        'search_items' => __('Search Offers', 'cleanora'),
        'parent_item_colon' => __('Parent Offers:', 'cleanora'),
        'not_found' => __('No Offers found.', 'cleanora'),
        'not_found_in_trash' => __('No Offers found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'offer'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('offer', $args);
	$labels = array(
        'name' => _x('Online Booking', 'post type general name', 'cleanora'),
        'singular_name' => _x('Online Booking', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Online Bookings', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Online Booking', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Online Booking', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Online Booking', 'cleanora'),
        'new_item' => __('New Online Booking', 'cleanora'),
        'edit_item' => __('Edit Online Booking', 'cleanora'),
        'view_item' => __('View Online Booking', 'cleanora'),
        'all_items' => __('All Online Bookings', 'cleanora'),
        'search_items' => __('Search Online Bookings', 'cleanora'),
        'parent_item_colon' => __('Parent Online Bookings:', 'cleanora'),
        'not_found' => __('No Online Bookings found.', 'cleanora'),
        'not_found_in_trash' => __('No Online Bookings found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'booking'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',  
        )
    );
    register_post_type('booking', $args);
	 $labels = array(
        'name' => _x('Enquiry Detail', 'post type general name', 'reynold'),
        'singular_name' => _x('Enquiry Detail', 'post type singular name', 'reynold'),
        'menu_name' => _x('Enquiry Detail', 'admin menu', 'reynold'),
        'name_admin_bar' => _x('Enquiry Detail', 'add new on admin bar', 'reynold'),
        'add_new' => _x('Add New Enquiry Detail', 'hotel', 'reynold'),
        'add_new_item' => __('Add New Enquiry Detail', 'reynold'),
        'new_item' => __('New Enquiry Detail', 'reynold'),
        'edit_item' => __('Edit Enquiry Detail', 'reynold'),
        'view_item' => __('View Enquiry Detail', 'reynold'),
        'all_items' => __('All Enquiry Details', 'reynold'),
        'search_items' => __('Search Enquiry Details', 'reynold'),
        'parent_item_colon' => __('Parent Enquiry Details:', 'reynold'),
        'not_found' => __('No Enquiry Details found.', 'reynold'),
        'not_found_in_trash' => __('No Enquiry Details found in Trash.', 'reynold')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'reynold'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'enquiry-detail'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title', 
            'thumbnail',
            'editor',
            'excerpt'
        )
    );
    register_post_type('enquiry-detail', $args);
    $labels = array(
        'name' => _x('Visiting Doctor', 'post type general name', 'cleanora'),
        'singular_name' => _x('Visiting Doctor', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Visiting Doctors', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Visiting Doctor', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Visiting Doctor', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Visiting Doctor', 'cleanora'),
        'new_item' => __('New Visiting Doctor', 'cleanora'),
        'edit_item' => __('Edit Visiting Doctor', 'cleanora'),
        'view_item' => __('View Visiting Doctor', 'cleanora'),
        'all_items' => __('All Visiting Doctors', 'cleanora'),
        'search_items' => __('Search Visiting Doctors', 'cleanora'),
        'parent_item_colon' => __('Parent Visiting Doctors:', 'cleanora'),
        'not_found' => __('No Visiting Doctors found.', 'cleanora'),
        'not_found_in_trash' => __('No Visiting Doctors found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'visiting-doctor'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('visiting-doctor', $args);
	$labels = array(
        'name' => _x('FAQs', 'post type general name', 'cleanora'),
        'singular_name' => _x('FAQs', 'post type singular name', 'cleanora'),
        'menu_name' => _x('FAQs', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('FAQs', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New FAQs', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New FAQs', 'cleanora'),
        'new_item' => __('New FAQs', 'cleanora'),
        'edit_item' => __('Edit FAQs', 'cleanora'),
        'view_item' => __('View FAQs', 'cleanora'),
        'all_items' => __('All FAQs', 'cleanora'),
        'search_items' => __('Search FAQs', 'cleanora'),
        'parent_item_colon' => __('Parent FAQs:', 'cleanora'),
        'not_found' => __('No FAQs found.', 'cleanora'),
        'not_found_in_trash' => __('No FAQs found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'faqs'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('faqs', $args);   
		$labels = array(
        'name' => _x('Testimonial', 'post type general name', 'cleanora'),
        'singular_name' => _x('Testimonial', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Testimonial', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Testimonial', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Testimonial', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Testimonial', 'cleanora'),
        'new_item' => __('New Testimonial', 'cleanora'),
        'edit_item' => __('Edit Testimonial', 'cleanora'),
        'view_item' => __('View Testimonial', 'cleanora'),
        'all_items' => __('All Testimonial', 'cleanora'),
        'search_items' => __('Search Testimonial', 'cleanora'),
        'parent_item_colon' => __('Parent Testimonial:', 'cleanora'),
        'not_found' => __('No Testimonial found.', 'cleanora'),
        'not_found_in_trash' => __('No Testimonial found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'testimonial'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('testimonial', $args);  
	$labels = array(
        'name' => _x('Before & After', 'post type general name', 'cleanora'),
        'singular_name' => _x('Before & After', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Before & After', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Before & After', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Before & After', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Before & After', 'cleanora'),
        'new_item' => __('New Before & After', 'cleanora'),
        'edit_item' => __('Edit Before & After', 'cleanora'),
        'view_item' => __('View Before & After', 'cleanora'),
        'all_items' => __('All Before & After', 'cleanora'),
        'search_items' => __('Search Before & After', 'cleanora'),
        'parent_item_colon' => __('Parent Before & After:', 'cleanora'),
        'not_found' => __('No Before & After found.', 'cleanora'),
        'not_found_in_trash' => __('No Before & After found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'before-after'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('before-after', $args);   
	$labels = array(
        'name' => _x('News & Events', 'post type general name', 'cleanora'),
        'singular_name' => _x('News & Events', 'post type singular name', 'cleanora'),
        'menu_name' => _x('News & Events', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('News & Events', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New News & Events', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New News & Events', 'cleanora'),
        'new_item' => __('New News & Events', 'cleanora'),
        'edit_item' => __('Edit News & Events', 'cleanora'),
        'view_item' => __('View News & Events', 'cleanora'),
        'all_items' => __('All News & Events', 'cleanora'),
        'search_items' => __('Search News & Events', 'cleanora'),
        'parent_item_colon' => __('Parent News & Events:', 'cleanora'),
        'not_found' => __('No News & Events found.', 'cleanora'),
        'not_found_in_trash' => __('No News & Events found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'news-events'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('news-events', $args);  
	$labels = array(
        'name' => _x('Video Gallery', 'post type general name', 'cleanora'),
        'singular_name' => _x('Video Gallery', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Video Gallery', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Video Gallery', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Video Gallery', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Video Gallery', 'cleanora'),
        'new_item' => __('New Video Gallery', 'cleanora'),
        'edit_item' => __('Edit Video Gallery', 'cleanora'),
        'view_item' => __('View Video Gallery', 'cleanora'),
        'all_items' => __('All Video Gallery', 'cleanora'),
        'search_items' => __('Search Video Gallery', 'cleanora'),
        'parent_item_colon' => __('Parent Video Gallery:', 'cleanora'),
        'not_found' => __('No Video Gallery found.', 'cleanora'),
        'not_found_in_trash' => __('No Video Gallery found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'video-gallery'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('video-gallery', $args);   
	$labels = array(
        'name' => _x('Photo Gallery', 'post type general name', 'cleanora'),
        'singular_name' => _x('Photo Gallery', 'post type singular name', 'cleanora'),
        'menu_name' => _x('Photo Gallery', 'admin menu', 'cleanora'),
        'name_admin_bar' => _x('Photo Gallery', 'add new on admin bar', 'cleanora'),
        'add_new' => _x('Add New Photo Gallery', 'hotel', 'cleanora'),
        'add_new_item' => __('Add New Photo Gallery', 'cleanora'),
        'new_item' => __('New Photo Gallery', 'cleanora'),
        'edit_item' => __('Edit Photo Gallery', 'cleanora'),
        'view_item' => __('View Photo Gallery', 'cleanora'),
        'all_items' => __('All Photo Gallery', 'cleanora'),
        'search_items' => __('Search Photo Gallery', 'cleanora'),
        'parent_item_colon' => __('Parent Photo Gallery:', 'cleanora'),
        'not_found' => __('No Photo Gallery found.', 'cleanora'),
        'not_found_in_trash' => __('No Photo Gallery found in Trash.', 'cleanora')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'cleanora'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'photo-gallery'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('photo-gallery', $args);   
}
add_action('init', 'custom_post_init');
 
function custom_taxonomy_init()
{
        $labels = array(
        'name' => _x('Offer Category', 'taxonomy general name'),
        'singular_name' => _x('Offer Category', 'taxonomy singular name'),
        'search_items' => __('Search Offer Categories'),
        'all_items' => __('All Offer Categories'),
        'parent_item' => __('Parent Offer Category'),
        'parent_item_colon' => __('Parent Offer Category:'),
        'edit_item' => __('Edit Offer Category'),
        'update_item' => __('Update Offer Category'),
        'add_new_item' => __('Add New Offer Category'),
        'new_item_name' => __('New Offer Category'),
        'menu_name' => __('Offer Category')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'offer-category'
        )
    );
    register_taxonomy('offer-category', array(
        'offer'
    ), $args); 
	  $labels = array(
        'name' => _x('Review Type', 'taxonomy general name'),
        'singular_name' => _x('Review Type', 'taxonomy singular name'),
        'search_items' => __('Search Review Types'),
        'all_items' => __('All Review Types'),
        'parent_item' => __('Parent Review Type'),
        'parent_item_colon' => __('Parent Review Type:'),
        'edit_item' => __('Edit Review Type'),
        'update_item' => __('Update Review Type'),
        'add_new_item' => __('Add New Review Type'),
        'new_item_name' => __('New Review Type'),
        'menu_name' => __('Review Type')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'review-type'
        )
    );
    register_taxonomy('review-type', array(
        'review'
    ), $args); 
    
     
	  $labels = array(
        'name' => _x('Speciality', 'taxonomy general name'),
        'singular_name' => _x('Speciality', 'taxonomy singular name'),
        'search_items' => __('Search Specialitys'),
        'all_items' => __('All Specialitys'),
        'parent_item' => __('Parent Speciality'),
        'parent_item_colon' => __('Parent Speciality:'),
        'edit_item' => __('Edit Speciality'),
        'update_item' => __('Update Speciality'),
        'add_new_item' => __('Add New Speciality'),
        'new_item_name' => __('New Speciality'),
        'menu_name' => __('Speciality')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'speciality'
        )
    );
    register_taxonomy('speciality', array(
        'doctor'
    ), $args); 
	  $labels = array(
        'name' => _x('Event Type', 'taxonomy general name'),
        'singular_name' => _x('Event Type', 'taxonomy singular name'),
        'search_items' => __('Search Event Types'),
        'all_items' => __('All Event Types'),
        'parent_item' => __('Parent Event Type'),
        'parent_item_colon' => __('Parent Event Type:'),
        'edit_item' => __('Edit Event Type'),
        'update_item' => __('Update Event Type'),
        'add_new_item' => __('Add New Event Type'),
        'new_item_name' => __('New Event Type'),
        'menu_name' => __('Event Type')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'event-type'
        )
    );
    register_taxonomy('event-type', array(
        'news-events'
    ), $args); 
	
	  $labels = array(
        'name' => _x('Category', 'taxonomy general name'),
        'singular_name' => _x('Category', 'taxonomy singular name'),
        'search_items' => __('Search Categories'),
        'all_items' => __('All Categories'),
        'parent_item' => __('Parent Category'),
        'parent_item_colon' => __('Parent Category:'),
        'edit_item' => __('Edit Category'),
        'update_item' => __('Update Category'),
        'add_new_item' => __('Add New Category'),
        'new_item_name' => __('New Category'),
        'menu_name' => __('Category')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'before-after-category'
        )
    );
    register_taxonomy('before-after-category', array(
        'before-after', 'faqs'
    ), $args); 
}
add_action('init', 'custom_taxonomy_init');
 //CUSTOM FIELDS
function custom_meta_box()
{
    global $post;
 
        add_meta_box('custom_meta_box_doctor', // $id
            'Doctor Information', // $title
            'show_custom_meta_box_doctor', // $callback
            'doctor', // $page
            'normal', // $context
            'high' // $priority
            );
	add_meta_box('custom_meta_box_offer', // $id
            'Offer Information', // $title
            'show_custom_meta_box_offer', // $callback
            'offer', // $page
            'normal', // $context
            'high' // $priority
            );
        add_meta_box('custom_meta_box_photo_gallery', // $id
            'Photo Gallery Information', // $title
            'show_custom_meta_box_photo_gallery', // $callback
            'photo-gallery', // $page
            'normal', // $context
            'high' // $priority
            );
        add_meta_box('custom_meta_box_video_gallery', // $id
            'Video Gallery Information', // $title
            'show_custom_meta_box_video_gallery', // $callback
            'video-gallery', // $page
            'normal', // $context
            'high' // $priority
            );
        add_meta_box('custom_meta_box_before_after', // $id
            'Before & After Information', // $title
            'show_custom_meta_box_before_after', // $callback
            'before-after', // $page
            'normal', // $context
            'high' // $priority
            );   
	    add_meta_box('custom_meta_box_testimonial', // $id
            'Testimonial Information', // $title
            'show_custom_meta_box_testimonial', // $callback
            'testimonial', // $page
            'normal', // $context
            'high' // $priority
            );  
	    add_meta_box('custom_meta_box_online_booking', // $id
            'Online Booking Information', // $title
            'show_custom_meta_box_online_booking', // $callback
            'booking', // $page
            'normal', // $context
            'high' // $priority
            );
      add_meta_box('custom_meta_box_event', // $id
            'Event Information', // $title
            'show_custom_meta_box_event', // $callback
            'news-events', // $page
            'normal', // $context
            'high' // $priority
            );
      add_meta_box('custom_meta_box_timing', // $id
            'Timing Information', // $title
            'show_custom_meta_box_timing', // $callback
            'page', // $page
            'normal', // $context
            'high' // $priority
            );
	 add_meta_box('custom_meta_box_review', // $id
            'Review Information', // $title
            'show_custom_meta_box_review', // $callback
            'review', // $page
            'normal', // $context
            'high' // $priority
            );
}
add_action('add_meta_boxes', 'custom_meta_box');
function show_custom_meta_box_timing()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $saturday_open_1    = get_post_meta($post->ID, 'saturday_open_1', true); 
        $saturday_open_2    = get_post_meta($post->ID, 'saturday_open_2', true); 
        $saturday_open_3    = get_post_meta($post->ID, 'saturday_open_3', true);  
		
        $sunday_open_1    = get_post_meta($post->ID, 'sunday_open_1', true); 
        $sunday_open_2    = get_post_meta($post->ID, 'sunday_open_2', true); 
        $sunday_open_3    = get_post_meta($post->ID, 'sunday_open_3', true);
		
        $monday_open_1    = get_post_meta($post->ID, 'monday_open_1', true); 
        $monday_open_2    = get_post_meta($post->ID, 'monday_open_2', true); 
        $monday_open_3    = get_post_meta($post->ID, 'monday_open_3', true);
		
        $tuesday_open_1    = get_post_meta($post->ID, 'tuesday_open_1', true); 
        $tuesday_open_2    = get_post_meta($post->ID, 'tuesday_open_2', true); 
        $tuesday_open_3    = get_post_meta($post->ID, 'tuesday_open_3', true);
		
        $wednesday_open_1    = get_post_meta($post->ID, 'wednesday_open_1', true); 
        $wednesday_open_2    = get_post_meta($post->ID, 'wednesday_open_2', true); 
        $wednesday_open_3    = get_post_meta($post->ID, 'wednesday_open_3', true);
		
        $thursday_open_1    = get_post_meta($post->ID, 'thursday_open_1', true); 
        $thursday_open_2    = get_post_meta($post->ID, 'thursday_open_2', true); 
        $thursday_open_3    = get_post_meta($post->ID, 'thursday_open_3', true);
	      $saturday_close_1    = get_post_meta($post->ID, 'saturday_close_1', true); 
        $saturday_close_2    = get_post_meta($post->ID, 'saturday_close_2', true); 
        $saturday_close_3    = get_post_meta($post->ID, 'saturday_close_3', true);  
		
        $sunday_close_1    = get_post_meta($post->ID, 'sunday_close_1', true); 
        $sunday_close_2    = get_post_meta($post->ID, 'sunday_close_2', true); 
        $sunday_close_3    = get_post_meta($post->ID, 'sunday_close_3', true);
		
        $monday_close_1    = get_post_meta($post->ID, 'monday_close_1', true); 
        $monday_close_2    = get_post_meta($post->ID, 'monday_close_2', true); 
        $monday_close_3    = get_post_meta($post->ID, 'monday_close_3', true);
		
        $tuesday_close_1    = get_post_meta($post->ID, 'tuesday_close_1', true); 
        $tuesday_close_2    = get_post_meta($post->ID, 'tuesday_close_2', true); 
        $tuesday_close_3    = get_post_meta($post->ID, 'tuesday_close_3', true);
		 
        $wednesday_close_1    = get_post_meta($post->ID, 'wednesday_close_1', true); 
        $wednesday_close_2    = get_post_meta($post->ID, 'wednesday_close_2', true); 
        $wednesday_close_3    = get_post_meta($post->ID, 'wednesday_close_3', true);
		
        $thursday_close_1    = get_post_meta($post->ID, 'thursday_close_1', true); 
        $thursday_close_2    = get_post_meta($post->ID, 'thursday_close_2', true); 
        $thursday_close_3    = get_post_meta($post->ID, 'thursday_close_3', true);
?>

    <!-- my custom value input -->
   
    <?php pll__('Saturday');?>: <br>
	<input type="text" name="saturday_open_1"  id="saturday_open_1"  value="<?php echo $saturday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="saturday_open_2"  id="saturday_open_2"  value="<?php echo $saturday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="saturday_open_3"  id="saturday_open_3"  value="<?php echo $saturday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
    <input type="text" name="saturday_close_1"  id="saturday_close_1"  value="<?php echo $saturday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="saturday_close_2"  id="saturday_close_2"  value="<?php echo $saturday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="saturday_close_3"  id="saturday_close_3"  value="<?php echo $saturday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
    Sunday: <br>
	<input type="text" name="sunday_open_1"  id="sunday_open_1"  value="<?php echo $sunday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="sunday_open_2"  id="sunday_open_2"  value="<?php echo $sunday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="sunday_open_3"  id="sunday_open_3"  value="<?php echo $sunday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
<input type="text" name="sunday_close_1"  id="sunday_close_1"  value="<?php echo $sunday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="sunday_close_2"  id="sunday_close_2"  value="<?php echo $sunday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="sunday_close_3"  id="sunday_close_3"  value="<?php echo $sunday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
    Monday: <br>
	<input type="text" name="monday_open_1"  id="monday_open_1"  value="<?php echo $monday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="monday_open_2"  id="monday_open_2"  value="<?php echo $monday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="monday_open_3"  id="monday_open_3"  value="<?php echo $monday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
<input type="text" name="monday_close_1"  id="monday_close_1"  value="<?php echo $monday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="monday_close_2"  id="monday_close_2"  value="<?php echo $monday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="monday_close_3"  id="monday_close_3"  value="<?php echo $monday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
    Tuesday: <br>
	<input type="text" name="tuesday_open_1"  id="tuesday_open_1"  value="<?php echo $tuesday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="tuesday_open_2"  id="tuesday_open_2"  value="<?php echo $tuesday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="tuesday_open_3"  id="tuesday_open_3"  value="<?php echo $tuesday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
<input type="text" name="tuesday_close_1"  id="tuesday_close_1"  value="<?php echo $tuesday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="tuesday_close_2"  id="tuesday_close_2"  value="<?php echo $tuesday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="tuesday_close_3"  id="tuesday_close_3"  value="<?php echo $tuesday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
    Wednesday: <br>
	<input type="text" name="wednesday_open_1"  id="wednesday_open_1"  value="<?php echo $wednesday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="wednesday_open_2"  id="wednesday_open_2"  value="<?php echo $wednesday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="wednesday_open_3"  id="wednesday_open_3"  value="<?php echo $wednesday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
<input type="text" name="wednesday_close_1"  id="wednesday_close_1"  value="<?php echo $wednesday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="wednesday_close_2"  id="wednesday_close_2"  value="<?php echo $wednesday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="wednesday_close_3"  id="wednesday_close_3"  value="<?php echo $wednesday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
    Thursday: <br>
	<input type="text" name="thursday_open_1"  id="thursday_open_1"  value="<?php echo $thursday_open_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="thursday_open_2"  id="thursday_open_2"  value="<?php echo $thursday_open_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="thursday_open_3"  id="thursday_open_3"  value="<?php echo $thursday_open_3;?>"  class="ve_input vsmall">&nbsp; - &nbsp;
<input type="text" name="thursday_close_1"  id="thursday_close_1"  value="<?php echo $thursday_close_1;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="thursday_close_2"  id="thursday_close_2"  value="<?php echo $thursday_close_2;?>"  class="ve_input vsmall">&nbsp;
	<input type="text" name="thursday_close_3"  id="thursday_close_3"  value="<?php echo $thursday_close_3;?>"  class="ve_input vsmall">&nbsp;
	<br>
  
 
<br> 
  
    <?php  
}

 function show_custom_meta_box_review()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $rating    = get_post_meta($post->ID, 'rating', true); 
        $headline    = get_post_meta($post->ID, 'headline', true); 
        $reviewer_name    = get_post_meta($post->ID, 'reviewer_name', true);  
        $approve_review    = get_post_meta($post->ID, 'approve_review', true);   $service_id    = get_post_meta($post_id, 'service_id', true);  
?>

    <!-- my custom value input -->
   
<b>Review for service :</b><br>  <?php echo  ($service_id) ?>  <br>
<b>Rating:</b><br>  <?php echo $rating ?> / 5 <br>
    <b>Headline:</b><br>  <?php echo $headline ?> / 5 <br>
    <b>Reviewer Name:</b><br>  <?php echo $reviewer_name ?> / 5 <br> 
  <b>Approve:</b> <br><select  name="approve_review" > 
	  <option value="No" class="ve_input" <?php   if($approve_review=='No') { echo 'selected'; } ?>>No</option>  
 	  <option value="Yes" class="ve_input" <?php   if($approve_review=='Yes') { echo 'selected'; } ?>>Yes</option></select><br>
  
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_review($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    
        //so our basic checking is done, now we can grab what we've passed from our newly created form
        $approve_review    = $_POST['approve_review'];
      
       
        
        update_post_meta($post_id, 'approve_review', $approve_review);  
	 
    
    
}
add_action('save_post', 'save_meta_fields_review');
add_action('new_to_publish', 'save_meta_fields_review');

add_filter( 'manage_edit-review_columns', 'my_edit_review_columns' ) ;

function my_edit_review_columns( $columns ) {

   $columns['approved'] = __( 'Approved' );
   $columns['service_id'] = __( 'Service Name' );
 

    return $columns;
}

function new_modify_review_table_row( $column, $post_id ) {
	
        $approve_review    = get_post_meta($post_id, 'approve_review', true);  
        $service_id    = get_post_meta($post_id, 'service_id', true);  
    switch ($column) {
        case 'approved' :
            echo $approve_review;
            break;
        case 'service_id' :
            echo get_the_title($service_id);
            break;
        default:
    } 
}
add_filter( 'manage_review_posts_custom_column', 'new_modify_review_table_row', 10, 3 );

//now we are saving the data
function  save_meta_fields_timing($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
 
        //so our basic checking is done, now we can grab what we've passed from our newly created form
   
		$saturday_open_1 = $_REQUEST['saturday_open_1']; 
		$saturday_open_2 = $_REQUEST['saturday_open_2']; 
		$saturday_open_3 = $_REQUEST['saturday_open_3']; 
		$sunday_open_1 = $_REQUEST['sunday_open_1']; 
		$sunday_open_2 = $_REQUEST['sunday_open_2']; 
		$sunday_open_3 = $_REQUEST['sunday_open_3']; 
		$monday_open_1 = $_REQUEST['monday_open_1']; 
		$monday_open_2 = $_REQUEST['monday_open_2']; 
		$monday_open_3 = $_REQUEST['monday_open_3']; 
		$tuesday_open_1 = $_REQUEST['tuesday_open_1']; 
		$tuesday_open_2 = $_REQUEST['tuesday_open_2']; 
		$tuesday_open_3 = $_REQUEST['tuesday_open_3']; 
		$wednesday_open_1 = $_REQUEST['wednesday_open_1']; 
		$wednesday_open_2 = $_REQUEST['wednesday_open_2']; 
		$wednesday_open_3 = $_REQUEST['wednesday_open_3']; 
		$thursday_open_1 = $_REQUEST['thursday_open_1']; 
		$thursday_open_2 = $_REQUEST['thursday_open_2']; 
		$thursday_open_3 = $_REQUEST['thursday_open_3']; 
	  		$saturday_close_1 = $_REQUEST['saturday_close_1']; 
		$saturday_close_2 = $_REQUEST['saturday_close_2']; 
		$saturday_close_3 = $_REQUEST['saturday_close_3']; 
		$sunday_close_1 = $_REQUEST['sunday_close_1']; 
		$sunday_close_2 = $_REQUEST['sunday_close_2']; 
		$sunday_close_3 = $_REQUEST['sunday_close_3']; 
		$monday_close_1 = $_REQUEST['monday_close_1']; 
		$monday_close_2 = $_REQUEST['monday_close_2']; 
		$monday_close_3 = $_REQUEST['monday_close_3']; 
		$tuesday_close_1 = $_REQUEST['tuesday_close_1']; 
		$tuesday_close_2 = $_REQUEST['tuesday_close_2']; 
		$tuesday_close_3 = $_REQUEST['tuesday_close_3']; 
		$wednesday_close_1 = $_REQUEST['wednesday_close_1']; 
		$wednesday_close_2 = $_REQUEST['wednesday_close_2']; 
		$wednesday_close_3 = $_REQUEST['wednesday_close_3']; 
		$thursday_close_1 = $_REQUEST['thursday_close_1']; 
		$thursday_close_2 = $_REQUEST['thursday_close_2']; 
		$thursday_close_3 = $_REQUEST['thursday_close_3']; 
       
        
        update_post_meta($post_id, 'saturday_open_1', $saturday_open_1); 
        update_post_meta($post_id, 'saturday_open_2', $saturday_open_2); 
        update_post_meta($post_id, 'saturday_open_3', $saturday_open_3); 
        
        update_post_meta($post_id, 'sunday_open_1', $sunday_open_1); 
        update_post_meta($post_id, 'sunday_open_2', $sunday_open_2); 
        update_post_meta($post_id, 'sunday_open_3', $sunday_open_3); 
        
        update_post_meta($post_id, 'monday_open_1', $monday_open_1); 
        update_post_meta($post_id, 'monday_open_2', $monday_open_2); 
        update_post_meta($post_id, 'monday_open_3', $monday_open_3); 
        
        update_post_meta($post_id, 'tuesday_open_1', $tuesday_open_1); 
        update_post_meta($post_id, 'tuesday_open_2', $tuesday_open_2); 
        update_post_meta($post_id, 'tuesday_open_3', $tuesday_open_3); 
        
        update_post_meta($post_id, 'wednesday_open_1', $wednesday_open_1); 
        update_post_meta($post_id, 'wednesday_open_2', $wednesday_open_2); 
        update_post_meta($post_id, 'wednesday_open_3', $wednesday_open_3); 
        
        update_post_meta($post_id, 'thursday_open_1', $thursday_open_1); 
        update_post_meta($post_id, 'thursday_open_2', $thursday_open_2); 
        update_post_meta($post_id, 'thursday_open_3', $thursday_open_3); 
	   update_post_meta($post_id, 'saturday_close_1', $saturday_close_1); 
        update_post_meta($post_id, 'saturday_close_2', $saturday_close_2); 
        update_post_meta($post_id, 'saturday_close_3', $saturday_close_3); 
        
        update_post_meta($post_id, 'sunday_close_1', $sunday_close_1); 
        update_post_meta($post_id, 'sunday_close_2', $sunday_close_2); 
        update_post_meta($post_id, 'sunday_close_3', $sunday_close_3); 
        
        update_post_meta($post_id, 'monday_close_1', $monday_close_1); 
        update_post_meta($post_id, 'monday_close_2', $monday_close_2); 
        update_post_meta($post_id, 'monday_close_3', $monday_close_3); 
        
        update_post_meta($post_id, 'tuesday_close_1', $tuesday_close_1); 
        update_post_meta($post_id, 'tuesday_close_2', $tuesday_close_2); 
        update_post_meta($post_id, 'tuesday_close_3', $tuesday_close_3); 
        
        update_post_meta($post_id, 'wednesday_close_1', $wednesday_close_1); 
        update_post_meta($post_id, 'wednesday_close_2', $wednesday_close_2); 
        update_post_meta($post_id, 'wednesday_close_3', $wednesday_close_3); 
        
        update_post_meta($post_id, 'thursday_close_1', $thursday_close_1); 
        update_post_meta($post_id, 'thursday_close_2', $thursday_close_2); 
        update_post_meta($post_id, 'thursday_close_3', $thursday_close_3); 
    
    
}
add_action('save_post', 'save_meta_fields_timing');
add_action('new_to_publish', 'save_meta_fields_timing');
function show_custom_meta_box_online_booking()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
	  
        $speciality    = get_post_meta($post->ID, 'speciality', true); 
        $firstname    = get_post_meta($post->ID, 'firstname', true);  
        $familyname    = get_post_meta($post->ID, 'familyname', true);  
        $mobile    = get_post_meta($post->ID, 'mobile', true);  
        $dob    = get_post_meta($post->ID, 'dob', true);  
        $phour    = get_post_meta($post->ID, 'phour', true); 
        $ampm    = get_post_meta($post->ID, 'ampm', true); 
        $preffereddate    = get_post_meta($post->ID, 'preffereddate', true); 
        $booking_status    = get_post_meta($post->ID, 'booking_status', true); 
        $booking_notes    = get_post_meta($post->ID, 'booking_notes', true); 
?>

    <!-- my custom value input -->
   
    <b>Speciality:</b> <?php echo $speciality;?>  <br><br>
    <b>Name:</b> <?php echo $firstname;?>  <br><br>
    <b>Family Name:</b> <?php echo $familyname;?>  <br><br>
    <b>Mobile Number:</b> <?php echo $mobile;?>  <br><br>
    <b>Preferred Time:</b> <?php echo $phour;?>  <?php echo $ampm;?> <br><br>
		<b> Preferred Date:</b> <?php echo $preffereddate;?>  <br><br>
<input type='hidden' id='booking_id' value='<?php echo $post->ID;?>'>
<?php if($booking_status!='Confirmed')
		{
			?>

<b>Notes:</b> <textarea class='admin-input-field' id='booking-notes'></textarea><br><br>
<input type='button' id='confirm-booking' class="button button-primary" value='Confirm Booking'>
		<div class='success'></div>
  <?php  } else{
			?>
<b class='book-highlight'>Booking Confirmed</b> <br>
		<?php if($booking_status!='')
		{
			?>
<span class='book-notes'><b>Booking Notes:</b><?php echo $booking_notes;?> </span> 
<?php
				}
		}
			?>
 
<br> 
  
    <?php  
}
function show_custom_meta_box_event()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $event_date    = get_post_meta($post->ID, 'event_date', true); 
        $event_sub_title    = get_post_meta($post->ID, 'event_sub_title', true); 
        $event_location    = get_post_meta($post->ID, 'event_location', true); 
        $event_link    = get_post_meta($post->ID, 'event_link', true); 
?>

    <!-- my custom value input -->
   
    Event Date: <br><input type="text" name="event_date"  id="event-date"  value="<?php echo $event_date;?>"  class="ve_input">  <br>
 Event Sub Title: <br><input type="text" name="event_sub_title"  id="event-sub-title"  value="<?php echo $event_sub_title;?>"  class="ve_input">  <br>
 Event Location: <br><input type="text" name="event_location"  id="event-location"  value="<?php echo $event_location;?>"  class="ve_input">  <br>
 Event Read More Link: <br><input type="text" name="event_link"  id="event-link"  value="<?php echo $event_link;?>"  class="ve_input">  <br>
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_event($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
 
        //so our basic checking is done, now we can grab what we've passed from our newly created form
   
		$event_date = $_REQUEST['event_date'];
		$event_sub_title = $_REQUEST['event_sub_title'];
		$event_location = $_REQUEST['event_location'];
		$event_link = $_REQUEST['event_link'];
	  
       
        
        update_post_meta($post_id, 'event_date', $event_date); 
        update_post_meta($post_id, 'event_sub_title', $event_sub_title); 
        update_post_meta($post_id, 'event_location', $event_location); 
        update_post_meta($post_id, 'event_link', $event_link); 
	 
    
    
}
add_action('save_post', 'save_meta_fields_event');
add_action('new_to_publish', 'save_meta_fields_event');
function show_custom_meta_box_doctor()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $designation    = get_post_meta($post->ID, 'designation', true); 
        $available    = get_post_meta($post->ID, 'available', true); 
        $visiting    = get_post_meta($post->ID, 'visiting', true); 
        $visitingdate    = get_post_meta($post->ID, 'visitingdate', true); 
        $snapchat    = get_post_meta($post->ID, 'snapchat', true); 
        $instagram    = get_post_meta($post->ID, 'instagram', true); 
        $services    = get_post_meta($post->ID, 'services', true); 
	$services = maybe_unserialize($services);

	if(!is_array($services)){
		$services = array();
	}
	 
foreach ($services as $key => $var) {
    $services[$key] = (int)$var;
}
	 
	
	
		
		
?>

    <!-- my custom value input -->
   
    Designation: <br><input type="text" name="designation" value="<?php
        echo $designation;
?>" class="ve_input"> <br>  Services: 
<?php 
	$args = array(	'post_type' => 'project',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						 
						while($loop->have_posts()) : $loop->the_post();
					 		
?>
<br><input type="checkbox" name="services[]" value="<?php  echo get_the_ID();?>" <?php if(in_array( (int)get_the_ID(),$services)){   ?> checked <?php } ?>class="ve_input">  <?php  echo get_the_title();?>

<?php
		endwhile;
						wp_reset_postdata(); 
					}				
						?><br><br>  
  Available: <br><select  name="available" >
>	  <option value="Yes" class="ve_input" <?php   if($available=='Yes') { echo 'selected'; } ?>>Yes</option> 
	  <option value="No" class="ve_input" <?php   if($available=='No') { echo 'selected'; } ?>>No</option>  </select><br>
  Visiting: <br><select  name="visiting" >
>	  <option value="No" class="ve_input" <?php   if($visiting=='No') { echo 'selected'; } ?>>No</option> 
	  <option value="Yes" class="ve_input" <?php   if($visiting=='Yes') { echo 'selected'; } ?>>Yes</option>  </select><br>
  Visiting Date: <br><input type="text" name="visitingdate" value="<?php
        echo $visitingdate;
?>" class="ve_input">  <br>
    Snapchat: <br><input type="text" name="snapchat" value="<?php
        echo $snapchat;
?>" class="ve_input">  <br>
    Instagram: <br><input type="text" name="instagram" value="<?php
        echo $instagram;
?>" class="ve_input">  <br>
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_doctor($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    
        //so our basic checking is done, now we can grab what we've passed from our newly created form
        $designation    = $_POST['designation'];
        $available    = $_POST['available']; 
        $visiting    = $_POST['visiting']; 
        $visitingdate    = $_POST['visitingdate']; 
		$snapchat    = $_POST['snapchat'];
	
		$instagram   = $_POST['instagram'];
		$services   = $_POST['services'];
 
        update_post_meta($post_id, 'visitingdate', $visitingdate); 
        update_post_meta($post_id, 'designation', $designation); 
        update_post_meta($post_id, 'available', $available); 
        update_post_meta($post_id, 'visiting', $visiting); 
        update_post_meta($post_id, 'snapchat', $snapchat); 
        update_post_meta($post_id, 'instagram', $instagram); 
        update_post_meta($post_id, 'services', serialize($services));
	 
    
    
}
add_action('save_post', 'save_meta_fields_doctor');
add_action('new_to_publish', 'save_meta_fields_doctor');
function show_custom_meta_box_offer()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $line_1    = get_post_meta($post->ID, 'line_1', true); 
        $line_2    = get_post_meta($post->ID, 'line_2', true); 
        $line_3    = get_post_meta($post->ID, 'line_3', true);   
        $line_4    = get_post_meta($post->ID, 'line_4', true);   
        $line_5    = get_post_meta($post->ID, 'line_5', true); 
        $offer_info_line_1    = get_post_meta($post->ID, 'offer_info_line_1', true); 
        $offer_info_line_2    = get_post_meta($post->ID, 'offer_info_line_2', true); 
?>

    <!-- my custom value input -->
   
    Offer small bubble line 1: <br><input type="text" name="line_1" value="<?php
        echo $line_1;
?>" class="ve_input">  <br> 
    Offer small bubble line 2: <br><input type="text" name="line_2" value="<?php
        echo $line_2;
?>" class="ve_input">  <br> 
    Offer small bubble line 3: <br><input type="text" name="line_3" value="<?php
        echo $line_3;
?>" class="ve_input">  <br> 
    Offer small bubble line 4: <br><input type="text" name="line_4" value="<?php
        echo $line_4;
?>" class="ve_input">  <br> 
    Offer small bubble line 5: <br><input type="text" name="line_5" value="<?php
        echo $line_5;
?>" class="ve_input">  <br> 
    Offer Info line 1: <br><input type="text" name="offer_info_line_1" value="<?php
        echo $offer_info_line_1;
?>" class="ve_input">  <br> 
    Offer Info line 2: <br><input type="text" name="offer_info_line_2" value="<?php
        echo $offer_info_line_2;
?>" class="ve_input">  <br> 
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_offer($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    
        //so our basic checking is done, now we can grab what we've passed from our newly created form
        $line_1    = $_POST['line_1'];
        $line_2  = $_POST['line_2']; 
		$line_3= $_POST['line_3'];
		$line_4= $_POST['line_4'];
		$line_5= $_POST['line_5'];
		$offer_info_line_1= $_POST['offer_info_line_1'];
		$offer_info_line_2= $_POST['offer_info_line_2'];
	 
       
        
        update_post_meta($post_id, 'line_1', $line_1); 
        update_post_meta($post_id, 'line_2', $line_2); 
        update_post_meta($post_id, 'line_3', $line_3);   
        update_post_meta($post_id, 'line_4', $line_4);   
        update_post_meta($post_id, 'line_5', $line_5);   
        update_post_meta($post_id, 'offer_info_line_1', $offer_info_line_1);  
        update_post_meta($post_id, 'offer_info_line_2', $offer_info_line_2);  
	 
    
    
}
add_action('save_post', 'save_meta_fields_offer');
add_action('new_to_publish', 'save_meta_fields_offer');
function show_custom_meta_box_photo_gallery()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $featured    = get_post_meta($post->ID, 'featured', true); 
?>

    <!-- my custom value input -->
   
    Featured: <br><input type="checkbox" name="featured" value="1" <?php if($featured == 1){ ?>checked<?php } ?> class="ve_input">  <br>
 
<br> 
  
    <?php  
}
function show_custom_meta_box_video_gallery()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $featured    = get_post_meta($post->ID, 'featured', true); 
?>

    <!-- my custom value input -->
   
    Featured: <br><input type="checkbox" name="featured" value="1" <?php if($featured == 1){ ?>checked<?php } ?> class="ve_input">  <br>
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_video_gallery($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    $featured = 0;
        //so our basic checking is done, now we can grab what we've passed from our newly created form
       if(isset($_REQUEST['featured'])){
		$featured = $_REQUEST['featured'];
	   }
       
        
        update_post_meta($post_id, 'featured', $featured); 
	 
    
    
}
add_action('save_post', 'save_meta_fields_video_gallery');
add_action('new_to_publish', 'save_meta_fields_video_gallery');
//now we are saving the data
function  save_meta_fields_photo_gallery($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    $featured = 0;
        //so our basic checking is done, now we can grab what we've passed from our newly created form
       if(isset($_REQUEST['featured'])){
		$featured = $_REQUEST['featured'];
	   }
       
        
        update_post_meta($post_id, 'featured', $featured); 
	 
    
    
}
add_action('save_post', 'save_meta_fields_photo_gallery');
add_action('new_to_publish', 'save_meta_fields_photo_gallery');
 
function show_custom_meta_box_before_after()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $featured    = get_post_meta($post->ID, 'featured', true); 
        $floatingfeatured    = get_post_meta($post->ID, 'floatingfeatured', true); 
        $profile    = get_post_meta($post->ID, 'profile', true); 
        $batype    = get_post_meta($post->ID, 'batype', true); 
        $basize    = get_post_meta($post->ID, 'basize', true); 
        $scar_location    = get_post_meta($post->ID, 'scar_location', true); 
?>

    <!-- my custom value input -->
   
    Floating Featured: <input type="checkbox" name="floatingfeatured" value="1" <?php if($floatingfeatured == 1){ ?>checked<?php } ?> class="ve_input"> <br> <br>
    Featured: <input type="checkbox" name="featured" value="1" <?php if($featured == 1){ ?>checked<?php } ?> class="ve_input">  <br> <br>  Scar Location: <br><input type="text" name="scar_location" value="<?php
        echo $scar_location;
?>" class="ve_input"> <br> <br>
    Profile: <br> <input type="text" name="profile" value="<?php
        echo $profile;
?>" class="ve_input">  <br> <br>
    Type: <br> <input type="text" name="batype" value="<?php
        echo $batype;
?>" class="ve_input"> <br>  <br>
    Size: <br> <input type="text" name="basize" value="<?php
        echo $basize;
?>" class="ve_input"> <br>  <br>
  Before Photo: <br> <?php gallery_layout($post, 'before_photo', 'single');?> 
<br>  <br>
  After Photo: <br> <?php gallery_layout($post, 'after_photo', 'single');?> 
 <br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_before_after($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    $featured = 0;
    $floatingfeatured = 0;
        //so our basic checking is done, now we can grab what we've passed from our newly created form
       if(isset($_REQUEST['floatingfeatured'])){
		$floatingfeatured = $_REQUEST['floatingfeatured'];
	   }
           if(isset($_REQUEST['featured'])){
		$featured = $_REQUEST['featured'];
	   }
         $scar_location    = $_POST['scar_location'];
        $profile    = $_POST['profile']; 
		$batype    = $_POST['batype'];
	
		$basize   = $_POST['basize'];
       
        
        update_post_meta($post_id, 'scar_location', $scar_location); 
        update_post_meta($post_id, 'profile', $profile); 
        update_post_meta($post_id, 'batype', $batype); 
        update_post_meta($post_id, 'basize', $basize); 
        update_post_meta($post_id, 'featured', $featured); 
        update_post_meta($post_id, 'floatingfeatured', $floatingfeatured); 
	   if (isset($_POST['before_photo_image'])) {
        update_post_meta($_REQUEST['post_ID'], 'before_photo_image', $_POST['before_photo_image']);
        update_post_meta($_REQUEST['post_ID'], 'before_photo_title', $_POST['before_photo_title']);
    } 
	   if (isset($_POST['after_photo_image'])) {
        update_post_meta($_REQUEST['post_ID'], 'after_photo_image', $_POST['after_photo_image']);
        update_post_meta($_REQUEST['post_ID'], 'after_photo_title', $_POST['after_photo_title']);
    } 
    
    
}
add_action('save_post', 'save_meta_fields_before_after');
add_action('new_to_publish', 'save_meta_fields_before_after');

function show_custom_meta_box_testimonial()
{
    global $post;  
        // Use nonce for verification to secure data sending
        wp_nonce_field(basename(__FILE__), 'wpse_our_nonce');
        $designation    = get_post_meta($post->ID, 'designation', true); 
        $ranking    = get_post_meta($post->ID, 'ranking', true); 
?>

    <!-- my custom value input -->
   
    Designation: <br><input type="text" name="designation" value="<?php
        echo $designation;
?>" class="ve_input">  <br>
    Ranking: <br><select  name="ranking"  class="ve_input">
		<?php for($i=1;$i<=5;$i++){
			?>
		<option value='<?php echo $i;?>' <?php if($i==$ranking){ ?>selected<?php } ?> ><?php echo $i;?></option>
		 
		<?php
		} ?>
</select>  <br>
 
 
<br> 
  
    <?php  
}
//now we are saving the data
function  save_meta_fields_testimonial($post_id)
{
    global $post;
     
        // verify nonce
        if (!isset($_POST['wpse_our_nonce']) || !wp_verify_nonce($_POST['wpse_our_nonce'], basename(__FILE__)))
            return 'nonce not verified';
        
        // check autosave
        if (wp_is_post_autosave($post_id))
            return 'autosave';
        
        //check post revision
        if (wp_is_post_revision($post_id))
            return 'revision';
        
        // check permissions
    
        //so our basic checking is done, now we can grab what we've passed from our newly created form
        $designation    = $_POST['designation'];
        $ranking    = $_POST['ranking'];
       
        
        update_post_meta($post_id, 'ranking', $ranking); 
	 
    
    
}
add_action('save_post', 'save_meta_fields_testimonial');
add_action('new_to_publish', 'save_meta_fields_testimonial');
//SHORTCODES START
//FAQS ON HOME PAGE

function faq_list_home($atts) {
 
					$args = array(	'post_type' => 'faqs',
					'posts_per_page' => 4, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<ul class="faq-list">';
						while($loop->have_posts()) : $loop->the_post();
							$i++;
						$html .= '<li>Q. '.get_the_title().'</li>';
						endwhile;
						wp_reset_postdata();
						$html .= '</ul>';
						$html .= '<a href='.site_url("faqs-list").' class="read-more-float-bottom faqs-more light">'. pll__('Read More').'</a>';
					}
							 
							 
return $html;
}
add_shortcode('faq-list-home', 'faq_list_home');

//FAQS ON HOME PAGE

function faqs_list($atts) {
 
					$args = array(	'post_type' => 'faqs',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						
				$html = '<div class="cmsmasters_toggles toggles_mode_toggle">';
 
						while($loop->have_posts()) : $loop->the_post();
							$i++;
						 
						if($i==1){
							 
							$html .= '<div class="cmsmasters_toggle_wrap current_toggle" data-tags="all ">';
						}else{
							
							$html .= '<div class="cmsmasters_toggle_wrap" data-tags="all ">';
						}
						
						$html .= '<div class="cmsmasters_toggle_title">';
						$html .= '<span class="cmsmasters_toggle_plus">';
						$html .= '<span class="cmsmasters_toggle_plus_hor"></span>';
						$html .= '<span class="cmsmasters_toggle_plus_vert"></span>';
						$html .= '</span>';
						$html .= '<a href="javascript:void(0)">Q. '.get_the_title().'</a>';
						$html .= '</div>';
						if($i==1){
							 
							$html .= '<div class="cmsmasters_toggle" style="display: block !important;">';
						}else{
							
							$html .= '<div class="cmsmasters_toggle" >';
						}
						
						$html .= '<div class="cmsmasters_toggle_inner">';
						$html .=   get_the_content() ; 
						$html .= '</div>';
						$html .= '</div>';
						$html .= '</div> ';
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
						 
					}
							 
							 
return $html;
}
add_shortcode('faqs', 'faqs_list');
//DOCTOR SLIDER
//
//
function doctor_list_home($atts) {
 
					$args = array(	'post_type' => 'doctor',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme doctor-carousel ">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$available = get_post_meta(get_the_ID(),'available',true);
						if($available=='No'){
							 
							$doctorstatus ='<div class="doctor-status Busy">'. pll__('Busy').'</div>';
						}else{
							 
							$doctorstatus ='<div class="doctor-status available">'. pll__('Available').'</div>';
						}
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
							$i++;
						$html .= '<div class="item doctor-slider"><img src="'.$featuredimage[0].'" class="doctor-img">';
						$html .= '<h1>'.get_the_title().'</h1>';
						$html .= '<h5>'.$designation.'</h5>';
						$html .= '<a href='.get_permalink().'>'. pll__('Click Here').'</a>'.$doctorstatus.'';
						
						$html .= '</div>';
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
					}
							 
							 
return $html;
}
add_shortcode('doctor-list-home', 'doctor_list_home');

function doctor_list($atts) {
 $msg = '';

	         
  $speciality = get_query_var('speciality');
 
					$args = array(	'post_type' => 'doctor',
					'posts_per_page' => -1, 
					'orderby'   => 'menu_order', 
					'order' => 'ASC',
					);
	
 
 	      if($speciality !='' && $speciality !='all'){
						$args['tax_query'] =  array(
						array (
							'taxonomy' => 'speciality',
							'field' => 'slug',
							'terms' => $speciality,
						)
						
    		);
			
						 $specialityterm = get_term_by('slug', $speciality, 'speciality'); 
						 $specialitytermname = $specialityterm->name;
						 $msg .= 'Doctors with speciality <span style="color:#59a4b9">'.$specialitytermname.'</span>';
		}
	$args['docname'] = '1';
	 //   if($doctor !=''){
		//				$args['s'] = $doctor;
	//	}
	 
	 	if(isset($_REQUEST['doc'])){
			if($msg !=''){
							$msg .= ' and ';
						}else{
						 $msg .= 'Doctors with ';	
						}
		 $doctor = $_REQUEST['doc'];
		 $msg .= 'name  <span style="color:#59a4b9">'.$doctor.'</span>';
	}
	$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="doctor-listing">';
						 
						while($loop->have_posts()) : $loop->the_post();
					 
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
							$i++;
						$html .= '<div class="doctor-item ">'.$doctorstatus.'<img src="'.$featuredimage[0].'" class="doctor-img">';
						$html .= '<h1>'.get_the_title().'</h1>';
						$html .= '<h5>'.$designation.'</h5>';
						$html .= '<div id="cmsmasters_button_m5jzafoqp" class="read-more button_wrap"><a href="'.get_permalink().'" class="cmsmasters_button"><span>'. pll__('Read More').'</span></a></div>';
						$html .= '</div>';
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
						
					}
					else{
						if($msg == ''){
							$msg = 'No doctors found!';
						}else{
							$msg = $msg.' not found!';
						}
						
						$html = '<div class="doctor-listing"><h3 class="cmsmasters_heading" >'.$msg.'</h3>';
						$html .= '</div>';
						
					}
							 
							 
return $html;
}
//DOCTOR SLIDER
//
//
function visiting_doctor_slide($atts) {
 
					$args = array(	'post_type' => 'doctor',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme doctor-carousel ">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$visiting = get_post_meta(get_the_ID(),'visiting',true);
						$visitingdate = get_post_meta(get_the_ID(),'visitingdate',true);
						if($visiting=='Yes'){
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
							$i++;
						$html .= '<div class="item doctor-slider">'.$doctorstatus.'<img src="'.$featuredimage[0].'" class="doctor-img">';
						$html .= '<h1>'.get_the_title().'</h1>';
						$html .= '<h5>'.$designation.'</h5>';
							if($visitingdate !=''){
									$html .= '<h4>'. pll__('Visiting').': '.$visitingdate.'</h4>';
							}
					
						$html .= '<a href='.get_permalink().'>'. pll__('Click Here').'</a>';
						$html .= '</div>';
						}
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
					}
							 
							 
return $html;
}
add_shortcode('visiting-doctor-slide', 'visiting_doctor_slide');

function service_doctor($atts) {
	
                     global $post;
					 $service_id = $post->ID;
					$args = array(	'post_type' => 'doctor',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
	 
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<hr>';
						$html .= '<h3>'. pll__('Doctors providing this service').': </h3><br>';
						$html .= '<div class="owl-carousel owl-theme doctor-service-carousel ">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$services = get_post_meta(get_the_ID(),'services',true);
						$services = maybe_unserialize(get_post_meta(get_the_ID(),'services',true));
						if(!is_array($services)){
						 $services = array();
						}
						 
						 if(in_array( $service_id,$services)){  
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
							$i++;
						$html .= '<div class="item doctor-slider">'.$doctorstatus.'<img src="'.$featuredimage[0].'" class="doctor-img">';
						$html .= '<h1>'.get_the_title().'</h1>';
						$html .= '<h5>'.$designation.'</h5>';
							if($visitingdate !=''){
									$html .= '<h4>Visitng: '.$visitingdate.'</h4>';
							}
					
						$html .= '<a href='.get_permalink().'>'. pll__('Click Here').'</a>';
						$html .= '</div>';
						}
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
					}
	
	if($i==0){
		$html .= pll__('No doctors found');
	}
	$html .= '<hr>';						 
return $html;
}
add_shortcode('service-doctor', 'service_doctor');
add_shortcode('doctor-list', 'doctor_list');
function visiting_doctor_list($atts) {
 
 
 
					$args = array(	'post_type' => 'doctor',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
	
  
	 
	 
	$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="doctor-listing">';
						 
						while($loop->have_posts()) : $loop->the_post();
					 
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
						$visiting = get_post_meta(get_the_ID(),'visiting',true);
						if($visiting=='Yes'){
							$i++;
						$html .= '<div class="doctor-item ">'.$doctorstatus.'<img src="'.$featuredimage[0].'" class="doctor-img">';
						$html .= '<h1>'.get_the_title().'</h1>';
						$html .= '<h5>'.$designation.'</h5>';
						$html .= '<div id="cmsmasters_button_m5jzafoqp" class="read-more button_wrap"><a href="'.get_permalink().'" class="cmsmasters_button"><span>'. pll__('Read More').'</span></a></div>';
						$html .= '</div>';
						}
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
					}
							 
							 
return $html;
}
add_shortcode('visiting-doctor-list', 'visiting_doctor_list');
function doctor_search($atts) {
  
						$html .= '<div class="doctor-search ">';
						$html .= '<select id="speciality">';
	$specialities = get_terms( array(
    'taxonomy' => 'speciality',
    'hide_empty' => false,
) );
	
 $html .= '<option value="">'. pll__('Select Speciality').'</option>';
	foreach($specialities as $speciality){
 $html .= '<option value="'.$speciality->slug.'">'.$speciality->name.'</option>';
	}
						$html .= '</select>';
						$html .= '<input type="text" id="doctor-name" placeholder="'. pll__('Doctor Name').'">'; 
						$html .= '<div id="cmsmasters_button_550e25dc78" class="button_wrap" id="btn-find-wrap"><a href="javascript:void(0)" class="cmsmasters_button cmsmasters_but_clear_styles cmsmasters_but_icon_dark_bg cmsmasters-icon-dribbble-6"  id="btn-find-doctor-btn"><span>'. pll__('Search Doctor').'</span></a></div>';
					 
						 
						$html .= '</div>';
				 
							 
							 
return $html;
}
add_shortcode('doctor-search', 'doctor_search');
function speciality_list($atts) {
  
						$html .= '<div class="speciality-list ">';
						$html .= '<ul id="speciality-ul">';
	$specialities = get_terms( array(
    'taxonomy' => 'speciality',
    'hide_empty' => false,
) );
	 
	foreach($specialities as $speciality){
 $html .= '<li>'.$speciality->name.'</>';
	}
						$html .= '</ul>';
						 
						 
						$html .= '</div>';
				 
							 
							 
return $html;
}
add_shortcode('speciality-list', 'speciality_list');
//Home Photo Gallery
//
//
function photo_gallery_home($atts) {
 
					$args = array(	'post_type' => 'photo-gallery',
					'posts_per_page' =>1, 
					'meta_query' => array(
										array(
											'key'     => 'featured',
											'value'   => 1,
											'compare' => '=',
										),
									), 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="photo-gallery-box-home">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						 
						$html .= '<div class="pg-home-image"><img src="'.$featuredimage[0].'"></div>';
						$html .= '<h5>'.get_the_title().'</h5>'; 
						$html .= '<a href='.site_url("photo-gallery").' class="read-more-float-bottom light">'. pll__('Read More').'</a>';
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
							 
							 
return $html;
}
add_shortcode('photo-gallery-home', 'photo_gallery_home');
//Home Video Gallery
//
//
function video_gallery_home($atts) {
 
					$args = array(	'post_type' => 'video-gallery',
					'posts_per_page' => 1, 
					'meta_query' => array(
										array(
											'key'     => 'featured',
											'value'   => 1,
											'compare' => '=',
										),
									),
							 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="video-gallery-box-home">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						 
						$html .= '<div class="pg-home-image"><img src="'.$featuredimage[0].'"></div>';
						$html .= '<h5>'.get_the_title().'</h5>'; 
						$html .= '<a href='.site_url("video-gallery").'  class="read-more-float-bottom dark">'. pll__('Read More').'</a>';
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
							 
							 
return $html;
}
add_shortcode('video-gallery-home', 'video_gallery_home');

//Home Before & After  
//
//
function before_after_home($atts) {
 
					 
						$html = '<div class="owl-carousel owl-theme before-after-slide">'; 
						$online=1;
						
						$baterms = get_terms([
    'taxonomy' =>'before-after-category',
    'hide_empty' => false,
]);
	foreach($baterms as $baterm){
		 
	 
				$meta_image = get_wp_term_image($baterm->term_id); 
				  

						if($meta_image !=''){
								$category = wp_get_post_terms(get_the_id(), 'before-after-category',  array("fields" => "names"));
							$html .= '<div class="item home-ba" onclick="location.href=\''.site_url('before-and-after').'/'.$baterm->slug.'\'">'; 
						$html .= '<div class="ba-home-image"><img src="'.$meta_image.'" width="380" height="269"></div>';
						$html .= '<h5>'.$baterm->name.'</h5>';  
						$html .= '</div>';
						}
	}
						
				 
					
							$html .= '</div>';		 
							 
return $html;
}
add_shortcode('before-after-home', 'before_after_home');
//listing Before & After  category
//
function before_after_category($atts) {
 if(isset($_REQUEST['cat'])){
	 $cat = $_REQUEST['cat'];
	 $category = get_term_by('slug', $cat, 'before-after-category');
	 
	 $ba_category = get_terms([
			'taxonomy' => 'before-after-category',
			'hide_empty' => false,
		    'parent'=>$category->term_id
		]);
 }else{
	 $cat = '';
	 $ba_category = get_terms([
			'taxonomy' => 'before-after-category',
			'hide_empty' => false,'parent'=>0
		]);
 }
 
 
		
		foreach($ba_category as $category_item){
			 
			 if (function_exists('get_wp_term_image'))
{
    $meta_image = get_wp_term_image($category_item->term_id); 
    //It will give category/term image url 
}

					 
			$html .= '<div class="before-after-item-grid ">'; 
						$html .= '<div class="offer-home-image"><img src='.$meta_image.' > </div>';
						$html .= '<h5>'.$category_item->name.'</h5>';  
			if($cat ==''){
				$html .= '<a href="'.site_url("before-after-category-list/?cat=".$category_item->slug).'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
			}else{
				$html .= '<a href="'.site_url("before-after-category/".$category_item->slug).'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
			}
						
						$html .= '</div>';
		 
		}
 		 
		 	 
return $html;
}
add_shortcode('before-after-category', 'before_after_category');
//listing Before & After  
//
//
function before_after_listing($atts) {
	
   $surgery_type = get_query_var('surgery_type');
	
	if($surgery_type ==''){
		$cat_id = get_queried_object_id();
		$cat_id = (int) $cat_id;
       $categoryObj = get_term($cat_id); 
      $surgery_type = $categoryObj->slug;
	}
	 
	
 $cat_id = get_queried_object_id();
	if( $surgery_type !=''){
		$surgery_type_term = get_term_by('slug', $surgery_type, 'before-after-category');
	 
					$args = array(	'post_type' => 'before-after',
					'posts_per_page' => -1, 
				 
				  'tax_query' =>  array(
						array (
							'taxonomy' => 'before-after-category',
							'field' => 'slug',
							'terms' =>  $surgery_type,
						)
    		),
							 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$html  = '<input type="hidden" id="beforeafter-header" value="'. $surgery_type_term->name.'"><div class="before-after-listing-container ">';
					if($loop->have_posts()) {
						 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$scar_location = get_post_meta(get_the_ID(),'scar_location',true);
						$before_photo_image = get_post_meta(get_the_ID(),'before_photo_image',true);
						$before_photo_image_src = wp_get_attachment_image_src( $before_photo_image[0], 'full' ); 
						$after_photo_image = get_post_meta(get_the_ID(),'after_photo_image',true);
						$after_photo_image_src = wp_get_attachment_image_src( $after_photo_image[0], 'full' ); 
						$batype = get_post_meta(get_the_ID(),'batype',true);
						$basize = get_post_meta(get_the_ID(),'basize',true);
						$profile = get_post_meta(get_the_ID(),'profile',true);
							$html .= '<div class="before-after-item ">'; 
						$html .= '<div class="text-row header"><div class= "label">'. pll__('Before').'</div><div class= "text">'. pll__('After').'</div></div>'; 
						//$html .= '<div class="ba-home-image before" style="background:url(\''.$before_photo_image_src[0].'\')"> </div>'; 
						//$html .= '<div class="ba-home-image after"  style="background:url(\''.$after_photo_image_src[0].'\')"> </div>'; 
						 $html .= '<div class="ba-home-image before" ><img src ="'.$before_photo_image_src[0].'"></div>'; 
						$html .= '<div class="ba-home-image after"   ><img src ="'.$after_photo_image_src[0].'"></div>'; 
						if($scar_location !=''){
						$html .= '<div class="text-row"><div class= "label">Scar Location</div><div class= "text">'.$scar_location.'</div></div>'; 
						}
							if($batype !=''){
						$html .= '<div class="text-row"><div class= "label">Type</div><div class= "text">'.$batype.'</div></div>'; 
							}
							if($profile !=''){
						$html .= '<div class="text-row"><div class= "label">Profile</div><div class= "text">'.$profile.'</div></div>'; 
							}
							if($basize !=''){
						$html .= '<div class="text-row"><div class= "label">Size</div><div class= "text">'.$basize.'</div></div>'; 
							}
						  
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
					$html .= '</div>';	
	}else{
		 if(isset($_REQUEST['cat'])){
	 $cat = $_REQUEST['cat'];
	 $category = get_term_by('slug', $cat, 'before-after-category');
	 
	 $ba_category = get_terms([
			'taxonomy' => 'before-after-category',
			'hide_empty' => false,
		    'parent'=>$category->term_id
		]);
			 
			 	$html   = '<h1 class="cmsmasters_project_title entry-title before-after-category">'. $category->name.'</h1>';	 	 
 }else{
	 $cat = '';
	 $ba_category = get_terms([
			'taxonomy' => 'before-after-category',
			'hide_empty' => false,'parent'=>0
		]);
			 $html   = '<h1 class="cmsmasters_project_title entry-title before-after-category">'. pll__('Before & After').'</h1>';	
 }
		 
		foreach($ba_category as $category_item){
			 $featured_cat = get_field('featured',$category_item);
			 if(isset($_REQUEST['cat'])){
				 $featured_cat=  'Yes' ;
			 }
			if($featured_cat=='Yes'   ){
							 if (function_exists('get_wp_term_image'))
{
    $meta_image = get_wp_term_image($category_item->term_id); 
    //It will give category/term image url 
}

			
			$html .= '<div class="before-after-item-grid ">'; 
						$html .= '<div class="offer-home-image"><img src='.$meta_image.' > </div>';
						$html .= '<h5>'.$category_item->name.'</h5>';
				if(pll_current_language() =='ar'){ 
			if($cat ==''){
				
					
				
				$html .= '<a href="'.site_url("ar/قبل-وبعد/?cat=".$category_item->slug).'" class="cmsmasters_button">'. pll__('Click to View ').'</a>'; 
			}else{
				$html .= '<a href="'.site_url("ar/قبل-وبعد/".$category_item->slug).'" class="cmsmasters_button">'. pll__('Click to View ').'</a>'; 
			}
				} else{
					if($cat ==''){
				
					
				
				$html .= '<a href="'.site_url("before-and-after/?cat=".$category_item->slug).'" class="cmsmasters_button">'. pll__('Click to View ').'</a>'; 
			}else{
				$html .= '<a href="'.site_url("before-after-category/".$category_item->slug).'" class="cmsmasters_button">'. pll__('Click to View ').'</a>'; 
			}
				}
						
						$html .= '</div>';
			}

		 
		}
	}
 	 		 
		 	 
return $html;
}
add_shortcode('before-after-listing', 'before_after_listing');

//listing News & Events
//
//
function news_events_list($atts) {
 
					$args = array(	'post_type' => 'news-events',
					'posts_per_page' => -1, 
				  'tax_query' =>  array(
						array (
							'taxonomy' => 'event-type',
							'field' => 'slug',
							'terms' => 'past-event',
						)
    		),
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$html .= '<div class="news-events-listing-container ">';
					if($loop->have_posts()) {
						 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
							$html .= '<div class="news-events-item ">'; 
						$html .= '<div class="ne-home-image"><img src="'.$featuredimage[0].'"></div>';
						$html .= '<h5>'.get_the_title().'</h5>';  
						$html .= '<a href="'.get_the_permalink().'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
					$html .= '</div>';		 		 
							 
return $html;
}
add_shortcode('news-events-list', 'news_events_list');

//SLide News & Events
//
//
function news_events_slide($atts) {
 
					$args = array(	'post_type' => 'news-events',
					'posts_per_page' => -1, 
				  'tax_query' =>  array(
						array (
							'taxonomy' => 'event-type',
							'field' => 'slug',
							'terms' => 'past-event',
						)
    		),
					'orderby'   => 'menu_order', 
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$html .= '<div class="news-events-listing-container ">';
					if($loop->have_posts()) {
						 	$html = '<div class="owl-carousel owl-theme news-events-slider ">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						 $playhtml = '';
						   if(get_the_post_video_image( get_the_ID() ) !=""){
	   $featuredimage_thumb_url=  $featuredimage_thumb[0]; //get_the_post_video_image_url( $picture->ID ); 
	    $featuredimage_vurl = get_the_post_video_url( get_the_ID() );
	    $videoclass=' class="video-link"';
	    $playhtml = '<div class="play-icon"><img src="'.get_stylesheet_directory_uri().'/images/play-96.png"></div>';
   } 
							   $featuredimage_url  = $featuredimage[0];
				 
							$html .= '<div class="news-events-item item" onclick="location.href=\''.get_the_permalink().'\'">'; 
						$html .= '<div class="ne-home-image"><img class="newsthumb" src="'.$featuredimage_url.'">'.$playhtml.'</div>';
						$html .= '<h5>'.get_the_title().'</h5>';  
						$html .= '<a href="'.get_the_permalink().'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
						$html .= '</div>';	
					}
					
					$html .= '</div>';		 		 
							 
return $html;
}
add_shortcode('news-events-slide', 'news_events_slide');

//listing Testimonial
//
//
function testimonial_grid($atts) {
 
					$args = array(	'post_type' => 'testimonial',
					'posts_per_page' => -1, 
			 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$html .= '<div class="testimonial-listing-container ">';
					if($loop->have_posts()) {
						 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
							$html .= '<div class="testimonial-item ">'; 
						$html .= '<div class="testimonial-home-image"><div style="background:url(\''.$featuredimage[0].'\');width:100%;height:242px;"></div></div>';
						$html .= '<h5>'.get_the_title().'</h5>';  
						$html .= '<a href="'.get_the_permalink().'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
					$html .= '</div>';		 		 
							 
return $html;
}
add_shortcode('testimonial-grid', 'testimonial_grid');
//Home Testimonial  
//
//
function testimonial_home($atts) {
 
					$args = array(	'post_type' => 'testimonial',
					'posts_per_page' => -1, 
				    'post_status'=>'publish',
							 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme testimonial-slide">'; 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$designation = get_post_meta(get_the_ID(),'designation',true);
						$ranking = get_post_meta(get_the_ID(),'ranking',true);
								$html .= '<div class="item ">'; 
							$html .= '<div class="cmsmasters_quote cmsmasters_owl_slider_item"> ';
							$html .= '<article class="cmsmasters_quote_inner pointer-cursor" onclick="location.href=\''.get_permalink().'\'">';
							$html .= '<figure class="cmsmasters_quote_image"><img width="280" height="280"  src="'.$featuredimage[0].'"></figure>';
							$html .= '<div class="cmsmasters_quote_block"><header class="cmsmasters_quote_header"><h3 class="cmsmasters_quote_title">'.get_the_title().'</h3></header>';
							$html .= '<div class="cmsmasters_quote_subtitle_wrap">';
							$html .= '<h6 class="cmsmasters_quote_subtitle">'.$designation.'</h6></div>';
							$html .= '<div class="cmsmasters_quote_content">';
							$html .= '<p>'.wp_trim_words( get_the_content(), 30, '...' ).'</p>';
							$html .= '</div></div></article> ';

							$html .= '</div>';  
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
							$html .= '</div>';		 
							 
return $html;
}
add_shortcode('testimonial-home', 'testimonial_home');
//Profile Slider  
//
//
function profile_slider($atts) {
 
					$args = array(	'post_type' => 'profile',
					'posts_per_page' => -1, 
				 
							 
					'orderby'   => 'ID',
					'order' => 'DESC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme profile-slider">'; 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						$profile_category = wp_get_object_terms(  get_the_ID(), 'pl-categs', array( 'fields' => 'names' ) );
						 
							$html .= '<div class="item ">'; 
						$html .= '<div class="ba-home-image"><img src="'.$featuredimage[0].'"></div>';
						$html .= '<h5>'.get_the_title().'</h5>';  
						$html .= '<h6>'.$profile_category[0].'</h6>';  
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
							$html .= '</div>';		 
							 
return $html;
}
add_shortcode('profile-slider', 'profile_slider');
function doctor_social_links($atts) {
 
					  global $post;
	
                       $instagram    = get_post_meta($post->ID, 'instagram', true); 
                       $snapchat    = get_post_meta($post->ID, 'snapchat', true); 
						$html = '<div class="doctor-social-links">';
						$html .= '</div>';
						 
				 
							 
							 
return $html;
}
add_shortcode('doctor-social-links', 'doctor_social_links');
function doctor_title_designation($atts) {
 
					  global $post;
	
                       
                       $designation    = get_post_meta($post->ID, 'designation', true); 
						$html = '<div class="doctor-title-designation">';
						 $html .= '<h1>'.get_the_title($post->ID).'</h1>';
						 $html .= '<h5>'.$designation.'</h5>';
						$html .= '</div>';
						 
				 
							 
							 
return $html;
}
add_shortcode('doctor-title-designation', 'doctor_title_designation');
//SHORTCODES ENDS
//
//
 function doctor_page_rules() {
  add_rewrite_rule('before-after-category-list/?([^/]*)', 'index.php?pagename=before-after-category-list&cat=$matches[1]', 'top');
  add_rewrite_rule('find-a-doctor/?([^/]*)', 'index.php?pagename=find-a-doctor&speciality=$matches[1]', 'top');
	  add_rewrite_rule('find-a-doctor/?([^/]*)', 'index.php?pagename=find-a-doctor&speciality=$matches[1]&doc=$matches[2]', 'top');  
  add_rewrite_rule('before-and-after/?([^/]*)', 'index.php?pagename=before-and-after&surgery_type=$matches[1]', 'top');
	 add_rewrite_rule('faq-category/?([^/]*)', 'index.php?pagename=faq-category&faq_category=$matches[1]', 'top');
 }

 function doctor_page_query_vars($vars) {
  $vars[] = 'speciality';
  $vars[] = 'doc';
  $vars[] = 'surgery_type';
  $vars[] = 'faq_category';
  $vars[] = 'cat';
  return $vars;
 }
 
  
 add_action('init', 'doctor_page_rules');
 //add plugin query vars (product_id) to wordpress
 add_filter('query_vars', 'doctor_page_query_vars');
add_action( 'wpcf7_mail_sent', 'your_wpcf7_mail_sent_function' ); 

function your_wpcf7_mail_sent_function( $contact_form ) {
    $title = $contact_form->title;
    $submission = WPCF7_Submission::get_instance();
  
    if ( $submission ) {
    	$posted_data = $submission->get_posted_data();
    }
      
     
 
   if ( 'Book Appointment' == $title ) {
     
    	$speciality = $posted_data['speciality'];
    	$firstname = $posted_data['your-name'];
    	$familyname = $posted_data['family-name'];
    	$mobile = $posted_data['mobile'];
    	$useremail = $posted_data['user-email'];
    	$dob = $posted_data['dob'];
    	$phour = $posted_data['phour'];
    	$ampm = $posted_data['ampm'];
    	$preffereddate = $posted_data['preffereddate'];
    	 $new_post         = array(
        'post_type' => 'booking',
        'post_title' => "Online Booking by " . $firstname . " " .$familyname. "<" . $emailaddress . ">",
        'post_status' => 'publish'
    );
    
    $post_id = wp_insert_post($new_post);
    update_post_meta($post_id, "speciality", $speciality);
    update_post_meta($post_id, "firstname", $firstname);
    update_post_meta($post_id, "familyname", $familyname);
    update_post_meta($post_id, "mobile", $mobile); 
    update_post_meta($post_id, "dob", $dob); 
    update_post_meta($post_id, "phour", $phour); 
    update_post_meta($post_id, "ampm", $ampm);; 
    update_post_meta($post_id, "useremail", $useremail);
    update_post_meta($post_id, "preffereddate", $preffereddate); 
    	/* Put your code here to manipulate the data - simples 😉 */
	   
	   
	    $to        = $useremail;
    $headers[] = 'From: Quttainah Medical Center Co  <no-reply@qmc-intl.com>' . "\r\n";
       $headers[] = 'BCC:  <dyna29@gmail.com>' . "\r\n";
    $headers[] = 'BCC:  <dyna29@mailinator.com >' . "\r\n";
    $body      = 'Hi '.$firstname;
    $body    .= '<br><br>Thank You.';
   $body    .= 'We have received your booking with the following information';
  $body    .= 'Speciality:'.$speciality;
  $body    .= 'Name:'.$firstname;
  $body    .= 'Family Name:'.$familyname;
  $body    .= 'Mobile Number:'.$mobile;
  $body    .= 'Email:'.$useremail;
  $body    .= 'Date Of Birth:'.$dob;
  $body    .= 'Preferred Timings:'.$phour.' '.$ampm;
  $body    .= 'Preferred Date:'.$preffereddate;

  $body    .= 'We shall get back to you soon.';

 
   
	    $body  .= '<br><br>Regards,<br>Quttainah Medical Center Co <br>';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $mail      = wp_mail($to,'Quttainah Medical Center "Thank you for booking with us"', $body, $headers);
    remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');
	   
	   
   }
}
add_action('wp_ajax_nopriv_send_booking_confirmation', 'send_booking_confirmation');
add_action('wp_ajax_send_booking_confirmation', 'send_booking_confirmation');

function send_booking_confirmation()
{
    add_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');
    $booking_notes            = esc_sql($_REQUEST["booking_notes"]);
    $booking_id            = esc_sql($_REQUEST["booking_id"]);
      
  
     
    $useremail = get_post_meta($booking_id, 'useremail', true);
    $firstname = get_post_meta($booking_id, 'firstname', true);
 

	update_post_meta($booking_id, 'booking_notes', $booking_notes );
	update_post_meta($booking_id, 'booking_status', 'Confirmed');
	 
    $to        = $useremail;
    $headers[] = 'From: Quttainah Medical Center Co  <no-reply@qmc-intl.com>' . "\r\n";
       $headers[] = 'BCC:  <dyna29@gmail.com>' . "\r\n";
    $headers[] = 'BCC:  <dyna29@mailinator.com >' . "\r\n";
    $body      = 'Hi '.$firstname;
    $body    .= '<br><br>Your booking has been confirmed.';
    $body .= '<br><b>Booking ID :</b>' . $booking_id; 
     if( $booking_notes !=''){
	 }
    $body .= '<br><b>Booking Notes :</b>' . $booking_notes;
   
	    $body  .= '<br><br>Regards,<br>Quttainah Medical Center Co <br>';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $mail      = wp_mail($to, "Booking Confirmation ID: " . $booking_id, $body, $headers);
    remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');
    $result = 1;
    echo json_encode($result );
    die();
}
 add_filter( 'manage_online-booking_posts_columns', 'set_custom_online_booking_columns' );
function set_custom_online_booking_columns($columns) {
    unset( $columns['author'] ); 
    $columns['booking_status'] = __( 'Booking Status', 'cleanora' ); 
    
    return $columns;
}

// Add the data to the custom columns for the quotation post type:
add_action( 'manage_online-booking_posts_custom_column' , 'custom_online_booking_column', 10, 2 );
function custom_online_booking_column( $column, $post_id ) {
	 
	$booking_status_display = '-';
	$booking_status =  get_post_meta( $post_id , 'booking_status' , true ); 
	 
	 if($booking_status !=''){
	 $booking_status_display = '<b class="book-highlight"> Booking '.$booking_status.'</b>';
	 }
	 
	 
    switch ( $column ) {

         

        case 'booking_status' :
			
			
			
            echo $booking_status_display; 
            break;
		
         

    }
}
add_filter( 'manage_news-events_posts_columns', 'set_custom_news_events' );
function set_custom_news_events($columns) {
     
    $columns['ne_id'] = __( 'ID', 'cleanora' ); 
    
    return $columns;
}

// Add the data to the custom columns for the quotation post type:
add_action( 'manage_news-events_posts_custom_column' , 'custom_news_events_column', 10, 2 );
function custom_news_events_column( $column, $post_id ) {
 
    switch ( $column ) {
  
        case 'ne_id' : 
            echo  $post_id; 
            break; 
    }
}


add_filter( 'manage_offer_posts_columns', 'set_custom_offer' );
function set_custom_offer($columns) {
     
    $columns['offer_id'] = __( 'ID', 'cleanora' ); 
    
    return $columns;
}

// Add the data to the custom columns for the quotation post type:
add_action( 'manage_offer_posts_custom_column' , 'custom_offer_column', 10, 2 );
function custom_offer_column( $column, $post_id ) {
 
    switch ( $column ) {
  
        case 'offer_id' : 
            echo  $post_id; 
            break; 
    }
}
add_filter( 'posts_where', 'wpse18703_posts_where', 10, 2 );
function wpse18703_posts_where( $where, &$wp_query )
{
    global $wpdb; 
	$queryelemenet = $wp_query->query; 
	if($queryelemenet['docname']==1){
			if(isset($_REQUEST['doc'])){
		 $doctor = $_REQUEST['doc'];
				if($doctor  !='all'){
					 $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql( $wpdb->esc_like( $doctor ) ) . '%\'';
				}
		 
				 
	}
	}

 unset($array[1]);
    return $where;
}

add_action('wp_ajax_nopriv_show_upcoming_event', 'show_upcoming_event');
add_action('wp_ajax_show_upcoming_event', 'show_upcoming_event');

function show_upcoming_event()
{
	  $event   = esc_sql($_REQUEST["event"]);
//	$latest_cpt = get_posts("post_type=news-events&numberposts=1&&category_name=upcoming-event'");
	$latest_cpt = get_posts(array(
  'post_type' => 'news-events',
  'numberposts' => 1,
 'orderby'   => 'ID',
					'order' => 'DESC',
  'numberposts' => 1,
  'tax_query' => array(
    array(
      'taxonomy' => 'event-type',
      'field' => 'slug',
      'terms' => 'upcoming-event', // Where term_id of Term 1 is "1".
      'include_children' => false
    )
  )
));
 
  $event   = $latest_cpt[0]->ID;
	    $title =get_the_title($event);
	    $event_sub_title =get_post_meta($event,'event_sub_title',true);
	    $location =get_post_meta($event,'event_location',true);
	    $event_date =get_post_meta($event,'event_date',true);
	    $event_link =get_post_meta($event,'event_link',true);
	    $time = strtotime($event_date);
	    $today = strtotime(date('m/d/Y'));
	    $timediff= 'ongoing';
	    if($today>=$time){
			$timediff= 'expired';
		}
	     $background = get_field('background_image',$event);
        $featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( $event ), 'full' ); 
        $event_date_display    = date('F jS Y',$time); 
        $event_day_display    = date('j M',$time); 
	$event_day = date('d',$time); 
	 	$event_month = date('m',$time)-1;     
	 	$event_year = date('Y',$time);   
		$html =  '';
		 
		if($background!=''){
		 	$html = '<style> .big-round-event{ background:url('. $background['url'].')!important; background-size: cover !important;  background-position: CENTER center !important;}</style>';
		}
	
	$html .= '<h3>'. $title.'</h3>';
	$html .= '<h5>'. $event_sub_title.'</h5>';
	$html .= '<div class="location-text">'. $event_date_display;
	if($location !=''){
		$html .= ' at '.$location ;
	}
	if($event_link ==''){ 
		$event_link = get_permalink($event);
	}
	$html .=  '</div>';
	$html .= '<div id="count-down" class="count-down"></div>';
	$html .= '<input type="button" id="know-more-event" value="'.pll__('Know More').'" onclick="location.href=\''.$event_link.'\'">';
	$html .= '<div id="upcoming-event-pic" class="upcoming-event-pic"  style="transition: none 0s ease 0s; text-align: inherit;';
	$html .= 'line-height: 17px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 700; font-size: 32px;background:url(\''.$featuredimage[0].'\')" >';
$html .= '</div>';
	$data = array('eventstatus'=>$timediff,'html'=>$html,'year'=>$event_year,'day'=>$event_day,'month'=>$event_month,'eventdate'=>$event_day_display,'eventfeature'=>$featuredimage[0]);
    echo json_encode($data );
    die();
}



add_action('wp_ajax_nopriv_show_offer_1', 'show_offer_1');
add_action('wp_ajax_show_offer_1', 'show_offer_1');
function event_schedule($atts) {

	global $post;

	$event_date    = get_post_meta($post->ID, 'event_date', true);
	$time = strtotime($event_date); 
	$event_date_display    = date('F jS Y',$time); 
	$event_day_display    = date('j M',$time); 					   
	$html = '<div class="event-schedule">'; 
	$html .= '<h5>'.$event_date_display.'</h5>';
	$html .= '</div>';

	return $html;
}
add_shortcode('event-schedule', 'event_schedule');
function floating_review_block($atts) {

	global $post;
	// $loop = new WP_Query( "post_type=review&meta_key=service_id&meta_value=$post->ID&order=ASC" );
 $args = array(
	'post_type'  => 'review', 
	'orderby'    => 'ID',
	'order'      => 'DESC',
	'meta_query' => array(
		array(
			'key'     => 'service_id',
			'value'   => $post->ID,
			'compare' => '=',
		),
	),
);
$loop = new WP_Query( $args );
$i=0;
	$htmlitems = '';
	$ratings_total = 0;
	$ratings_count = 0;
if($loop->have_posts()) {
	
	while($loop->have_posts()) : $loop->the_post();
	$ratings_count++;
		$rating    = get_post_meta(get_the_ID(), 'rating', true);  
	$ratings_total  = $ratings_total  + $rating ;
						$reviewer_name    = get_post_meta(get_the_ID(), 'reviewer_name', true);  
	$firstCharacter = substr($reviewer_name, 0, 1);
	 $htmlitems .= '<div class="item"><div class="review-content"><div class="review-content-block"><h4>'.get_the_title().'</h4>';
	 $htmlitems .= '<p>'.get_the_content().'</p></div> ';
	$htmlitems .= '<p class="reviewer-name"><span class="round-alpha">'.$firstCharacter.'</span>'.$reviewer_name.'</p></div></div>';
	endwhile;
	wp_reset_postdata(); 
}		
	$avg_rating = $ratings_total / $ratings_count;
	$avg_rating = round($avg_rating);
	$display_stars = '';
		for($i=1;$i<=$avg_rating;$i++){
							$display_stars .= "<img src='".get_stylesheet_directory_uri() . "/images/star.png'>";
						}
						for($i=$avg_rating+1;$i<=5;$i++){
							$display_stars .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
						}
	$html = '<div class="floating-review-block">'; 
	$html  .= '<div class="floating-review-rating">'; 
	$html .= '<h5>Very Good '.$display_stars.' </h5>';
	$html .= '<h6>'.$ratings_count.' reviews </h6>';

	$html .= '</div>';
	$html  .= '<div class="floating-review-block-scroll">'; 
	 
	$html .= '<div class="owl-carousel owl-theme review-slider">';
   	$html .= $htmlitems;

 
$html .= '</div>';
	$html .= '</div>';
	$html .= '</div>';
	return $html;
}
add_shortcode('floating-review-block', 'floating_review_block');
function show_offer_1()
{
	  $offer   = esc_sql($_REQUEST["offer"]);
	    $title =get_the_title($offer);
	    $post_content = get_post($offer);
	    $knowmore = get_permalink($offer);
        $content = $post_content->post_content;
	    $line_1 =get_post_meta($offer,'line_1',true); 
	    $line_2 =get_post_meta($offer,'line_2',true); 
	    $line_3 =get_post_meta($offer,'line_3',true); 
	    $line_4 =get_post_meta($offer,'line_4',true);  
	    $line_5 =get_post_meta($offer,'line_5',true); 
	    $offer_info_line_1 =get_post_meta($offer,'offer_info_line_1',true); 
	    $offer_info_line_2 =get_post_meta($offer,'offer_info_line_2',true);  

        $event_date_display    = date('F jS Y',$time); 
        $event_day_display    = date('j M',$time); 
	     
	$html = '<h3>'. $title.'</h3>';
	$html .= '<h5>'. $offer_info_line_1.'<br>'. $offer_info_line_2.'</h5>'; 
	$smallhtml = '<h6 class="up">'. $line_1.'</h6>';
	$smallhtml .= '<div class="value">'. $line_2.'</div>';
	$smallhtml .= '<div class="valuepostfix"><div class="percentage">'. $line_3.'</div>';
	$smallhtml .= '<div class="text">'. $line_4.'</div></div>';
	$smallhtml .= '<h6  class="down">'. $line_5.'</h6>';
	$data = array('html'=>$html,'smallhtml'=>$smallhtml,'line_1'=>$line_1,'line_2'=>$line_2,'line_3'=>$line_3,'line_4'=>$line_4,'knowmore'=>$knowmore);
    echo json_encode($data );
    die();
}

// Add scripts to wp_footer()
function child_theme_footer_script() { 

					$args = array(	'post_type' => 'before-after',
					'posts_per_page' => -1, 
				 
					'meta_query' => array(
										array(
											'key'     => 'floatingfeatured',
											'value'   => '1',
											'compare' => '=',
										),
									), 
							 
					'orderby'   => 'ID',
					'order' => 'DESC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme bf-top-slider">'; 
						$online=1;
						
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
						$taxonomies=get_taxonomies('','names');
						$batax_list = wp_get_post_terms( get_the_ID(), 'before-after-category', array("fields" => "all"));
                        foreach($batax_list as $batax_list_item){
							if($batax_list_item->parent!=0){
								$batax_list_item_slug = $batax_list_item->slug;
							}
						}
						$before_photo_image = get_post_meta(get_the_ID(),'before_photo_image',true);
						$before_photo_image_src = wp_get_attachment_image_src( $before_photo_image[0], 'full' ); 
						$after_photo_image = get_post_meta(get_the_ID(),'after_photo_image',true);
						$after_photo_image_src = wp_get_attachment_image_src( $after_photo_image[0], 'full' ); 
						$featured = get_post_meta(get_the_id(),'featured',true);
					 
								$category = wp_get_post_terms(get_the_id(), 'before-after-category',  array("fields" => "names"));
							$html .= '<div class="item home-ba" onclick="location.href=\''.site_url('before-and-after').'/'.$batax_list_item_slug.'/'.'\'">'; 
						$html .= '<div class="ba-home-image-before"><div class="ba-title">'. pll__('Before').'</div><div class="bg-blue"><div style="background:url(\''.$before_photo_image_src[0].'\')" class="ba-img-thimb"></div></div></div>';
						$html .= '<div class="ba-home-image-after"><div class="ba-title">'. pll__('After').'</div><div class="bg-blue"><div style="background:url(\''.$after_photo_image_src[0].'\')" class="ba-img-thimb"></div></div></div>';
						$html .= '<h5>'.pll__(get_the_title()).'</h5>';  
						$html .= '</div>';
				 
					
						endwhile;
						wp_reset_postdata(); 
					}
					
							$html .= '</div>';	
?>
	<div id='featured-ba-items'><?php echo $html;?>
</div>
<?php }
add_action( 'wp_footer', 'child_theme_footer_script' );
function cmsmasters_before_body_child($var){
	echo'<div class="page-loader"><div class="mainpreloader"><img src="'. get_stylesheet_directory_uri() .'/images/page-loader.gif"></div></div>';
}
add_action( 'cmsmasters_before_body', 'cmsmasters_before_body_child',10, 1 );


//listing Offer
//
//
function offer_grid($atts) {
 
					$args = array(	'post_type' => 'offer',
					'posts_per_page' => -1, 
			 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$html .= '<div class="offer-listing-container ">';
					if($loop->have_posts()) {
						 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
							$html .= '<div class="offer-item ">'; 
						$html .= '<div class="offer-home-image"><div style="background:url(\''.$featuredimage[0].'\');width:100%;height:242px;"></div></div>';
						$html .= '<h5>'.get_the_title().'</h5>';  
						$html .= '<a href="'.get_the_permalink().'" class="cmsmasters_button">'. pll__('Read More').'</a>'; 
						$html .= '</div>';
						endwhile;
						wp_reset_postdata(); 
					}
					
					$html .= '</div>';		 		 
							 
return $html;
}
add_shortcode('offer-grid', 'offer_grid');
add_action('wp_ajax_nopriv_show_timing_box', 'show_timing_box');
add_action('wp_ajax_show_timing_box', 'show_timing_box');

function show_timing_box()
{

	   $new_time = date("l-H-i-s-a", strtotime('+3 hours')); 
	$new_time = explode('-',$new_time);
	   $weekday = $new_time[0];
	$weekday = strtolower($weekday);
	$contactpage = get_page_by_path( 'contact-us' );
 
		    $open_1    = get_post_meta($contactpage->ID,  $weekday.'_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  $weekday.'_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  $weekday.'_open_3', true);  
	
		    $close_1    = get_post_meta($contactpage->ID,  $weekday.'_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  $weekday.'_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  $weekday.'_close_3', true);  
	$current_time = $new_time[1].':'.$new_time[2]." ".$new_time[4];
 
	$open  = date("H:i", strtotime($open_1.":".$open_2." ".$open_3));
	$open = explode(':',$open);
	$close  = date("H:i", strtotime($close_1.":".$close_2." ".$close_3));
	$close = explode(':',$close);
	$month = date('m');
	$day = date('d');
	$year = date('Y');
    $nowtime = mktime ( $new_time[1], $new_time[2], $new_time[3], $month, $day, $year );
    $opentime  = mktime ( $open[0], $open[1], 0, $month, $day, $year );
    $closetime = mktime ( $close[0], $close[1], 0, $month, $day, $year );
 if($nowtime >=$opentime &&  $nowtime <=$closetime ){
	 // normal process $html  =  '<span class="highlight"> Open</span> Closes '.$close_1.':'.$close_2.' '.$close_3  ;    
	 // below for ramadhan
	  $html  =  '<span class="highlight"> Open</span> we close 8:00 pm ' ;   
 }else{
	  $html  = '<span class="highlight"> Closed</span>'  ;    
 }
	
	 
	 
 
	$data = array('html'=>$html);
    echo json_encode($data );
    die();
}

 function reviews_box(){
global $post;
	 $serviceid =  $post->ID;
	 $html ='';
	 
	 $html  .= "<button type='button' class='slide-toggle'>Rate & Review</button>"; 
$html .= "<hr class='review-hr'>";
$html .= "<div class='box'>";
$html .= "<div class='box-inner'>";
	 $html .= "<div class='review-msg'></div>"; 
$html .= "<div id='write-review-block'  >";
$html .= "<label>Rate:</label><br><a href='javascript:void(0)' class='rate-star' id = 'rate-star-1' rating='1'>";
$html .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
$html .= "</a><a href='javascript:void(0)' class='rate-star' id = 'rate-star-2'  rating='2'>";
$html .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
$html .= "</a><a href='javascript:void(0)' class='rate-star'  id = 'rate-star-3' rating='3'>";
$html .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
$html .= "</a><a href='javascript:void(0)' class='rate-star'  id = 'rate-star-4' rating='4'>";
$html .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
$html .= "</a><a href='javascript:void(0)' class='rate-star' id = 'rate-star-5'  rating='5'>";
$html .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
$html .= "</a>";

	 
$html .= "<input type='hidden' id='rating' ><input type='hidden' id='review-type' value='service'><input type='hidden' id='service_id' value='".$serviceid."'>";
$html .= "<label>Add a headline:</label><input type='text' id='headline' class='review-input'>";
$html .= "<label>Review:</label><textarea id='review-text' class='review-input'></textarea>";
$html .= "<label>Your name:</label><input type='text' id='reviewer-name' class='review-input'>";
$html .= "<br><input type='button' id='submit-review' value='Submit Review' class='cmsmasters_button'>";
$html .= "</div>";
$html .= " </div>";
$html .= "</div>"	 ;
	$html .= "<ul class='rev-items'>";
	 $args = array(	'post_type' => 'review',
					'posts_per_page' => -1, 
				 
				  'tax_query' =>  array(
						array (
							'taxonomy' => 'review-type',
							'field' => 'slug',
							'terms' => 'service',
						)
    		),
							 
					'orderby'   => 'ID',
					'order' => 'DESC',
					);
					$loop = new WP_Query($args);
					$i=0;
					 if($loop->have_posts()) {
						 
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						$rating    = get_post_meta(get_the_ID(), 'rating', true);  
						$reviewer_name    = get_post_meta(get_the_ID(), 'reviewer_name', true);  
						 $approve_review = get_post_meta(get_the_ID(), 'approve_review', true);  
						$aservice    = get_post_meta(get_the_ID(), 'service_id', true);  
						  
						 if($approve_review=='Yes' && $serviceid == $aservice){
						$htmlstars = '<div class="stars">';
						for($i=1;$i<=$rating;$i++){
							$htmlstars .= "<img src='".get_stylesheet_directory_uri() . "/images/star.png'>";
						}
						for($i=$rating+1;$i<=5;$i++){
							$htmlstars .= "<img src='".get_stylesheet_directory_uri() . "/images/star-empty.png'>";
						}
						$htmlstars .= '</div>';
						
										$html .= '<li class="review-row">';
						$html .= '<b>Rating:</b> '.$htmlstars;
						$html .= '<h5>'.get_the_title().'</h5>';
						$html .= '<p>'.get_the_content().'<p>';
						$html .= '<h6 class="cmsmasters_quote_subtitle">- '.$reviewer_name.'</h6>';
							 $html .= "<hr>";
						$html .= '</li>';
						}
						endwhile;
						wp_reset_postdata(); 
					} 
	 	$html .= '</ul>';
//$html .= "<input type='button' id='write-review' value='Rate & Review' class='cmsmasters_button'>";


	 
	 return $html;
}	
add_shortcode('reviews', 'reviews_box');

  add_action('wp_ajax_nopriv_submit_review', 'submit_review');
add_action('wp_ajax_submit_review', 'submit_review');

function submit_review()
{
	 $rating   = esc_sql($_REQUEST["rating"]); 
	 $headline   = esc_sql($_REQUEST["headline"]); 
	 $review_text   = esc_sql($_REQUEST["review_text"]); 
	 $reviewer_name   = esc_sql($_REQUEST["reviewer_name"]); 
	 $review_type   = esc_sql($_REQUEST["review_type"]); 
	 $service_id   = esc_sql($_REQUEST["service_id"]); 
	 	 $new_post         = array(
        'post_type' => 'review',
        'post_title' => $headline,
        'post_content' => $review_text,
        'post_status' => 'publish'
    );
    $category = get_term_by('slug', $review_type, 'review-type');
 
    $post_id = wp_insert_post($new_post);
	wp_set_post_terms( $post_id, array($category->term_id), 'review-type') ;
    update_post_meta($post_id, "rating", $rating);
    update_post_meta($post_id, "headline", $headline);
    update_post_meta($post_id, "reviewer_name", $reviewer_name); 
    update_post_meta($post_id, "service_id", $service_id); 
	 update_post_meta($post_id, 'approve_review', 'No');  
	$data = $post_id;
	$to        = 'info@qmc-intl.com,i.hammoud@qmc-intl.com';
$headers[] = 'From: Quttainah Medical Center Co  <no-reply@qmc-intl.com>' . "\r\n";
$headers[] = 'BCC:  <dyna29@gmail.com>' . "\r\n";
$headers[] = 'BCC:  <dyna29@mailinator.com >' . "\r\n";
$body      = 'Hi, ' ; 

 
$body    .= '<br><br>We have received a review from user '.$reviewer_name.' for service: '.get_the_title($service_id);
$body    .= '<br><br>Below are the details: ';
$body    .= '<br>Rating: '.$rating;
$body    .= '<br>Headline: '.headline;
$body    .= '<br>Review: '.$review_text;
$body    .= '<br>Reviewer Name: '.$reviewer_name;
$body    .= '<br><br>Login and <a href="'.admin_url('/post.php?post='.$post_id.'&action=edit').'" targte="blank">'. pll__('Click Here').'</a> to check the review  ';
 

$body  .= '<br><br>Regards,<br>Quttainah Medical Center Co <br>';
$headers[] = 'Content-Type: text/html; charset=UTF-8';
$mail      = wp_mail($to,'Quttainah Medical Center Review - Service: '.get_the_title($service_id).' ', $body, $headers);
remove_filter('wp_mail_content_type', 'wpdocs_set_html_mail_content_type');
    echo json_encode($data );
    die();
}
function show_timing_grid() {
 
		$contactpage = get_page_by_path( 'contact-us' );
 
		
		$html .= '<div class="timing-grid "><h3>'. pll__('Timings').'</h3>'; 
		$open_1    = get_post_meta($contactpage->ID,  'saturday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'saturday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'saturday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'saturday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'saturday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'saturday_close_3', true);  
		$html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Saturday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
		$html .= '</div>';
		 
		$open_1    = get_post_meta($contactpage->ID,  'sunday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'sunday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'sunday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'sunday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'sunday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'sunday_close_3', true);  
		 $html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Sunday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
		$html .= '</div>';
 
		$open_1    = get_post_meta($contactpage->ID,  'monday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'monday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'monday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'monday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'monday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'monday_close_3', true);  
		$html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Monday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
		$html .= '</div>';
 
		$open_1    = get_post_meta($contactpage->ID,  'tuesday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'tuesday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'tuesday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'tuesday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'tuesday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'tuesday_close_3', true);  
		$html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Tuesday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
		$html .= '</div>';
 
		$open_1    = get_post_meta($contactpage->ID,  'wednesday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'wednesday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'wednesday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'wednesday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'wednesday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'wednesday_close_3', true);  
		$html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Wednesday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
		$html .= '</div>';
 
		$open_1    = get_post_meta($contactpage->ID,  'thursday_open_1', true); 
        $open_2    = get_post_meta($contactpage->ID,  'thursday_open_2', true); 
        $open_3    = get_post_meta($contactpage->ID,  'thursday_open_3', true);  
	
		$close_1    = get_post_meta($contactpage->ID,  'thursday_close_1', true); 
        $close_2    = get_post_meta($contactpage->ID,  'thursday_close_2', true); 
        $close_3    = get_post_meta($contactpage->ID,  'thursday_close_3', true);  
		$html .= '<div class="dayrow">';
		$html .= '<div class="dayname">'. pll__('Thursday').'</div>';
		$html .= '<div class="fromtime">'.$open_1.':'.$open_2.' '.pll__($open_3).'</div>';
		$html .= '<div class="fromtime"> - '.$close_1.':'.$close_2.' '.pll__($close_3).'</div>';
	 
		
		$html .= '</div>';
		$html .= '</div>';
					 	 		 
							 
$data = array('html'=>$html);
    echo json_encode($data );
    die();
} 

add_action('wp_ajax_nopriv_show_timing_grid', 'show_timing_grid');
add_action('wp_ajax_show_timing_grid', 'show_timing_grid');

add_action('wp_ajax_nopriv_show_counters', 'show_counters');
add_action('wp_ajax_show_counters', 'show_counters');

function show_counters() { 	 
	$counter_date = date('m/d/Y');	
	$dateset = get_option('counter_date');
	$counter_vippatients = get_option('counter_vippatients');
	$counter_cases = get_option('counter_cases');
	$counter_staffdoctors = get_option('counter_staffdoctors');
	
	if($dateset != $counter_date){
		update_option('counter_date',$counter_date);
		update_option('counter_vippatients',intval($counter_vippatients)+9);
		update_option('counter_cases',intval($counter_cases)+9);
		update_option('counter_staffdoctors',intval($counter_staffdoctors)+9);
	}
	$counter_vippatients = get_option('counter_vippatients');
	$counter_cases = get_option('counter_cases');
	$counter_staffdoctors = get_option('counter_staffdoctors');
	 
$data = array('vippatients'=>50,'counter_date'=>$counter_date, 'dateset'=>$dateset, 'counter_vippatients'=>$counter_vippatients, 'counter_cases'=>$counter_cases, 'counter_staffdoctors'=>$counter_staffdoctors);
    echo json_encode($data );
    die();
} 


function cmsmasters_after_body_child($var){
	$html = '';
	$html .= '<div></div>';
	$html .= '<svg xmlns="http://www.w3.org/2000/svg">';
	$html .= '<svg id="send" viewBox="0 0 24 24">';
	$html .= '<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>';
	$html .= '<path d="M0 0h24v24H0z" fill="none"/>';
	$html .= '</svg>';
	$html .= '</svg>';
//	echo $html;
}
add_action('cmsmasters_after_body','cmsmasters_after_body_child',10,1);
remove_action( 'set_comment_cookies', 'wp_set_comment_cookies' );

//start disabled chat
add_action( 'rest_api_init', function () {
	register_rest_route( 'chatkitpusher/v1', '/session/auth', array(
		'methods' => 'POST',
		'callback' => 'auth',
	));
} );

function auth(WP_REST_Request $request){
	
	require_once('vendor/autoload.php');
	$chatkit = new Chatkit\Chatkit([
	  'instance_locator' => 'v1:us1:dc46542f-b040-4e5b-932d-4271d9c98927',
	  'key' => '96e53816-abfd-4133-bf81-cc87fb8d6d90:w7A56VOQrU+uIXaBHhTXy8Wk6H0+gJEjxTXgWzvGIyQ='
	]);
	$param_userid = rawurldecode($request['user_id']);
	$auth_data = $chatkit->authenticate([ 'user_id' => $param_userid  ]);
	return json_encode($auth_data['body']);
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'chatkitpusher/v1', '/session/load', array(
		'methods' => 'POST',
		'callback' => 'load',
	));
} );

function load(WP_REST_Request $request){
	require_once('vendor/autoload.php');
	$chatkit = new Chatkit\Chatkit([
	  'instance_locator' => 'v1:us1:dc46542f-b040-4e5b-932d-4271d9c98927',
	  'key' => '96e53816-abfd-4133-bf81-cc87fb8d6d90:w7A56VOQrU+uIXaBHhTXy8Wk6H0+gJEjxTXgWzvGIyQ='
	]);
	$userid = time();
	$param_name = 'GUEST('.$userid.')';
	$param_email = 'GUEST|'.$userid;
	 $userhash = array();
	 $userhash = $chatkit->getUser([
	 	'id' => $param_email
	 ]);
	
	 
	 if ($userhash['body']['error']=='services/chatkit/not_found/user_not_found'){
		$userhash = $chatkit->createUser([ 
			'id' => $param_email, 
			'name' => $param_name 
		]);
		  $userrooms = $chatkit->createRoom([
		  'creator_id' => $param_email,
		  'name' => $param_email,
		  'user_ids' => ['Admin'],
		  'private' => false
		]); 
		return $userrooms['body'] ; 
	 }else{
	$userrooms = $chatkit->createRoom([
		  'creator_id' => $param_email,
		  'name' =>  $param_email,
		  'user_ids' => ['Admin'],
		  'private' => false
		]); 
 
		return $userrooms['body'] ; 
	 }
	 
	
 
 
   
}
function clearpusher(){
	require_once('vendor/autoload.php');
	$chatkit = new Chatkit\Chatkit([
	  'instance_locator' => 'v1:us1:dc46542f-b040-4e5b-932d-4271d9c98927',
	  'key' => '96e53816-abfd-4133-bf81-cc87fb8d6d90:w7A56VOQrU+uIXaBHhTXy8Wk6H0+gJEjxTXgWzvGIyQ='
	]);
	//deleted users starts
	$pusher_users = $chatkit->getUsers();
	$userindex =  count($pusher_users)  ;
	 
	$i = 0;
	
	
	foreach($pusher_users as $pusher_user){
		$i++;
		if($userindex==$i){
			foreach($pusher_user as $user){
				if($user['id'] !=='Admin') {
				  
					$chatkit->deleteUser([ 'id' => $user['id'] ]);
				}
			}			 
		}
		
		 
	}
	//deleted users ends
	//
	
	//deleted rooms starts
	$pusher_rooms = $chatkit->getRooms([]);
	$roomindex =  count($pusher_rooms)  ;
	 
	$i = 0;
	
	
	foreach($pusher_rooms as $pusher_room){
		$i++;
		if($roomindex==$i){
			foreach($pusher_room as $room){
				if($room['id'] !=='Admin') {
				  
					$chatkit->deleteRoom([ 'id' => $room['id'] ]);
				}
			}			 
		}
		
		 
	}
	//deleted rooms ends
}
add_action('clear_pusher_history','clearpusher');

//end disabled chat
function faqs_by_category($atts) {

 $faq_category = get_query_var('faq_category');
	  
					$args = array(	'post_type' => 'faqs',
					'posts_per_page' => -1, 
					 'tax_query'  =>  array(
						array (
							'taxonomy' => 'before-after-category',
							'field' => 'slug',
							'terms' => $faq_category,
						)
    		),
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						
				$html = '<div class="cmsmasters_toggles toggles_mode_toggle">';
 
						while($loop->have_posts()) : $loop->the_post();
							$i++;
						 
						if($i==1){
							 
							$html .= '<div class="cmsmasters_toggle_wrap current_toggle" data-tags="all ">';
						}else{
							
							$html .= '<div class="cmsmasters_toggle_wrap" data-tags="all ">';
						}
						
						$html .= '<div class="cmsmasters_toggle_title">';
						$html .= '<span class="cmsmasters_toggle_plus">';
						$html .= '<span class="cmsmasters_toggle_plus_hor"></span>';
						$html .= '<span class="cmsmasters_toggle_plus_vert"></span>';
						$html .= '</span>';
						$html .= '<a href="javascript:void(0)">Q. '.get_the_title().'</a>';
						$html .= '</div>';
						if($i==1){
							 
							$html .= '<div class="cmsmasters_toggle" style="display: block !important;">';
						}else{
							
							$html .= '<div class="cmsmasters_toggle" >';
						}
						
						$html .= '<div class="cmsmasters_toggle_inner">';
						$html .=   get_the_content() ; 
						$html .= '</div>';
						$html .= '</div>';
						$html .= '</div> ';
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
						 
					}
							 
							 
return $html;
}
add_shortcode('faq-by-category', 'faqs_by_category');
 function add_meta_tags() {
	 
	if (pll_current_language()== 'en'){
		?>
  <meta name="description" content="Quttainah Medical Centeris an integrated medical center established in Kuwait early 2016.QMC provides the highest standards of medical services, the center is fully fledged with the latest technologies, advanced techniques, specialized and skilled team to assure the best consmetic and reconstructive results."/>
  <meta name="keywords" content="Plastic surgery , Quttainah medical center , Dermatology, Breast augmentation , Facelift, Tummy tuck, Cosmetic surgery"/><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103656078-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103656078-1');
</script>

<?php
	}else{
		?>
  <meta name="description" content="Quttainah Medical Centeris an integrated medical center established in Kuwait early 2016.QMC provides the highest standards of medical services, the center is fully fledged with the latest technologies, advanced techniques, specialized and skilled team to assure the best consmetic and reconstructive results."/>
  <meta name="keywords" content="مركز قطينه الطبي, جراحة تجميلية, شد بطن, شد صدر, جلدية, جراح تجميل"/>
<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-103656078-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-103656078-1');
</script>

<?php
	}
  }
add_action('wp_head', 'add_meta_tags');

add_action('wp_footer', 'wpshout_action_example'); 
function wpshout_action_example() { 
	$contact_query = new WP_Query( array( 'pagename' => 'pop-up' ,'post_status'=>'publish') );
						while($contact_query->have_posts()): $contact_query->the_post(); 
							 $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
							  
					
   $footer_html =  " <!-- Trigger/Open The Modal -->";
   $footer_html .= "<button id='myBtn' style='display:none'>Open Modal</button>";
 $footer_html .= "<!-- The Modal -->";
 $footer_html .= "<div id='myModal' class='modal'>";
 $footer_html .= " <!-- Modal content -->";
   $footer_html .= "<div class='modal-content'>";
    $footer_html .= " <span class='close-offer'>×</span>";
   $footer_html .= " <a href='".site_url('offers')."'><img src='".$featured_image[0]."' alt='Quttainah Medical Center'></a>";
   $footer_html .= "</div>";

 $footer_html .= "</div>"; 
	
		endwhile;  
									 
						wp_reset_postdata();
	echo  $footer_html;
}
 
// define the wpcf7_skip_mail callback 
function filter_wpcf7_skip_mail( $skip_mail, $contact_form ) { 
    // make filter magic happen here...
    // 
     $cmsmasters_message = $_REQUEST['cmsmasters_message'];
 $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";

// The Text you want to filter for urls
$text = "The text you want to filter goes here. http://google.com";

// Check if there is a url in the text
if(preg_match($reg_exUrl, $cmsmasters_message, $url)) {

       // make the urls hyper links
    
       return true; 

} else {

       // if no urls in the text just return the text
 
       return false; 

}
 
   
}; 
         
// add the filter 
add_filter( 'wpcf7_skip_mail', 'filter_wpcf7_skip_mail', 10, 2 ); 
 
//offerlist shortcode
//
function offer_list($atts) {
	$html =''; 
	$html .= '<div class="cmsmasters_row_margin  ">';
		$offercategories = get_terms( array(
    'taxonomy' => 'offer-category',
    'hide_empty' => false,'orderby' => 'tax_position',
) );
	 
	foreach($offercategories as $offercategory){
 if (function_exists('get_wp_term_image'))
{
    $meta_image = get_wp_term_image($offercategory->term_id); 
    //It will give category/term image url 
}
$args = array(
'post_type' => 'offer','posts_per_page' => 1, 
'tax_query' => array(
    array(
    'taxonomy' => 'offer-category',
    'field' => 'term_id',
    'terms' => $offercategory->term_id
     )
  )
); 
			$loop = new WP_Query($args);
					$i=0;
					$data =  array();
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
			 $offer_page = get_permalink();
   
	endwhile;
						wp_reset_postdata();
					} 
 
			$html .= '<div  class="cmsmasters_column one_third">';
	$html .= '<div class="cmsmasters_column_inner"><div class="aligncenter offer-items"><div class="cmsmasters_img  cmsmasters_image_c with_caption offer-icon"><a href="'.$offer_page.'"><img src="'.$meta_image.'"></a><p class="cmsmasters_img_caption">'.$offercategory->name.'</p></div></div>';
	$html .= '</div></div>';
	}

	$html .= '</div>';
							 
return $html;
}
add_shortcode('offer-list', 'offer_list');

add_action( 'rest_api_init', 'my_register_route' );
function my_register_route() {
    register_rest_route( 'offers', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'offers_list_json',
                )
            );
}
function offers_list_json() {	
	$last_offer_updated_date = get_option( 'last_offer_updated_date'); 
    header("Last-Modified: " . $last_offer_updated_date);
	$offercategories = get_terms( array(
    'taxonomy' => 'offer-category',
    'hide_empty' => false,
) );
	 $data =  array();
	foreach($offercategories as $offercategory){
		 if(pll_get_term_language($offercategory->term_id)=='en' ){
 if (function_exists('get_wp_term_image'))
{
    $meta_image = get_wp_term_image($offercategory->term_id); 
    //It will give category/term image url 
}
$args = array(
'post_type' => 'offer','posts_per_page' => 1,  'lang' => 'en' ,
'tax_query' => array(
    array(
    'taxonomy' => 'offer-category',
    'field' => 'term_id',
    'terms' => $offercategory->term_id
     )
  )
); 
		 
			$loop = new WP_Query($args);
					$i=0;
				$attr = 1;	
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
		 $image_list = array();
			 $page_id = get_the_ID();
   $content = preg_replace('/\[[^\]]*\]/', '',get_the_content());
							$image_content = explode(',',$content);
						
						 
						$imagedata =  explode('|',$image_content[0]) ;
						$attr = count($imagedata ) ;
						 
						   foreach ($image_content as $image_content_data){
								$image_content_data = explode('|',$image_content_data);
								$image_list[] = set_url_scheme(str_replace('-150x150','',$image_content_data[1]));
							}
	endwhile;
						wp_reset_postdata();
					} 
			 //if($attr==2){
			  
			 if ($image_list[0]==''){
				 $image_list[0] = 'https://qmc-dubai.com/wp-content/uploads/2019/10/coming-soon.jpg';
			 }
				 $data[] = array('title'=>$offercategory->name,'image'=>$meta_image,'detail'=>$image_list);
			// }
		
	}	
	}
					return rest_ensure_response( $data );
}


add_action( 'rest_api_init', 'register_route_offer_details' );
function register_route_offer_details() {
  register_rest_route( 'offer',  '/detail/(?P<id>\d+)', array(
    'methods' => 'GET',
    'callback' => 'offer_details',
    'args' => array(
      'id' ,
    ),
  ) );
}  ;
function offer_details($offer) {
	$last_offer_updated_date = get_option( 'last_offer_updated_date'); 
    header("Last-Modified: " . $last_offer_updated_date  );
	$args = array(	'post_type' => 'offer', 
					'p'   => $offer['id'],
					'order' => 'DESC',
					);
					$loop = new WP_Query($args);
					$i=0;
					$data =  array();
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
							$i++;
							$content = preg_replace('/\[[^\]]*\]/', '',get_the_content());
							$image_content = explode(',',$content);
						$image_list = array();
						    foreach ($image_content as $image_content_data){
								$image_content_data = explode('|',$image_content_data);
								$image_list[] = set_url_scheme(str_replace('-150x150','',$image_content_data[1]));
							}
								$data[] =array('ID'=>get_the_ID(),'offer-images'=>$image_list);
   
	endwhile;
						wp_reset_postdata();
					} return $data;
}
add_action( 'rest_api_init', 'register_route_testimonials' );
function register_route_testimonials() {
 
	register_rest_route( 'testimonial', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'testimonial_list',
                )
            );
}  ;
function testimonial_list() {
	$last_testimonial_updated_date = get_option( 'last_testimonial_updated_date'); 
    header("Last-Modified: " . $last_testimonial_updated_date  );
	$args = array(	'post_type' => 'testimonial', 'lang' => 'en' ,
	'order' => 'DESC',
	);
	$loop = new WP_Query($args);
	$i=0;
	$data =  array();
	if($loop->have_posts()) {
		while($loop->have_posts()) : $loop->the_post();
			$i++;
			$vurl = ''; 
			$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 
	 
			if(get_the_post_video_url(get_the_ID()) !=""){
$vurl = get_the_post_video_url( get_the_ID() );
			} 
			$data[] =array('ID'=>get_the_ID(),'image'=>$featuredimage[0],'video_url'=> $vurl,content=>html_entity_decode(get_the_content()));
			
		endwhile;
		wp_reset_postdata();
	}
	return $data;
}
add_action( 'rest_api_init', 'register_route_doctors' );
function register_route_doctors() {
 
	register_rest_route( 'doctor', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'doctor_json_list',
                )
            );
}  ;
function doctor_json_list() {
	$last_doctor_updated_date = get_option( 'last_doctor_updated_date'); 
    header("Last-Modified: " . $last_doctor_updated_date);
	$args = array(	'post_type' => 'doctor'  , 'lang' => 'en' ,'posts_per_page' => -1, 
	'order' => 'ASC',
	);
	$loop = new WP_Query($args);
	$i=0;
	$data =  array();
	if($loop->have_posts()) {
		while($loop->have_posts()) : $loop->the_post();
			$i++; 
			$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	        $designation = get_post_meta(get_the_ID(),'designation',true);
	        $visiting  = get_post_meta(get_the_ID(),'visiting',true);
	        $snapchat  = get_post_meta(get_the_ID(),'snapchat',true);
	        $instagram  = get_post_meta(get_the_ID(),'instagram',true);
	        $services = get_post_meta(get_the_ID(),'services',true);
		      $services = maybe_unserialize($services);
		$service_names = array();
		foreach($services as $service){
			$service_names[] = get_the_title($service);
		}
		$content = html_entity_decode(get_the_content());
		$contentextract = explode('mode="toggle" animation_delay="0"]',$content);
		//var_dump($content);
		 $contentextract =	explode('[/cmsmasters_toggles]',$contentextract[1]);
		
		 $contentextract =	explode('[/cmsmasters_toggle]',$contentextract[0]);
		$contentdata = array();
		foreach($contentextract as $contentextract_item){
			$text =  $contentextract_item ;
			preg_match_all("/\[[^\]]*\]/", $text, $matches);
		 
		    $contenttitleextract =	explode('title="',$matches[0][0]);
			
		   $contenttitleextract =	explode('"]',$contenttitleextract[1]);
			$content_title =$contenttitleextract[0];
			 
			$content_text = str_replace($matches[0],"",$contentextract_item);
			if($content_title !=''){
				
					$content_text =  str_replace("<strong>","*",$content_text);
				$content_text =  str_replace("</strong>","*",$content_text);
				$content_text = strip_tags ($content_text);
			 $content_text =  str_replace("\r","",$content_text);
				$content_title = strip_tags ($content_title);
			 $content_title =  str_replace("\r","",$content_title);
				$contentdata[] = array('title'=>$content_title,'description'=>$content_text);
			}
			
			
		}
			$data[] =array('ID'=>get_the_ID(),'name'=>html_entity_decode(get_the_title()),'designation'=>$designation,'services'=>html_entity_decode($service_names),'visiting-doctor'=>$visiting,'snapchat'=>$snapchat,'instagram'=>$instagram,'image'=>$featuredimage[0],  'content'=>  $contentdata  );
			
		endwhile;
		wp_reset_postdata();
	}return $data;
}


add_action( 'rest_api_init', 'register_route_services' );
function register_route_services() {
 
	register_rest_route( 'service', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'services_json_list',
                )
            );
}  ;
function services_json_list() {
	  $last_service_updated_date = get_option( 'last_service_updated_date'); 
	 
  header("Last-Modified: " . $last_service_updated_date  );
	$args = array(	'post_type' => 'project' ,'lang' => 'en' ,'posts_per_page' => -1, 
	'order' => 'ASC',
	);
	$loop = new WP_Query($args);
	$i=0;
	$data =  array();
	if($loop->have_posts()) {
		while($loop->have_posts()) : $loop->the_post();
			$i++; 
		//if(get_the_ID() ==1169){
			
		
			$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	        $content =  html_entity_decode(get_the_content());
		$content_text = '';
		  // var_dump( $content);
		$contentone = explode('data_classes="service-content"][cmsmasters_text',$content);
		 // var_dump( $contentone[1]);
		$content_a =  explode(']',$contentone[1]);
			// var_dump( $content_a[1]);
		//$contentextract = explode(']',$contentone[1]);
		//echo '------------------------------<br>';
	     if(count($content_a) > 1 ){
			  $contentextract  =	explode('[/cmsmasters_text',$content_a[1]);
			 $content_text = $contentextract[0];
			 
					$content_text =  str_replace("<strong>","*",$content_text);
				$content_text =  str_replace("</strong>","*",$content_text);
		$content_text = strip_tags ($content_text);
			 $content_text =  str_replace("\r","",$content_text);
			
		 }
		$app_thumbnail = get_field('app_thumbnail');
		$thumbnailimg = $app_thumbnail['url'];
		if(is_null( $app_thumbnail['url'])){
			$thumbnailimg = '';
		}
		$data[] =array('ID'=>get_the_ID(),'name'=>html_entity_decode(get_the_title()),   'content'=>  $content_text,'thumbnail-pic'=>$thumbnailimg);
			//}
		endwhile;
		wp_reset_postdata();
	}return $data;
}
add_action( 'rest_api_init', 'register_route_test' );
function register_route_test() {
 
	register_rest_route( 'test', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'test_json_list',
                )
            );
}  ;
function test_json_list() {
	$last_doctor_updated_date = get_option( 'last_doctor_updated_date'); 
    header("Last-Modified: " . $last_doctor_updated_date  );
	$data = array();
	$data[] = array('ID'=>41,'name'=>'maggie',   'content'=> 'a lot of text');
	 
	 return $data;
}
 
//before after json
//

  add_action( 'rest_api_init', 'register_route_before_after' );
function register_route_before_after() {
 
	register_rest_route( 'before-after', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'before_after_json_list',
                )
            );
}  ;
function before_after_json_list() {
	
		$last_before_after_updated_date = get_option( 'last_before_after_updated_date'); 
    header("Last-Modified: " . $last_before_after_updated_date  );
	$parent_beforeaftercategories = get_terms( array(
    'taxonomy' => 'before-after-category',
    'hide_empty' => false,
	'parent'=>0,
) );
foreach($parent_beforeaftercategories as $parent_beforeaftercategory){
	$featured  = get_field('featured',$parent_beforeaftercategory);
			 
			if($featured =='Yes'){
		 if(pll_get_term_language($parent_beforeaftercategory->term_id)=='en' ){

	$beforeaftercategories = get_terms( array(
    'taxonomy' => 'before-after-category',
    'hide_empty' => false,'parent'=>$parent_beforeaftercategory->term_id,
) );
	 $data =  array();
	foreach($beforeaftercategories as $beforeaftercategory){
		 if(pll_get_term_language($beforeaftercategory->term_id)=='en' ){
 if (function_exists('get_wp_term_image'))
{
    $meta_image = get_wp_term_image($beforeaftercategory->term_id); 
    //It will give category/term image url 
}
$args = array(
'post_type' => 'before-after','posts_per_page' => -1,  'lang' => 'en' ,
'tax_query' => array(
    array(
    'taxonomy' => 'before-after-category',
    'field' => 'term_id',
    'terms' => $beforeaftercategory->term_id
     )
  )
); 
			$loop = new WP_Query($args);
					$i=0;
				$attr = 1;	
			  $before_after_list = array();
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
		
			 $page_id = get_the_ID();
                  $scar_location = get_post_meta(get_the_ID(),'scar_location',true);
						$before_photo_image = get_post_meta(get_the_ID(),'before_photo_image',true);
						$before_photo_image_src = wp_get_attachment_image_src( $before_photo_image[0], 'full' ); 
						$after_photo_image = get_post_meta(get_the_ID(),'after_photo_image',true);
						$after_photo_image_src = wp_get_attachment_image_src( $after_photo_image[0], 'full' ); 
						$batype = get_post_meta(get_the_ID(),'batype',true);
						$basize = get_post_meta(get_the_ID(),'basize',true);
						$profile = get_post_meta(get_the_ID(),'profile',true);
						$app_before_image = get_field('app_before_image');
						$app_after_image = get_field('app_after_image');
						$after_img = $after_photo_image_src[0];
						$before_img = $before_photo_image_src[0];
						if($app_after_image['url']!=''){
							$after_img = $app_after_image['url'];
						}
						if($app_before_image['url']!=''){
							$before_img = $app_before_image['url'];
						}
						
				 $before_after_list[] = array('id'=>get_the_ID(),'before_image'=>$before_img,'after_image'=>$after_img);
		 endwhile;
						wp_reset_postdata();
					} 
			 	 $meta_image = '';
			  if (function_exists('get_wp_term_image'))
				{
					$meta_image = get_wp_term_image($beforeaftercategory->term_id); 
					//It will give category/term image url 
					if($meta_image==''){
						$meta_image =  get_stylesheet_directory_uri().'/images/no-image-before-after.jpg'; 
					}
				}
		 $data[] = array('sub_category'=>html_entity_decode($beforeaftercategory->name),'sub_category_image'=>$meta_image,'items'=>$before_after_list);
	}	
	}
			 $meta_image = '';
			  if (function_exists('get_wp_term_image'))
				{
					$meta_image = get_wp_term_image($parent_beforeaftercategory->term_id); 
					//It will give category/term image url 
					 if($meta_image==''){
						$meta_image =  get_stylesheet_directory_uri().'/images/no-image-before-after.jpg'; 
					}
				}
	$maindata[] = array('category'=>html_entity_decode($parent_beforeaftercategory->name),'category_image'=>$meta_image,'sub_categories'=>$data);
}}
}
					return rest_ensure_response( $maindata );
}
add_action( 'rest_api_init', 'register_route_test' );
//visitng doctor json
//
 add_action( 'rest_api_init', 'register_route_visiting_doctors' );
function register_route_visiting_doctors() {
 
	register_rest_route( 'visiting-doctor', 'list', array(
                    'methods' => 'GET',
                    'callback' => 'visitingdoctor_json_list',
                )
            );
}  ;
function visitingdoctor_json_list() {
	$last_visiting_doctor_updated_date = get_option( 'last_visiting_doctor_updated_date'); 
    header("Last-Modified: " . $last_visiting_doctor_updated_date);
	$args = array(	'post_type' => 'doctor'   , 'lang' => 'en' ,'posts_per_page' => -1, 
	'order' => 'DESC',
	);
	$loop = new WP_Query($args);
	$i=0;
	$data =  array();
	if($loop->have_posts()) {
		while($loop->have_posts()) : $loop->the_post();
			$i++; 
			$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	        $designation = get_post_meta(get_the_ID(),'designation',true);
	        $visiting  = get_post_meta(get_the_ID(),'visiting',true);
			if($visiting =='Yes'){
	        $snapchat  = get_post_meta(get_the_ID(),'snapchat',true);
	        $instagram  = get_post_meta(get_the_ID(),'instagram',true);
	        $services = get_post_meta(get_the_ID(),'services',true);
				$visitingdate = get_post_meta(get_the_ID(),'visitingdate',true);
		      $services = maybe_unserialize($services);
		$service_names = array();
		foreach($services as $service){
			$service_names[] = get_the_title($service);
		}
		$content = html_entity_decode(get_the_content());
		$contentextract = explode('mode="toggle" animation_delay="0"]',$content);
		//var_dump($content);
		 $contentextract =	explode('[/cmsmasters_toggles]',$contentextract[1]);
		
		 $contentextract =	explode('[/cmsmasters_toggle]',$contentextract[0]);
		$contentdata = array();
		foreach($contentextract as $contentextract_item){
			$text =  $contentextract_item ;
			preg_match_all("/\[[^\]]*\]/", $text, $matches);
		 
		    $contenttitleextract =	explode('title="',$matches[0][0]);
			
		   $contenttitleextract =	explode('"]',$contenttitleextract[1]);
			$content_title =$contenttitleextract[0];
			 
			$content_text = str_replace($matches[0],"",$contentextract_item);
			if($content_title !=''){
				
					$content_text =  str_replace("<strong>","*",$content_text);
				$content_text =  str_replace("</strong>","*",$content_text);
				$content_text = strip_tags ($content_text);
			 $content_text =  str_replace("\r","",$content_text);
				$content_title = strip_tags ($content_title);
			 $content_title =  str_replace("\r","",$content_title);
				$contentdata[] = array('title'=>html_entity_decode($content_title),'description'=>$content_text);
			}
			
			
		}
			$data[] =array('ID'=>get_the_ID(),'name'=>get_the_title(),'designation'=>$designation,'services'=>$service_names,'snapchat'=>$snapchat,'instagram'=>$instagram,'image'=>$featuredimage[0], 'visitingdate'=>$visitingdate, 'content'=> $contentdata );
			}
		endwhile;
		wp_reset_postdata();
	}return $data;
}
add_action('rest_api_init', 'register_route_before_after_category');
function register_route_before_after_category()
{
    
    register_rest_route('before-after', 'category/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'before_after_json_category', 'args' => array(
      'id' ,
    ),
    ));
}
;
function before_after_json_category($cat)
{
    
    $last_before_after_updated_date = get_option('last_before_after_updated_date');
    header("Last-Modified: " . $last_before_after_updated_date);
	if(isset($cat['id'])){
		 $parent_beforeaftercategories = get_terms(array(
        'taxonomy' => 'before-after-category',
        'hide_empty' => false,
        'parent' => $cat['id']
    ));
	}else{
		 $parent_beforeaftercategories = get_terms(array(
        'taxonomy' => 'before-after-category',
        'hide_empty' => false,
        'parent' => 0
    ));
	}
   
    $data                         = array();
    foreach ($parent_beforeaftercategories as $parent_beforeaftercategory) {
        if (pll_get_term_language($parent_beforeaftercategory->term_id) == 'en') {
            
            
            
            $meta_image = '';
            if (function_exists('get_wp_term_image')) {
                $meta_image = get_wp_term_image($parent_beforeaftercategory->term_id);
                //It will give category/term image url 
            }
			$featured  = '';
			$featured  = get_field('featured',$parent_beforeaftercategory);
			if( $cat['id'] ==0 ){
				$sub_link = 'https://qmc-dubai.com/wp-json/before-after/category/'.$parent_beforeaftercategory->term_id;
			}else{
				$featured  = 'Yes';
				$sub_link = 'https://qmc-dubai.com/wp-json/before-after/items/'.$parent_beforeaftercategory->term_id;
			}
			if($featured =='Yes'){
				  $data[] = array(
                'category' => html_entity_decode($parent_beforeaftercategory->name),
                'category_image' => $meta_image,
                'sub_link' => $sub_link
            );
			}
          
        }
    }
    return rest_ensure_response($data);
}
add_action('rest_api_init', 'register_route_before_after_item_list');
function register_route_before_after_item_list()
{
    
    register_rest_route('before-after', 'items/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'before_after_json_item_list', 'args' => array(
      'id' ,
    ),
    ));
}
;
function before_after_json_item_list($cat)
{
    
    $last_before_after_updated_date = get_option('last_before_after_updated_date');
    header("Last-Modified: " . $last_before_after_updated_date);
   $args = array(
'post_type' => 'before-after','posts_per_page' => -1, 
'tax_query' => array(
    array(
    'taxonomy' => 'before-after-category',
    'field' => 'term_id',
    'terms' => $cat['id']
     )
  )
); 
			$loop = new WP_Query($args);
					$i=0;
				$attr = 1;	
			  $before_after_list = array();
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
		
			 $page_id = get_the_ID();
                  $scar_location = get_post_meta(get_the_ID(),'scar_location',true);
						$before_photo_image = get_post_meta(get_the_ID(),'before_photo_image',true);
						$before_photo_image_src = wp_get_attachment_image_src( $before_photo_image[0], 'full' ); 
						$after_photo_image = get_post_meta(get_the_ID(),'after_photo_image',true);
						$after_photo_image_src = wp_get_attachment_image_src( $after_photo_image[0], 'full' ); 
						$batype = get_post_meta(get_the_ID(),'batype',true);
						$basize = get_post_meta(get_the_ID(),'basize',true);
						$profile = get_post_meta(get_the_ID(),'profile',true);
						
				 $before_after_list[] = array('id'=>get_the_ID(),'before_image'=>$before_photo_image_src[0],'after_image'=>$after_photo_image_src[0]);
		 endwhile;
						wp_reset_postdata();
					} 
           
    
    return rest_ensure_response($before_after_list);
}
//update header for json
add_action('save_post','save_post_callback',10,1);
function save_post_callback($post_id){
    global $post; 
	
	
	//before-after-list
    if ($post->post_type == 'before-after'){
	    update_option( 'last_before_after_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
        return;
    }
	
	//doctor-list
    if ($post->post_type == 'doctor'){
	    update_option( 'last_doctor_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
		update_option( 'last_visiting_doctor_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
        return;
    }
	
 
	//offer-list
	 
	 if ($post->post_type == 'offer'){
	    update_option( 'last_offer_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
        return;
    }
	 
	//service-list
	 if ($post->post_type == 'project' || $_REQUEST['post_type']=='project' ){
	    update_option( 'last_service_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
        return;
    }
	
	//testimonial-list
	 if ($post->post_type == 'testimonial'){
	    update_option( 'last_testimonial_updated_date',gmdate("D, d M Y H:i:s") . " GMT" );
        return;
    }
    //if you get here then it's your post type so do your thing....
}

//update header for doctor list update
//
 function qmc_slider() {  
 
	$args = array(	'post_type' => 'slider',
					'posts_per_page' => -1, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						$html = '<div class="owl-carousel owl-theme slide-carousel ">';
						$online=1;
						while($loop->have_posts()) : $loop->the_post();
						 
						$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
						 
							$i++;
						$html .= '<div class="item qmc-slider"><div style="background:url('.$featuredimage[0].')" class="home-slide-img"></div>';
						 
						
						$html .= '</div>';
						endwhile;
						wp_reset_postdata();
						$html .= '</div>';
					}
 // Output needs to be return
 return $html; 
 } 
 // register shortcode 
 add_shortcode('HOME-SLIDER', 'qmc_slider'); 
 
 function qmccustom_font($font){
	 return array();
 }
 apply_filters('cleanora_google_fonts_list_filter', 'qmccustom_font',10,1);
?>