<?php

namespace MailPoetGenerated;

use MailPoetVendor\Symfony\Component\DependencyInjection\Argument\RewindableGenerator;
use MailPoetVendor\Symfony\Component\DependencyInjection\ContainerInterface;
use MailPoetVendor\Symfony\Component\DependencyInjection\Container;
use MailPoetVendor\Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use MailPoetVendor\Symfony\Component\DependencyInjection\Exception\LogicException;
use MailPoetVendor\Symfony\Component\DependencyInjection\Exception\RuntimeException;
use MailPoetVendor\Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;

/**
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 *
 * @final since Symfony 3.3
 */
class FreeCachedContainer extends Container
{
    private $parameters;
    private $targetDirs = [];

    public function __construct()
    {
        $this->services = [];
        $this->normalizedIds = [
            'mailpoet\\api\\json\\api' => 'MailPoet\\API\\JSON\\API',
            'mailpoet\\api\\json\\v1\\automatedlatestcontent' => 'MailPoet\\API\\JSON\\v1\\AutomatedLatestContent',
            'mailpoet\\api\\json\\v1\\customfields' => 'MailPoet\\API\\JSON\\v1\\CustomFields',
            'mailpoet\\api\\json\\v1\\forms' => 'MailPoet\\API\\JSON\\v1\\Forms',
            'mailpoet\\api\\json\\v1\\importexport' => 'MailPoet\\API\\JSON\\v1\\ImportExport',
            'mailpoet\\api\\json\\v1\\mailer' => 'MailPoet\\API\\JSON\\v1\\Mailer',
            'mailpoet\\api\\json\\v1\\mp2migrator' => 'MailPoet\\API\\JSON\\v1\\MP2Migrator',
            'mailpoet\\api\\json\\v1\\newsletters' => 'MailPoet\\API\\JSON\\v1\\Newsletters',
            'mailpoet\\api\\json\\v1\\newslettertemplates' => 'MailPoet\\API\\JSON\\v1\\NewsletterTemplates',
            'mailpoet\\api\\json\\v1\\segments' => 'MailPoet\\API\\JSON\\v1\\Segments',
            'mailpoet\\api\\json\\v1\\sendingqueue' => 'MailPoet\\API\\JSON\\v1\\SendingQueue',
            'mailpoet\\api\\json\\v1\\services' => 'MailPoet\\API\\JSON\\v1\\Services',
            'mailpoet\\api\\json\\v1\\settings' => 'MailPoet\\API\\JSON\\v1\\Settings',
            'mailpoet\\api\\json\\v1\\setup' => 'MailPoet\\API\\JSON\\v1\\Setup',
            'mailpoet\\api\\json\\v1\\subscribers' => 'MailPoet\\API\\JSON\\v1\\Subscribers',
            'mailpoet\\api\\mp\\v1\\api' => 'MailPoet\\API\\MP\\v1\\API',
            'mailpoet\\config\\accesscontrol' => 'MailPoet\\Config\\AccessControl',
            'mailpoet\\config\\activator' => 'MailPoet\\Config\\Activator',
            'mailpoet\\config\\changelog' => 'MailPoet\\Config\\Changelog',
            'mailpoet\\config\\hooks' => 'MailPoet\\Config\\Hooks',
            'mailpoet\\config\\initializer' => 'MailPoet\\Config\\Initializer',
            'mailpoet\\config\\menu' => 'MailPoet\\Config\\Menu',
            'mailpoet\\config\\renderer' => 'MailPoet\\Config\\Renderer',
            'mailpoet\\config\\rendererfactory' => 'MailPoet\\Config\\RendererFactory',
            'mailpoet\\cron\\crontrigger' => 'MailPoet\\Cron\\CronTrigger',
            'mailpoet\\cron\\daemon' => 'MailPoet\\Cron\\Daemon',
            'mailpoet\\cron\\daemonhttprunner' => 'MailPoet\\Cron\\DaemonHttpRunner',
            'mailpoet\\cron\\workers\\sendingqueue\\sendingerrorhandler' => 'MailPoet\\Cron\\Workers\\SendingQueue\\SendingErrorHandler',
            'mailpoet\\cron\\workers\\statsnotifications\\scheduler' => 'MailPoet\\Cron\\Workers\\StatsNotifications\\Scheduler',
            'mailpoet\\cron\\workers\\workersfactory' => 'MailPoet\\Cron\\Workers\\WorkersFactory',
            'mailpoet\\di\\containerwrapper' => 'MailPoet\\DI\\ContainerWrapper',
            'mailpoet\\listing\\bulkactioncontroller' => 'MailPoet\\Listing\\BulkActionController',
            'mailpoet\\listing\\handler' => 'MailPoet\\Listing\\Handler',
            'mailpoet\\mailer\\mailer' => 'MailPoet\\Mailer\\Mailer',
            'mailpoet\\newsletter\\automatedlatestcontent' => 'MailPoet\\Newsletter\\AutomatedLatestContent',
            'mailpoet\\router\\endpoints\\crondaemon' => 'MailPoet\\Router\\Endpoints\\CronDaemon',
            'mailpoet\\router\\endpoints\\subscription' => 'MailPoet\\Router\\Endpoints\\Subscription',
            'mailpoet\\router\\endpoints\\track' => 'MailPoet\\Router\\Endpoints\\Track',
            'mailpoet\\router\\endpoints\\viewinbrowser' => 'MailPoet\\Router\\Endpoints\\ViewInBrowser',
            'mailpoet\\router\\router' => 'MailPoet\\Router\\Router',
            'mailpoet\\segments\\subscriberslistings' => 'MailPoet\\Segments\\SubscribersListings',
            'mailpoet\\segments\\woocommerce' => 'MailPoet\\Segments\\WooCommerce',
            'mailpoet\\settings\\settingscontroller' => 'MailPoet\\Settings\\SettingsController',
            'mailpoet\\subscribers\\confirmationemailmailer' => 'MailPoet\\Subscribers\\ConfirmationEmailMailer',
            'mailpoet\\subscribers\\newsubscribernotificationmailer' => 'MailPoet\\Subscribers\\NewSubscriberNotificationMailer',
            'mailpoet\\subscribers\\requiredcustomfieldvalidator' => 'MailPoet\\Subscribers\\RequiredCustomFieldValidator',
            'mailpoet\\subscribers\\subscriberactions' => 'MailPoet\\Subscribers\\SubscriberActions',
            'mailpoet\\subscription\\comment' => 'MailPoet\\Subscription\\Comment',
            'mailpoet\\subscription\\form' => 'MailPoet\\Subscription\\Form',
            'mailpoet\\subscription\\registration' => 'MailPoet\\Subscription\\Registration',
            'mailpoet\\woocommerce\\helper' => 'MailPoet\\WooCommerce\\Helper',
            'mailpoet\\wp\\functions' => 'MailPoet\\WP\\Functions',
        ];
        $this->syntheticIds = [
            'premium_container' => true,
        ];
        $this->methodMap = [
            'MailPoet\\API\\JSON\\API' => 'getAPIService',
            'MailPoet\\API\\JSON\\v1\\AutomatedLatestContent' => 'getAutomatedLatestContentService',
            'MailPoet\\API\\JSON\\v1\\CustomFields' => 'getCustomFieldsService',
            'MailPoet\\API\\JSON\\v1\\Forms' => 'getFormsService',
            'MailPoet\\API\\JSON\\v1\\ImportExport' => 'getImportExportService',
            'MailPoet\\API\\JSON\\v1\\MP2Migrator' => 'getMP2MigratorService',
            'MailPoet\\API\\JSON\\v1\\Mailer' => 'getMailerService',
            'MailPoet\\API\\JSON\\v1\\NewsletterTemplates' => 'getNewsletterTemplatesService',
            'MailPoet\\API\\JSON\\v1\\Newsletters' => 'getNewslettersService',
            'MailPoet\\API\\JSON\\v1\\Segments' => 'getSegmentsService',
            'MailPoet\\API\\JSON\\v1\\SendingQueue' => 'getSendingQueueService',
            'MailPoet\\API\\JSON\\v1\\Services' => 'getServicesService',
            'MailPoet\\API\\JSON\\v1\\Settings' => 'getSettingsService',
            'MailPoet\\API\\JSON\\v1\\Setup' => 'getSetupService',
            'MailPoet\\API\\JSON\\v1\\Subscribers' => 'getSubscribersService',
            'MailPoet\\API\\MP\\v1\\API' => 'getAPI2Service',
            'MailPoet\\Config\\AccessControl' => 'getAccessControlService',
            'MailPoet\\Config\\Activator' => 'getActivatorService',
            'MailPoet\\Config\\Changelog' => 'getChangelogService',
            'MailPoet\\Config\\Hooks' => 'getHooksService',
            'MailPoet\\Config\\Initializer' => 'getInitializerService',
            'MailPoet\\Config\\Menu' => 'getMenuService',
            'MailPoet\\Config\\Renderer' => 'getRendererService',
            'MailPoet\\Config\\RendererFactory' => 'getRendererFactoryService',
            'MailPoet\\Cron\\CronTrigger' => 'getCronTriggerService',
            'MailPoet\\Cron\\Daemon' => 'getDaemonService',
            'MailPoet\\Cron\\DaemonHttpRunner' => 'getDaemonHttpRunnerService',
            'MailPoet\\Cron\\Workers\\SendingQueue\\SendingErrorHandler' => 'getSendingErrorHandlerService',
            'MailPoet\\Cron\\Workers\\StatsNotifications\\Scheduler' => 'getSchedulerService',
            'MailPoet\\Cron\\Workers\\WorkersFactory' => 'getWorkersFactoryService',
            'MailPoet\\DI\\ContainerWrapper' => 'getContainerWrapperService',
            'MailPoet\\Listing\\BulkActionController' => 'getBulkActionControllerService',
            'MailPoet\\Listing\\Handler' => 'getHandlerService',
            'MailPoet\\Mailer\\Mailer' => 'getMailer2Service',
            'MailPoet\\Newsletter\\AutomatedLatestContent' => 'getAutomatedLatestContent2Service',
            'MailPoet\\Router\\Endpoints\\CronDaemon' => 'getCronDaemonService',
            'MailPoet\\Router\\Endpoints\\Subscription' => 'getSubscriptionService',
            'MailPoet\\Router\\Endpoints\\Track' => 'getTrackService',
            'MailPoet\\Router\\Endpoints\\ViewInBrowser' => 'getViewInBrowserService',
            'MailPoet\\Router\\Router' => 'getRouterService',
            'MailPoet\\Segments\\SubscribersListings' => 'getSubscribersListingsService',
            'MailPoet\\Segments\\WooCommerce' => 'getWooCommerceService',
            'MailPoet\\Settings\\SettingsController' => 'getSettingsControllerService',
            'MailPoet\\Subscribers\\ConfirmationEmailMailer' => 'getConfirmationEmailMailerService',
            'MailPoet\\Subscribers\\NewSubscriberNotificationMailer' => 'getNewSubscriberNotificationMailerService',
            'MailPoet\\Subscribers\\RequiredCustomFieldValidator' => 'getRequiredCustomFieldValidatorService',
            'MailPoet\\Subscribers\\SubscriberActions' => 'getSubscriberActionsService',
            'MailPoet\\Subscription\\Comment' => 'getCommentService',
            'MailPoet\\Subscription\\Form' => 'getFormService',
            'MailPoet\\Subscription\\Registration' => 'getRegistrationService',
            'MailPoet\\WP\\Functions' => 'getFunctionsService',
            'MailPoet\\WooCommerce\\Helper' => 'getHelperService',
        ];
        $this->privates = [
            'MailPoet\\Cron\\Workers\\StatsNotifications\\Scheduler' => true,
            'MailPoet\\Mailer\\Mailer' => true,
            'MailPoet\\Router\\Router' => true,
        ];

        $this->aliases = [];
    }

    public function getRemovedIds()
    {
        return [
            'MailPoetVendor\\Psr\\Container\\ContainerInterface' => true,
            'MailPoetVendor\\Symfony\\Component\\DependencyInjection\\ContainerInterface' => true,
            'MailPoet\\Cron\\Workers\\StatsNotifications\\Scheduler' => true,
            'MailPoet\\Mailer\\Mailer' => true,
            'MailPoet\\Router\\Router' => true,
            'autowired.MailPoet\\Config\\ServicesChecker' => true,
        ];
    }

    public function compile()
    {
        throw new LogicException('You cannot compile a dumped container that was already compiled.');
    }

    public function isCompiled()
    {
        return true;
    }

    public function isFrozen()
    {
        @trigger_error(sprintf('The %s() method is deprecated since Symfony 3.3 and will be removed in 4.0. Use the isCompiled() method instead.', __METHOD__), E_USER_DEPRECATED);

        return true;
    }

    /**
     * Gets the public 'MailPoet\API\JSON\API' shared autowired service.
     *
     * @return \MailPoet\API\JSON\API
     */
    protected function getAPIService()
    {
        return $this->services['MailPoet\API\JSON\API'] = new \MailPoet\API\JSON\API(${($_ = isset($this->services['MailPoet\DI\ContainerWrapper']) ? $this->services['MailPoet\DI\ContainerWrapper'] : $this->getContainerWrapperService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\AccessControl']) ? $this->services['MailPoet\Config\AccessControl'] : ($this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\AutomatedLatestContent' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\AutomatedLatestContent
     */
    protected function getAutomatedLatestContentService()
    {
        return $this->services['MailPoet\API\JSON\v1\AutomatedLatestContent'] = new \MailPoet\API\JSON\v1\AutomatedLatestContent(${($_ = isset($this->services['MailPoet\Newsletter\AutomatedLatestContent']) ? $this->services['MailPoet\Newsletter\AutomatedLatestContent'] : ($this->services['MailPoet\Newsletter\AutomatedLatestContent'] = new \MailPoet\Newsletter\AutomatedLatestContent())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\CustomFields' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\CustomFields
     */
    protected function getCustomFieldsService()
    {
        return $this->services['MailPoet\API\JSON\v1\CustomFields'] = new \MailPoet\API\JSON\v1\CustomFields();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Forms' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Forms
     */
    protected function getFormsService()
    {
        return $this->services['MailPoet\API\JSON\v1\Forms'] = new \MailPoet\API\JSON\v1\Forms(${($_ = isset($this->services['MailPoet\Listing\BulkActionController']) ? $this->services['MailPoet\Listing\BulkActionController'] : $this->getBulkActionControllerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\ImportExport' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\ImportExport
     */
    protected function getImportExportService()
    {
        return $this->services['MailPoet\API\JSON\v1\ImportExport'] = new \MailPoet\API\JSON\v1\ImportExport();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\MP2Migrator' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\MP2Migrator
     */
    protected function getMP2MigratorService()
    {
        return $this->services['MailPoet\API\JSON\v1\MP2Migrator'] = new \MailPoet\API\JSON\v1\MP2Migrator();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Mailer' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Mailer
     */
    protected function getMailerService()
    {
        return $this->services['MailPoet\API\JSON\v1\Mailer'] = new \MailPoet\API\JSON\v1\Mailer();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\NewsletterTemplates' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\NewsletterTemplates
     */
    protected function getNewsletterTemplatesService()
    {
        return $this->services['MailPoet\API\JSON\v1\NewsletterTemplates'] = new \MailPoet\API\JSON\v1\NewsletterTemplates();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Newsletters' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Newsletters
     */
    protected function getNewslettersService()
    {
        return $this->services['MailPoet\API\JSON\v1\Newsletters'] = new \MailPoet\API\JSON\v1\Newsletters(${($_ = isset($this->services['MailPoet\Listing\BulkActionController']) ? $this->services['MailPoet\Listing\BulkActionController'] : $this->getBulkActionControllerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Segments' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Segments
     */
    protected function getSegmentsService()
    {
        return $this->services['MailPoet\API\JSON\v1\Segments'] = new \MailPoet\API\JSON\v1\Segments(${($_ = isset($this->services['MailPoet\Listing\BulkActionController']) ? $this->services['MailPoet\Listing\BulkActionController'] : $this->getBulkActionControllerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\SendingQueue' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\SendingQueue
     */
    protected function getSendingQueueService()
    {
        return $this->services['MailPoet\API\JSON\v1\SendingQueue'] = new \MailPoet\API\JSON\v1\SendingQueue();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Services' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Services
     */
    protected function getServicesService()
    {
        return $this->services['MailPoet\API\JSON\v1\Services'] = new \MailPoet\API\JSON\v1\Services();
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Settings' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Settings
     */
    protected function getSettingsService()
    {
        return $this->services['MailPoet\API\JSON\v1\Settings'] = new \MailPoet\API\JSON\v1\Settings(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Setup' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Setup
     */
    protected function getSetupService()
    {
        return $this->services['MailPoet\API\JSON\v1\Setup'] = new \MailPoet\API\JSON\v1\Setup(${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\JSON\v1\Subscribers' shared autowired service.
     *
     * @return \MailPoet\API\JSON\v1\Subscribers
     */
    protected function getSubscribersService()
    {
        return $this->services['MailPoet\API\JSON\v1\Subscribers'] = new \MailPoet\API\JSON\v1\Subscribers(${($_ = isset($this->services['MailPoet\Listing\BulkActionController']) ? $this->services['MailPoet\Listing\BulkActionController'] : $this->getBulkActionControllerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Segments\SubscribersListings']) ? $this->services['MailPoet\Segments\SubscribersListings'] : $this->getSubscribersListingsService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\SubscriberActions']) ? $this->services['MailPoet\Subscribers\SubscriberActions'] : $this->getSubscriberActionsService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\RequiredCustomFieldValidator']) ? $this->services['MailPoet\Subscribers\RequiredCustomFieldValidator'] : ($this->services['MailPoet\Subscribers\RequiredCustomFieldValidator'] = new \MailPoet\Subscribers\RequiredCustomFieldValidator())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\API\MP\v1\API' shared autowired service.
     *
     * @return \MailPoet\API\MP\v1\API
     */
    protected function getAPI2Service()
    {
        return $this->services['MailPoet\API\MP\v1\API'] = new \MailPoet\API\MP\v1\API(${($_ = isset($this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer']) ? $this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer'] : ($this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer'] = new \MailPoet\Subscribers\NewSubscriberNotificationMailer())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\ConfirmationEmailMailer']) ? $this->services['MailPoet\Subscribers\ConfirmationEmailMailer'] : $this->getConfirmationEmailMailerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\RequiredCustomFieldValidator']) ? $this->services['MailPoet\Subscribers\RequiredCustomFieldValidator'] : ($this->services['MailPoet\Subscribers\RequiredCustomFieldValidator'] = new \MailPoet\Subscribers\RequiredCustomFieldValidator())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Config\AccessControl' shared autowired service.
     *
     * @return \MailPoet\Config\AccessControl
     */
    protected function getAccessControlService()
    {
        return $this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl();
    }

    /**
     * Gets the public 'MailPoet\Config\Activator' shared autowired service.
     *
     * @return \MailPoet\Config\Activator
     */
    protected function getActivatorService()
    {
        return $this->services['MailPoet\Config\Activator'] = new \MailPoet\Config\Activator(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Config\Changelog' shared autowired service.
     *
     * @return \MailPoet\Config\Changelog
     */
    protected function getChangelogService()
    {
        return $this->services['MailPoet\Config\Changelog'] = new \MailPoet\Config\Changelog(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Config\Hooks' shared autowired service.
     *
     * @return \MailPoet\Config\Hooks
     */
    protected function getHooksService()
    {
        return $this->services['MailPoet\Config\Hooks'] = new \MailPoet\Config\Hooks(${($_ = isset($this->services['MailPoet\Subscription\Form']) ? $this->services['MailPoet\Subscription\Form'] : $this->getFormService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscription\Comment']) ? $this->services['MailPoet\Subscription\Comment'] : $this->getCommentService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscription\Registration']) ? $this->services['MailPoet\Subscription\Registration'] : $this->getRegistrationService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Segments\WooCommerce']) ? $this->services['MailPoet\Segments\WooCommerce'] : $this->getWooCommerceService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Config\Initializer' shared autowired service.
     *
     * @return \MailPoet\Config\Initializer
     */
    protected function getInitializerService()
    {
        return $this->services['MailPoet\Config\Initializer'] = new \MailPoet\Config\Initializer(${($_ = isset($this->services['MailPoet\Config\RendererFactory']) ? $this->services['MailPoet\Config\RendererFactory'] : ($this->services['MailPoet\Config\RendererFactory'] = new \MailPoet\Config\RendererFactory())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\AccessControl']) ? $this->services['MailPoet\Config\AccessControl'] : ($this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\API\JSON\API']) ? $this->services['MailPoet\API\JSON\API'] : $this->getAPIService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\Activator']) ? $this->services['MailPoet\Config\Activator'] : $this->getActivatorService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Router\Router']) ? $this->services['MailPoet\Router\Router'] : $this->getRouterService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\Hooks']) ? $this->services['MailPoet\Config\Hooks'] : $this->getHooksService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\Changelog']) ? $this->services['MailPoet\Config\Changelog'] : $this->getChangelogService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\Menu']) ? $this->services['MailPoet\Config\Menu'] : $this->getMenuService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Cron\CronTrigger']) ? $this->services['MailPoet\Cron\CronTrigger'] : $this->getCronTriggerService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Config\Menu' shared autowired service.
     *
     * @return \MailPoet\Config\Menu
     */
    protected function getMenuService()
    {
        return $this->services['MailPoet\Config\Menu'] = new \MailPoet\Config\Menu(${($_ = isset($this->services['MailPoet\Config\Renderer']) ? $this->services['MailPoet\Config\Renderer'] : $this->getRendererService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\AccessControl']) ? $this->services['MailPoet\Config\AccessControl'] : ($this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WooCommerce\Helper']) ? $this->services['MailPoet\WooCommerce\Helper'] : ($this->services['MailPoet\WooCommerce\Helper'] = new \MailPoet\WooCommerce\Helper())) && false ?: '_'}, new \MailPoet\Config\ServicesChecker());
    }

    /**
     * Gets the public 'MailPoet\Config\Renderer' shared service.
     *
     * @return \MailPoet\Config\Renderer
     */
    protected function getRendererService()
    {
        return $this->services['MailPoet\Config\Renderer'] = ${($_ = isset($this->services['MailPoet\Config\RendererFactory']) ? $this->services['MailPoet\Config\RendererFactory'] : ($this->services['MailPoet\Config\RendererFactory'] = new \MailPoet\Config\RendererFactory())) && false ?: '_'}->getRenderer();
    }

    /**
     * Gets the public 'MailPoet\Config\RendererFactory' shared autowired service.
     *
     * @return \MailPoet\Config\RendererFactory
     */
    protected function getRendererFactoryService()
    {
        return $this->services['MailPoet\Config\RendererFactory'] = new \MailPoet\Config\RendererFactory();
    }

    /**
     * Gets the public 'MailPoet\Cron\CronTrigger' shared autowired service.
     *
     * @return \MailPoet\Cron\CronTrigger
     */
    protected function getCronTriggerService()
    {
        return $this->services['MailPoet\Cron\CronTrigger'] = new \MailPoet\Cron\CronTrigger(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Cron\Daemon' shared autowired service.
     *
     * @return \MailPoet\Cron\Daemon
     */
    protected function getDaemonService()
    {
        return $this->services['MailPoet\Cron\Daemon'] = new \MailPoet\Cron\Daemon(${($_ = isset($this->services['MailPoet\Cron\Workers\WorkersFactory']) ? $this->services['MailPoet\Cron\Workers\WorkersFactory'] : $this->getWorkersFactoryService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Cron\DaemonHttpRunner' shared autowired service.
     *
     * @return \MailPoet\Cron\DaemonHttpRunner
     */
    protected function getDaemonHttpRunnerService()
    {
        return $this->services['MailPoet\Cron\DaemonHttpRunner'] = new \MailPoet\Cron\DaemonHttpRunner(${($_ = isset($this->services['MailPoet\Cron\Daemon']) ? $this->services['MailPoet\Cron\Daemon'] : $this->getDaemonService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler' shared autowired service.
     *
     * @return \MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler
     */
    protected function getSendingErrorHandlerService()
    {
        return $this->services['MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler'] = new \MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler();
    }

    /**
     * Gets the public 'MailPoet\Cron\Workers\WorkersFactory' shared autowired service.
     *
     * @return \MailPoet\Cron\Workers\WorkersFactory
     */
    protected function getWorkersFactoryService()
    {
        return $this->services['MailPoet\Cron\Workers\WorkersFactory'] = new \MailPoet\Cron\Workers\WorkersFactory(${($_ = isset($this->services['MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler']) ? $this->services['MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler'] : ($this->services['MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler'] = new \MailPoet\Cron\Workers\SendingQueue\SendingErrorHandler())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Cron\Workers\StatsNotifications\Scheduler']) ? $this->services['MailPoet\Cron\Workers\StatsNotifications\Scheduler'] : $this->getSchedulerService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Mailer\Mailer']) ? $this->services['MailPoet\Mailer\Mailer'] : ($this->services['MailPoet\Mailer\Mailer'] = new \MailPoet\Mailer\Mailer())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Config\Renderer']) ? $this->services['MailPoet\Config\Renderer'] : $this->getRendererService()) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Segments\WooCommerce']) ? $this->services['MailPoet\Segments\WooCommerce'] : $this->getWooCommerceService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\DI\ContainerWrapper' shared service.
     *
     * @return \MailPoet\DI\ContainerWrapper
     */
    protected function getContainerWrapperService()
    {
        return $this->services['MailPoet\DI\ContainerWrapper'] = \MailPoet\DI\ContainerWrapper::getInstance();
    }

    /**
     * Gets the public 'MailPoet\Listing\BulkActionController' shared autowired service.
     *
     * @return \MailPoet\Listing\BulkActionController
     */
    protected function getBulkActionControllerService()
    {
        return $this->services['MailPoet\Listing\BulkActionController'] = new \MailPoet\Listing\BulkActionController(${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Listing\Handler' shared autowired service.
     *
     * @return \MailPoet\Listing\Handler
     */
    protected function getHandlerService()
    {
        return $this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler();
    }

    /**
     * Gets the public 'MailPoet\Newsletter\AutomatedLatestContent' shared autowired service.
     *
     * @return \MailPoet\Newsletter\AutomatedLatestContent
     */
    protected function getAutomatedLatestContent2Service()
    {
        return $this->services['MailPoet\Newsletter\AutomatedLatestContent'] = new \MailPoet\Newsletter\AutomatedLatestContent();
    }

    /**
     * Gets the public 'MailPoet\Router\Endpoints\CronDaemon' shared autowired service.
     *
     * @return \MailPoet\Router\Endpoints\CronDaemon
     */
    protected function getCronDaemonService()
    {
        return $this->services['MailPoet\Router\Endpoints\CronDaemon'] = new \MailPoet\Router\Endpoints\CronDaemon(${($_ = isset($this->services['MailPoet\Cron\DaemonHttpRunner']) ? $this->services['MailPoet\Cron\DaemonHttpRunner'] : $this->getDaemonHttpRunnerService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Router\Endpoints\Subscription' shared autowired service.
     *
     * @return \MailPoet\Router\Endpoints\Subscription
     */
    protected function getSubscriptionService()
    {
        return $this->services['MailPoet\Router\Endpoints\Subscription'] = new \MailPoet\Router\Endpoints\Subscription();
    }

    /**
     * Gets the public 'MailPoet\Router\Endpoints\Track' shared autowired service.
     *
     * @return \MailPoet\Router\Endpoints\Track
     */
    protected function getTrackService()
    {
        return $this->services['MailPoet\Router\Endpoints\Track'] = new \MailPoet\Router\Endpoints\Track();
    }

    /**
     * Gets the public 'MailPoet\Router\Endpoints\ViewInBrowser' shared autowired service.
     *
     * @return \MailPoet\Router\Endpoints\ViewInBrowser
     */
    protected function getViewInBrowserService()
    {
        return $this->services['MailPoet\Router\Endpoints\ViewInBrowser'] = new \MailPoet\Router\Endpoints\ViewInBrowser(${($_ = isset($this->services['MailPoet\Config\AccessControl']) ? $this->services['MailPoet\Config\AccessControl'] : ($this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Segments\SubscribersListings' shared autowired service.
     *
     * @return \MailPoet\Segments\SubscribersListings
     */
    protected function getSubscribersListingsService()
    {
        return $this->services['MailPoet\Segments\SubscribersListings'] = new \MailPoet\Segments\SubscribersListings(${($_ = isset($this->services['MailPoet\Listing\Handler']) ? $this->services['MailPoet\Listing\Handler'] : ($this->services['MailPoet\Listing\Handler'] = new \MailPoet\Listing\Handler())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Segments\WooCommerce' shared autowired service.
     *
     * @return \MailPoet\Segments\WooCommerce
     */
    protected function getWooCommerceService()
    {
        return $this->services['MailPoet\Segments\WooCommerce'] = new \MailPoet\Segments\WooCommerce(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Settings\SettingsController' shared autowired service.
     *
     * @return \MailPoet\Settings\SettingsController
     */
    protected function getSettingsControllerService()
    {
        return $this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController();
    }

    /**
     * Gets the public 'MailPoet\Subscribers\ConfirmationEmailMailer' shared autowired service.
     *
     * @return \MailPoet\Subscribers\ConfirmationEmailMailer
     */
    protected function getConfirmationEmailMailerService()
    {
        return $this->services['MailPoet\Subscribers\ConfirmationEmailMailer'] = new \MailPoet\Subscribers\ConfirmationEmailMailer(NULL, ${($_ = isset($this->services['MailPoet\WP\Functions']) ? $this->services['MailPoet\WP\Functions'] : ($this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions())) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Subscribers\NewSubscriberNotificationMailer' shared autowired service.
     *
     * @return \MailPoet\Subscribers\NewSubscriberNotificationMailer
     */
    protected function getNewSubscriberNotificationMailerService()
    {
        return $this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer'] = new \MailPoet\Subscribers\NewSubscriberNotificationMailer();
    }

    /**
     * Gets the public 'MailPoet\Subscribers\RequiredCustomFieldValidator' shared autowired service.
     *
     * @return \MailPoet\Subscribers\RequiredCustomFieldValidator
     */
    protected function getRequiredCustomFieldValidatorService()
    {
        return $this->services['MailPoet\Subscribers\RequiredCustomFieldValidator'] = new \MailPoet\Subscribers\RequiredCustomFieldValidator();
    }

    /**
     * Gets the public 'MailPoet\Subscribers\SubscriberActions' shared autowired service.
     *
     * @return \MailPoet\Subscribers\SubscriberActions
     */
    protected function getSubscriberActionsService()
    {
        return $this->services['MailPoet\Subscribers\SubscriberActions'] = new \MailPoet\Subscribers\SubscriberActions(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer']) ? $this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer'] : ($this->services['MailPoet\Subscribers\NewSubscriberNotificationMailer'] = new \MailPoet\Subscribers\NewSubscriberNotificationMailer())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\ConfirmationEmailMailer']) ? $this->services['MailPoet\Subscribers\ConfirmationEmailMailer'] : $this->getConfirmationEmailMailerService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Subscription\Comment' shared autowired service.
     *
     * @return \MailPoet\Subscription\Comment
     */
    protected function getCommentService()
    {
        return $this->services['MailPoet\Subscription\Comment'] = new \MailPoet\Subscription\Comment(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\SubscriberActions']) ? $this->services['MailPoet\Subscribers\SubscriberActions'] : $this->getSubscriberActionsService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Subscription\Form' shared autowired service.
     *
     * @return \MailPoet\Subscription\Form
     */
    protected function getFormService()
    {
        return $this->services['MailPoet\Subscription\Form'] = new \MailPoet\Subscription\Form(${($_ = isset($this->services['MailPoet\API\JSON\API']) ? $this->services['MailPoet\API\JSON\API'] : $this->getAPIService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\Subscription\Registration' shared autowired service.
     *
     * @return \MailPoet\Subscription\Registration
     */
    protected function getRegistrationService()
    {
        return $this->services['MailPoet\Subscription\Registration'] = new \MailPoet\Subscription\Registration(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\Subscribers\SubscriberActions']) ? $this->services['MailPoet\Subscribers\SubscriberActions'] : $this->getSubscriberActionsService()) && false ?: '_'});
    }

    /**
     * Gets the public 'MailPoet\WP\Functions' shared autowired service.
     *
     * @return \MailPoet\WP\Functions
     */
    protected function getFunctionsService()
    {
        return $this->services['MailPoet\WP\Functions'] = new \MailPoet\WP\Functions();
    }

    /**
     * Gets the public 'MailPoet\WooCommerce\Helper' shared autowired service.
     *
     * @return \MailPoet\WooCommerce\Helper
     */
    protected function getHelperService()
    {
        return $this->services['MailPoet\WooCommerce\Helper'] = new \MailPoet\WooCommerce\Helper();
    }

    /**
     * Gets the private 'MailPoet\Cron\Workers\StatsNotifications\Scheduler' shared autowired service.
     *
     * @return \MailPoet\Cron\Workers\StatsNotifications\Scheduler
     */
    protected function getSchedulerService()
    {
        return $this->services['MailPoet\Cron\Workers\StatsNotifications\Scheduler'] = new \MailPoet\Cron\Workers\StatsNotifications\Scheduler(${($_ = isset($this->services['MailPoet\Settings\SettingsController']) ? $this->services['MailPoet\Settings\SettingsController'] : ($this->services['MailPoet\Settings\SettingsController'] = new \MailPoet\Settings\SettingsController())) && false ?: '_'});
    }

    /**
     * Gets the private 'MailPoet\Mailer\Mailer' shared autowired service.
     *
     * @return \MailPoet\Mailer\Mailer
     */
    protected function getMailer2Service()
    {
        return $this->services['MailPoet\Mailer\Mailer'] = new \MailPoet\Mailer\Mailer();
    }

    /**
     * Gets the private 'MailPoet\Router\Router' shared autowired service.
     *
     * @return \MailPoet\Router\Router
     */
    protected function getRouterService()
    {
        return $this->services['MailPoet\Router\Router'] = new \MailPoet\Router\Router(${($_ = isset($this->services['MailPoet\Config\AccessControl']) ? $this->services['MailPoet\Config\AccessControl'] : ($this->services['MailPoet\Config\AccessControl'] = new \MailPoet\Config\AccessControl())) && false ?: '_'}, ${($_ = isset($this->services['MailPoet\DI\ContainerWrapper']) ? $this->services['MailPoet\DI\ContainerWrapper'] : $this->getContainerWrapperService()) && false ?: '_'});
    }
}
